# CherryQuant 量化系统 — 文件路径清单（修正版 V2）

> 供 AI 评审使用的项目结构说明。项目根目录：`D:\Projects\quant-web\`
> 旧版备份（勿动）：`D:\Projects\quant\`

---

## 一、核心引擎（评审优先看这些）

| 文件 | 作用 | 评审价值 |
|---|---|---|
| `backend/engine/config.py` | 全局配置：20只ETF池/各标的阈值/风控参数/催化日历 | 看参数设计 |
| `backend/engine/signals.py` | **信号引擎**：指标计算、`_score()`多因子评分、止损止盈、市场温度 | 核心逻辑，查未来函数 |
| `backend/engine/data.py` | **数据层**：东财→akshare→腾讯多源拉取、缓存隔离、失败降级 | ⭐数据可信度必看（评审遗漏项） |
| `backend/engine/backtest.py` | 回测引擎：策略执行、风控模拟、绩效计算、FIFO胜率 | 回测可信度 |
| `backend/engine/decision.py` | **统一决策引擎**：`decide_holding`/`decide_buy`，所有模块共用一套买卖判定 | 消除口径矛盾 |
| `backend/engine/recommend.py` | **推荐组合**：验证有效Top3 + 评分加权 + 市场温度择时 | 当前核心策略 |
| `backend/engine/optimizer.py` | 调仓引擎：具体买卖份数/金额/批次 | 小资金执行 |
| `backend/engine/fflow.py` | 资金流数据（IC0.160最强因子）+ 新鲜度监控 | 数据源稳定性 |
| `backend/engine/rotation.py` | 板块动量/趋势质量（强趋势/回调企稳/下跌趋势） | 追强势板块 |
| `backend/engine/verify.py` | 样本外验证状态（读取 optimize_report_new.json） | 验证可信度 |
| `backend/engine/portfolio_backtest.py` | 组合回测（多标的同时持仓） | 组合层面验证 |
| `backend/engine/risk.py` | 组合风险（波动率/风险贡献/VaR） | 风控合理性 |

## 二、回测与验证脚本（可复现）

| 文件 | 作用 |
|---|---|
| `backend/history_rotation_backtest.py` | 10.6年动态轮动回测（2026-08最新数据） |
| `backend/final_return_test.py` | 最终收益报告（多区间：3.6年/5.6年/8.6年/10.6年） |
| `backend/market_filter_backtest.py` | 市场温度择时效果验证 |
| `backend/refresh_verify_report.py` | 验证报告刷新（全池阈值优化+样本外） |
| `backend/system_verify.py` | 系统全流程自检（16项 API 验证） |

## 三、数据文件（回测数据源）

```
D:\Projects\quant-web\data\cache\tencent\   ← 主数据源（K线，已合并10.6年历史，20只ETF）
D:\Projects\quant-web\data\cache\fflow\     ← 资金流缓存
D:\Projects\quant-web\data\optimize_report_new.json  ← 当前验证报告（10.6年数据重算）
D:\Projects\quant-web\data\ml_model.joblib          ← ML模型（GradientBoosting，AUC~0.61）
```

## 四、前端（可选看）

```
frontend/signals.html   ← 信号页（推荐组合/调仓方案/风控展示）
frontend/index.html     ← 仪表盘
frontend/backtest.html  ← 回测中心
```

---

## 当前系统核心策略（给评审的一句话背景）

> 这是一个 A股 ETF 量化轮动系统，主战场 20 只 ETF。核心策略：
> **多因子评分（MACD/均线/RSI/动量/形态/资金流/板块动量）→ 筛选"样本外验证有效"的标的 → 取评分最高的 Top3 → 按评分加权分配资金（单只上限40%）→ 用市场温度择时控制总仓位（>60满仓/40-60半仓/<40空仓）→ 趋势自适应止盈（强趋势放宽止盈线让利润奔跑）→ 每20个交易日调仓。**
>
> 关键回测数据（**诚实口径**，2026-09-05 由 `backend/long_history_backtest.py` 在东财上市以来全历史 OHLC 上实测，
> 评分无资金流 + Top5 + 20日调仓 + 点内有效 + 温度择时 + 止损-10%/-8% + 止盈+15% + T+1开盘成交 + 万3佣+千1滑）：
> - 近3.7年(2023起)：**+55.1%**，年化12.7%，夏普0.92，回撤-20.2%
> - 近5.7年(2021起，含震荡熊市)：**+26.6%**，年化4.2%，夏普0.40，回撤-28.2%
> - 近8.7年(2018起)：+4.6%，年化0.5%（温度择时在震荡市频繁空仓的代价）
> - 10.7年(2016起)：+43.5%，年化3.4%，夏普0.32，回撤-28.4%
> - 温度择时是双刃剑：2023起 收益+26pp、回撤-14pp；2018起 收益-12pp（详见脚本输出对比）
> - 旧口径数字（+58.4%/+181.9%）来自零成本+同日收盘+全历史标签的过期数据集，已废弃，勿再引用
>
> 请重点评审：1) 评分逻辑有无未来函数；2) 回测方法是否可信；3) 风控/止损设置是否合理；4) 哪些地方能提高收益。

---

## 已知局限（诚实声明，供评审参考）

1. **资金流数据仅约120天**：东财资金流免费接口无论 lmt 多少只返回约120天，长周期回测无法纳入该因子。近半年实测 IC +0.12（90%正、t≈4，见 `backend/fflow_ic_check.py`），有效但属于短样本统计。
2. **月胜率仅44-46%**：靠大赚小亏积累收益，不是稳定盈利。
3. **温度择时是双刃剑**：牛市大幅增效（2023起+26pp），震荡市拖累收益（2018起-12pp）。
4. **评分不含资金流**：诚实长回测与实盘（含资金流）不完全等同；实盘含资金流后表现介于两口径之间。
5. **池为事后挑选**：20只热门赛道 ETF 由 2025-26 视角选定，相对全市场仍有主题幸存者偏差。

---

## 系统升级记录（2026-09-05）

| 文件 | 说明 |
|---|---|
| `backend/fetch_long_history.ps1` | 拉取 20 只 ETF 上市以来全历史 OHLC（东财前复权）→ `data/cache/em_long/` |
| `backend/fetch_fflow.ps1` | 拉取资金流日数据（约120天，接口上限）→ `data/cache/fflow/` |
| `backend/long_history_backtest.py` | **诚实回测管线**：T+1开盘成交、含成本、点内有效、完整风控、温度择时开关、多起点对比 |
| `backend/today_signals.py` | 当期信号报告（排名/信号/趋势/温度仓位建议） |
| `backend/fflow_ic_check.py` | 资金流因子 IC 检验 |
| `engine/recommend.py` | 静态全历史验证表 → **滚动点内有效性**（`_rolling_valid`，与回测口径一致）；BT_SNAPSHOT 换成诚实口径 |
| `engine/ml.py` | 标签起点改为 T 日开盘（与实盘执行一致）；训练/测试切分加 5 日间隔期（embargo） |
