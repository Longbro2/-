# -*- coding: utf-8 -*-
"""
CherryQuant 桌面启动器（无黑窗版）
双击运行：后台启动服务 + 自动打开浏览器 + 日志记录
任何错误都会写入 start_app.log，方便排查
"""
import os
import sys
import time
import threading
import subprocess
import webbrowser
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
LOG_FILE = BASE_DIR / "start_app.log"
PORT = 8000
URL = f"http://localhost:{PORT}"

def log(msg):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")

def wait_port(port, timeout=30):
    """等待端口可访问"""
    import socket
    end = time.time() + timeout
    while time.time() < end:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1):
                return True
        except OSError:
            time.sleep(0.5)
    return False

def is_running(port):
    import socket
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=1):
            return True
    except OSError:
        return False

def open_browser():
    """等服务起来后自动打开浏览器"""
    time.sleep(3)
    if wait_port(PORT, timeout=30):
        webbrowser.open(URL)
        log(f"浏览器已打开: {URL}")
    else:
        log(f"警告: 等待 {URL} 超时")

def main():
    log("=== CherryQuant 启动 ===")

    # 0. 如果服务已在运行，直接打开浏览器
    if is_running(PORT):
        log("服务已在运行，直接打开浏览器")
        webbrowser.open(URL)
        return

    # 1. 检查依赖
    try:
        subprocess.run([sys.executable, "-c",
            "import fastapi, uvicorn, pandas, numpy, requests, openpyxl, python_multipart"],
            check=True, capture_output=True, timeout=30)
    except subprocess.CalledProcessError:
        log("依赖缺失，开始安装...")
        subprocess.run([sys.executable, "-m", "pip", "install",
            "-r", str(BASE_DIR / "requirements.txt"),
            "-i", "https://pypi.tuna.tsinghua.edu.cn/simple"],
            capture_output=True, timeout=300)
        log("依赖安装完成")

    # 2. 清理非法缓存（不阻塞，失败忽略）
    try:
        subprocess.run([sys.executable, "-X", "utf8", "-c",
            "import sys; sys.path.insert(0,'backend'); from engine.data import remove_garbage; print(remove_garbage())"],
            cwd=str(BASE_DIR), capture_output=True, timeout=60)
    except Exception:
        pass

    # 3. 后台启动服务
    log(f"启动服务: {URL}")
    proc = subprocess.Popen(
        [sys.executable, "-X", "utf8", "-m", "uvicorn",
         "main:app", "--app-dir", "backend",
         "--host", "127.0.0.1", "--port", str(PORT)],
        cwd=str(BASE_DIR),
        stdout=open(BASE_DIR / "server.log", "a", encoding="utf-8"),
        stderr=subprocess.STDOUT,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    log(f"服务进程 PID={proc.pid}")

    # 4. 打开浏览器
    threading.Thread(target=open_browser, daemon=True).start()

    # 5. 保持进程（由用户关闭？不，双击后脚本结束，子进程继续后台跑）
    # 注意：Popen 子进程会随父进程退出而继续存活（Windows 下 detach）

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log(f"启动失败: {e}")
        import ctypes
        ctypes.windll.user32.MessageBoxW(0,
            f"CherryQuant 启动失败：\n\n{e}\n\n详见 {LOG_FILE}",
            "CherryQuant", 0x10)  # MB_ICONERROR
