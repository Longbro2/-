@echo off
chcp 65001 >nul
title CherryQuant Web
cd /d "%~dp0"

echo ============================================
echo   CherryQuant Web V5.2  —  一键启动
echo ============================================
echo.

REM 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到 Python，请先安装 Python 3.10+ 并勾选 "Add to PATH"
    pause
    exit /b 1
)

REM 检查/安装依赖
echo [1/3] 检查依赖...
python -c "import fastapi, uvicorn, pandas, numpy, requests, openpyxl, python_multipart" >nul 2>&1
if errorlevel 1 (
    echo   首次运行，正在安装依赖（可能需要 1-3 分钟）...
    python -m pip install -r "%~dp0requirements.txt" -i https://pypi.tuna.tsinghua.edu.cn/simple
)

REM 清理垃圾缓存
echo [2/3] 清理非法缓存文件...
python -X utf8 -c "import sys; sys.path.insert(0,'backend'); from engine.data import remove_garbage; print('  已清理:', remove_garbage())" 2>nul

echo [3/3] 启动 Web 服务...
echo.
echo   ▸ 浏览器将自动打开: http://localhost:8000
echo   ▸ 关闭本窗口即停止服务
echo.

REM 打开浏览器（延迟2秒等服务起来）
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:8000"

REM 启动服务（UTF-8 输出避免乱码）
python -X utf8 -m uvicorn main:app --app-dir backend --host 127.0.0.1 --port 8000

pause
