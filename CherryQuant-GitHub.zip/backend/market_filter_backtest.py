# -*- coding: utf-8 -*-
"""加入市场温度择时后的全历史回测对比（口径已对齐主引擎）
验证：市场温度(全池平均分)过滤能否大幅降低回撤、保留收益。
- 评分/tq 阈值：research_common.score_series（与 engine.backtest.ScoreStrategy 一致）
- 成本：佣金万3 + 滑点千1，买卖双向
- 'valid' 选股 = 点内有效性(只用决策日之前数据)，不再用全历史验证标签
"""
import sys
sys.path.insert(0, 'D:/Projects/quant-web/backend')
import numpy as np
import pandas as pd
from engine.data import _read_csv, _csv_path
from engine.config import POOL
from research_common import score_series, pit_valid, buy_lot, sell_proceeds

# ============ 1. 加载数据 + 预计算分数 ============
print('加载数据并预计算分数...')
all_data = {}
all_scores = {}
closes = {}
for name, info in POOL.items():
    code = info['code']
    df = _read_csv(_csv_path('tencent', code))
    if len(df) < 100:
        continue
    df = df.reset_index(drop=True)
    all_data[code] = df
    all_scores[code] = score_series(df)
    closes[code] = pd.Series(
        df['close'].values,
        index=pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d'))

# ============ 2. 构建面板 ============
all_dates = set()
for code, df in all_data.items():
    all_dates.update(pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d'))
dates = sorted(all_dates)
close_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
score_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
for code, df in all_data.items():
    dstr = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
    close_panel.loc[dstr, code] = df['close'].values
    sc = all_scores[code]
    sc_idx = sc.index.strftime('%Y-%m-%d')
    score_panel.loc[sc_idx, code] = sc.values
print(f'  对齐后日期: {len(dates)} 天')

# ============ 3. 回测函数（支持市场温度过滤） ============
def rotation_with_market_filter(select_mode='valid', rebalance=20, topn=8,
                                start='2016-01-01', temp_filter=False):
    """
    temp_filter=True 时，用市场温度(全池当日平均分)决定仓位：
      当日平均分 > 60 → 满仓；40 ~ 60 → 半仓；< 40 → 空仓
    每20天调仓日评估温度并调整。全部交易计佣金+滑点。
    """
    start_idx = next((i for i, d in enumerate(dates) if d >= start), 0)
    sub_dates = dates[start_idx:]
    n_days = len(sub_dates)
    if n_days < 100:
        return None

    equity = 100000.0
    holdings = []  # (code, shares)
    nav = np.zeros(n_days)
    rebal_days = set(range(0, n_days, rebalance))

    for j, d in enumerate(sub_dates):
        if j in rebal_days:
            scores_today = score_panel.loc[d]
            close_today = close_panel.loc[d]
            available = {}
            avg_scores = []
            for code in all_data.keys():
                sc = scores_today[code]
                px = close_today[code]
                if not np.isnan(sc) and not np.isnan(px) and px > 0:
                    available[code] = (sc, px)
                    avg_scores.append(sc)
            market_temp = np.mean(avg_scores) if avg_scores else 50

            position_ratio = 1.0
            if temp_filter:
                if market_temp > 60:
                    position_ratio = 1.0
                elif market_temp >= 40:
                    position_ratio = 0.5
                else:
                    position_ratio = 0.0  # 空仓

            # 卖出全部（计成本）
            for code, sh in holdings:
                px = close_panel.loc[d, code]
                if not np.isnan(px):
                    equity += sell_proceeds(sh, float(px))
            holdings = []

            # 选股
            if available and position_ratio > 0:
                if select_mode == 'valid':
                    valid = [c for c in available if pit_valid(closes[c], d)]
                    if len(valid) >= 3:
                        selected = sorted(valid, key=lambda c: -available[c][0])[:topn]
                    else:
                        selected = sorted(available.keys(), key=lambda c: -available[c][0])[:topn]
                elif select_mode == 'rank':
                    selected = sorted(available.keys(), key=lambda c: -available[c][0])[:topn]
                else:
                    selected = list(available.keys())
                invest_cap = equity * position_ratio
                if selected and invest_cap > 0:
                    per = invest_cap / len(selected)
                    for code in selected:
                        px = available[code][1]
                        sh, spend = buy_lot(per, float(px))
                        if sh > 0:
                            holdings.append((code, sh))
                            equity -= spend
        # 估值
        mv = equity
        for code, sh in holdings:
            px = close_panel.loc[d, code]
            if not np.isnan(px):
                mv += sh * float(px)
        nav[j] = mv

    nav = pd.Series(nav, index=sub_dates)
    total = (nav.iloc[-1] / nav.iloc[0] - 1) * 100
    years = (pd.Timestamp(sub_dates[-1]) - pd.Timestamp(sub_dates[0])).days / 365
    annual = ((nav.iloc[-1] / nav.iloc[0]) ** (1 / years) - 1) * 100 if years > 0 and nav.iloc[0] > 0 else 0
    r = nav.pct_change().dropna()
    sharpe = (r.mean() / r.std()) * np.sqrt(252) if r.std() > 0 else 0
    mdd = float(((nav / nav.cummax()) - 1).min() * 100)
    return {'total': total, 'annual': annual, 'sharpe': sharpe, 'mdd': mdd,
            'years': years, 'n_days': n_days}

# ============ 4. 对比：有/无 温度过滤 ============
print()
print('=' * 70)
print('  市场温度择时过滤 效果验证（点内验证有效Top8轮动，含成本）')
print('=' * 70)
print('  提示: 结果已含佣金万3+滑点千1；valid 为点内有效性(无未来标签)')
print()

for start in ['2016-01-01', '2018-01-01', '2020-01-01', '2021-01-01', '2023-01-01']:
    r_no = rotation_with_market_filter('valid', 20, 8, start, temp_filter=False)
    r_yes = rotation_with_market_filter('valid', 20, 8, start, temp_filter=True)
    if not r_no:
        continue
    print(f'[ {start} 起, {r_no["years"]:.1f}年 ]')
    print(f'  无温度过滤(满仓穿越): 总 {r_no["total"]:+7.1f}%  年化 {r_no["annual"]:+6.1f}%  夏普 {r_no["sharpe"]:5.2f}  回撤 {r_no["mdd"]:6.1f}%')
    print(f'  温度过滤(熊市降仓)  : 总 {r_yes["total"]:+7.1f}%  年化 {r_yes["annual"]:+6.1f}%  夏普 {r_yes["sharpe"]:5.2f}  回撤 {r_yes["mdd"]:6.1f}%')
    print()
