# -*- coding: utf-8 -*-
"""全历史动态轮动回测 — 高效版（口径已对齐主引擎）
- 评分/tq 阈值：research_common.score_series（与 engine.backtest.ScoreStrategy 一致）
- 成本：佣金万3 + 滑点千1，买卖双向（engine.config.TRADING）
- 选股模式 'valid' = 点内有效性(只用决策日之前的数据，近1年年化夏普>0.3)，
  替代旧实现用“2026 全历史验证标签”筛 2016 年标的（幸存者偏差）
- 注意：评分不含资金流因子 → 研究口径，与实盘(含资金流)不完全等同
"""
import sys
sys.path.insert(0, 'D:/Projects/quant-web/backend')
import numpy as np
import pandas as pd
from engine.data import _read_csv, _csv_path
from engine.config import POOL
from research_common import score_series, pit_valid, buy_lot, sell_proceeds

# ============ 1. 一次性读入所有数据 + 预计算分数 ============
print('加载数据并预计算分数（评分口径与主引擎一致，不含资金流因子）...')
all_data = {}      # code -> df(全历史)
all_scores = {}    # code -> Series(date -> score)
closes = {}        # code -> Series('YYYY-MM-DD' -> close)，供点内验证
for name, info in POOL.items():
    code = info['code']
    df = _read_csv(_csv_path('tencent', code))
    if len(df) < 100:
        continue
    df = df.reset_index(drop=True)
    all_data[code] = df
    all_scores[code] = score_series(df)
    closes[code] = pd.Series(
        df['close'].values,
        index=pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d'))

print(f'  有效标的: {len(all_data)} 只')

# ============ 2. 高效轮动回测 ============
def build_panel():
    """构建对齐面板: 所有标的的 close / score / date"""
    all_dates = set()
    for code, df in all_data.items():
        all_dates.update(pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d'))
    dates = sorted(all_dates)
    close_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
    score_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
    for code, df in all_data.items():
        dstr = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
        close_panel.loc[dstr, code] = df['close'].values
        sc = all_scores[code]
        sc_idx = sc.index.strftime('%Y-%m-%d')
        score_panel.loc[sc_idx, code] = sc.values
    return dates, close_panel, score_panel

dates, close_panel, score_panel = build_panel()
print(f'  对齐后日期: {len(dates)} 天 ({dates[0]} ~ {dates[-1]})')

def dynamic_rotation(select_mode, rebalance=20, topn=8, start='2016-01-01'):
    """select_mode: 'valid'=点内验证有效TopN, 'rank'=纯评分TopN, 'pool'=全池等权
    全部交易计佣金(万3)+滑点(千1)。"""
    start_idx = next((i for i, d in enumerate(dates) if d >= start), 0)
    sub_dates = dates[start_idx:]
    n_days = len(sub_dates)
    if n_days < 100:
        return None

    equity = 100000.0   # 现金+持仓市值合计（调仓日全部先清算为现金）
    holdings = []       # list of (code, shares)
    nav = np.zeros(n_days)
    rebal_days = set(range(0, n_days, rebalance))

    for j, d in enumerate(sub_dates):
        if j in rebal_days:
            scores_today = score_panel.loc[d]
            close_today = close_panel.loc[d]
            available = {}
            for code in all_data.keys():
                sc = scores_today[code]
                px = close_today[code]
                if not np.isnan(sc) and not np.isnan(px) and px > 0:
                    available[code] = (sc, px)
            # 卖出全部（计成本）
            for code, sh in holdings:
                px = close_panel.loc[d, code]
                if not np.isnan(px):
                    equity += sell_proceeds(sh, float(px))
            holdings = []
            # 选股
            if available:
                if select_mode == 'valid':
                    valid = [c for c in available if pit_valid(closes[c], d)]
                    if len(valid) >= 3:
                        selected = sorted(valid, key=lambda c: -available[c][0])[:topn]
                    else:
                        selected = sorted(available.keys(), key=lambda c: -available[c][0])[:topn]
                elif select_mode == 'rank':
                    selected = sorted(available.keys(), key=lambda c: -available[c][0])[:topn]
                else:  # pool 全池等权
                    selected = list(available.keys())
                if selected:
                    per = equity / len(selected)
                    for code in selected:
                        px = available[code][1]
                        sh, spend = buy_lot(per, float(px))
                        if sh > 0:
                            holdings.append((code, sh))
                            equity -= spend
        # 估值
        mv = equity
        for code, sh in holdings:
            px = close_panel.loc[d, code]
            if not np.isnan(px):
                mv += sh * float(px)
        nav[j] = mv

    nav = pd.Series(nav, index=sub_dates)
    total = (nav.iloc[-1] / nav.iloc[0] - 1) * 100
    years = (pd.Timestamp(sub_dates[-1]) - pd.Timestamp(sub_dates[0])).days / 365
    annual = ((nav.iloc[-1] / nav.iloc[0]) ** (1 / years) - 1) * 100 if years > 0 and nav.iloc[0] > 0 else 0
    r = nav.pct_change().dropna()
    sharpe = (r.mean() / r.std()) * np.sqrt(252) if r.std() > 0 else 0
    mdd = float(((nav / nav.cummax()) - 1).min() * 100)
    return {'total': total, 'annual': annual, 'sharpe': sharpe, 'mdd': mdd,
            'years': years, 'n_days': n_days}

# ============ 3. 跑多起点对比 ============
print()
print('=' * 66)
print('  全历史动态轮动回测（含佣金万3+滑点千1；valid=点内验证Top8）')
print('=' * 66)
print('  提示: 与旧版本地对比时注意两点——(1)已计全部成本; (2)valid 不再用未来标签')
print()

for start in ['2016-01-01', '2018-01-01', '2020-01-01', '2021-01-01', '2023-01-01']:
    r_sys = dynamic_rotation('valid', 20, 8, start)
    r_rank = dynamic_rotation('rank', 20, 8, start)
    r_pool = dynamic_rotation('pool', 20, 8, start)
    if not r_sys:
        continue
    print(f'[ {start} 起, {r_sys["years"]:.1f}年 ]')
    print(f'  点内有效Top8 (含成本) : 总收益 {r_sys["total"]:+7.1f}%  年化 {r_sys["annual"]:+6.1f}%  夏普 {r_sys["sharpe"]:5.2f}  回撤 {r_sys["mdd"]:6.1f}%')
    print(f'  纯评分Top8   (含成本) : 总收益 {r_rank["total"]:+7.1f}%  年化 {r_rank["annual"]:+6.1f}%  夏普 {r_rank["sharpe"]:5.2f}  回撤 {r_rank["mdd"]:6.1f}%')
    print(f'  全池等权     (含成本) : 总收益 {r_pool["total"]:+7.1f}%  年化 {r_pool["annual"]:+6.1f}%  夏普 {r_pool["sharpe"]:5.2f}  回撤 {r_pool["mdd"]:6.1f}%')
    print()

print('完成。')
