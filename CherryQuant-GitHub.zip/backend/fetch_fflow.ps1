# 拉取 20 只池内 ETF 资金流日数据（东财 push2his fflow，接口仅提供约120天）
# 输出: data/cache/fflow/<code>.csv（与 engine/fflow.py 同格式，供实盘直接读取）
$ErrorActionPreference = 'Stop'
$outDir = 'D:\Projects\quant-web\data\cache\fflow'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$ua = @{ 'User-Agent' = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'; 'Referer' = 'https://quote.eastmoney.com/' }
$codes = @('516650','159558','159530','159857','159611','512660','159828','560680','513010','560390','159227','589130','588170','562510','516080','513120','512010','518850','515880','515230')
$ok = 0
foreach ($code in $codes) {
    $secid = if ($code.StartsWith('5')) { "1.$code" } else { "0.$code" }
    $u = "https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get?lmt=1500&klt=101&secid=$secid&fields1=f1,f2,f3,f7&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63"
    $done = $false
    for ($try = 1; $try -le 5 -and -not $done; $try++) {
        try {
            $r = Invoke-RestMethod -Uri $u -Headers $ua -TimeoutSec 30
            $kl = $r.data.klines
            if ($kl) {
                $lines = @('date,main_net,small_net,mid_net,big_net,super_net,main_pct,small_pct,mid_pct,big_pct,super_pct,close,pct_chg')
                foreach ($row in $kl) {
                    $p = $row.Split(',')
                    $lines += ($p -join ',')
                }
                [System.IO.File]::WriteAllLines((Join-Path $outDir "$code.csv"), $lines, [System.Text.Encoding]::UTF8)
                "{0} OK rows={1} first={2} last={3}" -f $code, $kl.Count, $kl[0].Split(',')[0], $kl[-1].Split(',')[0]
                $ok++
                $done = $true
            } else { "{0} EMPTY try{1}" -f $code, $try; Start-Sleep -Seconds 10 }
        } catch { "{0} ERR try{1}: {2}" -f $code, $try, $_.Exception.Message; Start-Sleep -Seconds 10 }
    }
    Start-Sleep -Seconds 4
}
"成功 $ok / $($codes.Count)"
