# -*- coding: utf-8 -*-
"""刷新验证报告 — 用最新全历史数据重跑全池阈值优化+样本外验证
生成 data/optimize_report_new.json（verify.py 读取的来源）
"""
import sys
sys.path.insert(0, 'D:/Projects/quant-web/backend')
import json
import time
from datetime import datetime

from engine.backtest import find_best_thresholds
from engine.config import POOL


def main():
    print(f'=== 刷新验证报告 @ {datetime.now().strftime("%Y-%m-%d %H:%M:%S")} ===')
    print('口径: 统一评分因子(资金流+板块+长期) + 统一下一开盘风控 + 测试期260根预热')
    print()

    results = []
    t0 = time.time()
    for i, (name, info) in enumerate(POOL.items()):
        code = info["code"]
        t1 = time.time()
        try:
            r = find_best_thresholds(code, test_ratio=0.3, enable_risk=True)
            if r is None:
                print(f'  [{i+1}/20] {name} {code}: 数据不足')
                results.append({"code": code, "name": name, "test_sharpe": None,
                                "total_return": None, "note": "数据不足"})
                continue
            from engine.data import fetch as _fetch
            try:
                _df = _fetch(code, offline=True)
                data_asof = str(_df["date"].iloc[-1])[:10] if len(_df) else ""
            except Exception:
                data_asof = ""
            ev = r.get("evaluation") or {}
            results.append({
                "code": code, "name": name,
                "buy_th": r["buy_th"], "sell_th": r["sell_th"],
                "test_sharpe": r["test"].get("sharpe"),
                "test_return": r["test"].get("total_return"),
                "train_sharpe": r["train"].get("sharpe"),
                "train_return": r["train"].get("total_return"),
                "total_return": r["all"].get("total_return"),
                "score_config": r.get("score_config"),
                "evaluation": ev,
                "data_asof": data_asof,
                "n_days": None,
            })
            ts = r["test"].get("sharpe")
            if ev.get("insufficient"):
                verdict = "⚠评估不足"
            else:
                verdict = "✅有效" if (ts or 0) > 0.5 else ("⚠️一般" if (ts or 0) > 0 else "❌无效")
            print(f'  [{i+1}/20] {name} {code}: BUY{r["buy_th"]}/SELL{r["sell_th"]} '
                  f'测试夏普={ts} {verdict} ({time.time()-t1:.1f}s)')
        except Exception as e:
            print(f'  [{i+1}/20] {name} {code}: 失败 {type(e).__name__}: {e}')
            results.append({"code": code, "name": name, "test_sharpe": None,
                            "total_return": None, "note": str(e)})

    _asof = [r.get("data_asof") for r in results if r.get("data_asof")]
    report = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "data_asof": max(_asof) if _asof else "",
        "method": ("全历史样本外验证：前70%训练/后30%测试；测试期带260根指标预热"
                   "（覆盖250日长期因子）、只在测试区间计收益；评分因子与线上统一；风控与线上统一"),
        "n_results": len(results),
        "results": results,
    }

    out = 'D:/Projects/quant-web/data/optimize_report_new.json'
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    print()
    print(f'=== 完成: {len(results)} 只, 总耗时 {time.time()-t0:.1f}s ===')
    print(f'报告已写入: {out}')

    # 汇总
    valid = sum(1 for r in results if (r.get("test_sharpe") or 0) > 0.5)
    weak = sum(1 for r in results if 0 < (r.get("test_sharpe") or 0) <= 0.5)
    invalid = sum(1 for r in results if (r.get("test_sharpe") or 0) <= 0)
    print(f'验证结果: 有效{valid} / 一般{weak} / 无效{invalid} / 无数据{len(results)-valid-weak-invalid}')


if __name__ == '__main__':
    main()
