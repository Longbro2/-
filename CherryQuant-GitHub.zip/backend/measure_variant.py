# -*- coding: utf-8 -*-
"""输出指定变体全指标（供 BT_SNAPSHOT 取数）"""
import sys
sys.path.insert(0, 'D:/Projects/quant-web/backend')
import numpy as np
import pandas as pd
from engine.data import _read_csv, _csv_path
from engine.config import POOL
from research_common import score_series, pit_valid, buy_lot, sell_proceeds

SELECT, TOPN, TEMP, REBAL = 'pit', 5, True, 40

all_data, all_scores, closes = {}, {}, {}
for name, info in POOL.items():
    code = info['code']
    df = _read_csv(_csv_path('tencent', code))
    if len(df) < 100:
        continue
    all_data[code] = df
    all_scores[code] = score_series(df)
    closes[code] = pd.Series(df['close'].values,
                             index=pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d'))
all_dates = set()
for s in all_scores.values():
    all_dates.update(s.index.strftime('%Y-%m-%d'))
dates = sorted(all_dates)
close_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
score_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
for code, df in all_data.items():
    dstr = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
    close_panel.loc[dstr, code] = df['close'].values
    sc = all_scores[code]
    score_panel.loc[sc.index.strftime('%Y-%m-%d'), code] = sc.values


def run(start):
    s_idx = next((i for i, d in enumerate(dates) if d >= start), 0)
    sub = dates[s_idx:]
    n = len(sub)
    equity = 100000.0
    holdings = {}
    nav = np.zeros(n)
    for j, d in enumerate(sub):
        if j % REBAL == 0:
            st, ct = score_panel.loc[d], close_panel.loc[d]
            available, avg = {}, []
            for code in all_data.keys():
                sc, px = st[code], ct[code]
                if not np.isnan(sc) and not np.isnan(px) and px > 0:
                    available[code] = (sc, px)
                    avg.append(sc)
            temp = float(np.mean(avg)) if avg else 50.0
            ratio = 1.0 if temp > 60 else (0.5 if temp >= 40 else 0.0)
            for code, sh in holdings.items():
                px = close_panel.loc[d, code]
                if not np.isnan(px):
                    equity += sell_proceeds(sh, float(px))
            holdings = {}
            if available and ratio > 0:
                cand = [c for c in available if pit_valid(closes[c], d)]
                sel = sorted(cand, key=lambda c: -available[c][0])[:TOPN] if len(cand) >= 3 \
                    else sorted(available.keys(), key=lambda c: -available[c][0])[:TOPN]
                invest = equity * ratio
                if sel and invest > 0:
                    per = invest / len(sel)
                    for code in sel:
                        px = available[code][1]
                        sh, spend = buy_lot(per, float(px))
                        if sh > 0:
                            holdings[code] = sh
                            equity -= spend
        mv = equity
        for code, sh in holdings.items():
            px = close_panel.loc[d, code]
            if not np.isnan(px):
                mv += sh * float(px)
        nav[j] = mv
    nav = pd.Series(nav, index=sub)
    total = (nav.iloc[-1] / nav.iloc[0] - 1) * 100
    years = (pd.Timestamp(sub[-1]) - pd.Timestamp(sub[0])).days / 365
    annual = ((nav.iloc[-1] / nav.iloc[0]) ** (1 / years) - 1) * 100 if years > 0 and nav.iloc[0] > 0 else 0
    r = nav.pct_change().dropna()
    sharpe = (r.mean() / r.std()) * np.sqrt(252) if r.std() > 0 else 0
    mdd = float(((nav / nav.cummax()) - 1).min() * 100)
    print(f"{start}: 总{total:+.1f}% 年化{annual:+.1f}% 夏普{sharpe:.2f} 回撤{mdd:.1f}% ({years:.1f}年)")


for s in ['2018-01-01', '2021-01-01', '2023-01-01']:
    run(s)
