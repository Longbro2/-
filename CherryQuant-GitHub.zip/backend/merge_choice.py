# -*- coding: utf-8 -*-
"""
Choice 历史数据补齐合并脚本
把桌面 Choice Excel 的历史数据合并进 quant-web 系统缓存，补齐早期历史。

两种格式:
  A) 13列 OHLCV: 证券代码/名称/交易时间/开盘/最高/最低/收盘/涨跌/涨跌幅/成交量/成交额/盘后量/盘后额
     → 真实 OHLC，volume 列9
  B) 6列 净值: 证券代码/名称/交易时间/净值/涨跌/涨跌幅%
     → 只有净值(收盘)，无真实 OHLC，high/low 用 ±0.5% 估算，volume=0

合并策略:
  - 只取系统缓存缺失的历史段（choice 数据起始日 < 系统缓存起始日 的部分）
  - 保留系统缓存的 8/4 最新数据
  - 真实 OHLCV(格式A) 直接合并；净值(格式B) 估算 OHLC 后合并，标注来源
"""
import sys
import glob
import re
from pathlib import Path

sys.path.insert(0, "D:/Projects/quant-web/backend")

import pandas as pd
from engine import data
from engine.config import EASTMONEY_DIR, POOL

DESKTOP = Path.home() / "Desktop"
FILES = sorted(Path(p) for p in glob.glob(str(DESKTOP / "K线导出_*_日线数据.xlsx")))


def load_choice_excel(path: Path) -> dict:
    """解析 Choice Excel，返回 {code, df, fmt}"""
    code = re.search(r"(\d{6})", path.name).group(1)
    raw = pd.read_excel(path, header=None)
    n_cols = raw.shape[1]

    if n_cols >= 13:
        # 格式 A: 真实 OHLCV，用表头定位列
        header_row = 0
        col_map = {}
        for r in range(min(2, len(raw))):
            row = raw.iloc[r]
            for i, v in enumerate(row):
                if pd.isna(v):
                    continue
                col_map[str(v).strip()] = i
            if "开盘价" in col_map:
                header_row = r
                break
        d = pd.to_datetime(raw.iloc[header_row + 1:, col_map.get("交易时间", 2)], errors="coerce")
        o = pd.to_numeric(raw.iloc[header_row + 1:, col_map["开盘价"]], errors="coerce")
        h = pd.to_numeric(raw.iloc[header_row + 1:, col_map["最高价"]], errors="coerce")
        l = pd.to_numeric(raw.iloc[header_row + 1:, col_map["最低价"]], errors="coerce")
        c = pd.to_numeric(raw.iloc[header_row + 1:, col_map["收盘价"]], errors="coerce")
        v = pd.to_numeric(raw.iloc[header_row + 1:, col_map.get("成交量", 9)], errors="coerce")
        df = pd.DataFrame({"date": d, "open": o, "high": h, "low": l, "close": c, "volume": v})
        df = df.dropna(subset=["date", "close"]).reset_index(drop=True)
        df["volume"] = df["volume"].fillna(0)
        return {"code": code, "df": df, "fmt": "ohlcv"}

    # 检查表头：找日期列（日期/交易时间）和净值/收盘列
    header_row = None
    date_col, close_col = None, None
    for r in range(min(4, len(raw))):
        row = raw.iloc[r]
        for i, v in enumerate(row):
            if pd.isna(v):
                continue
            s = str(v).strip()
            if s in ("日期", "交易时间"):
                date_col = i
            elif s in ("净值", "收盘价", "收盘"):
                close_col = i
        if date_col is not None:
            header_row = r
            # 若只有日期列找不到净值列，尝试日期旁边最近的数值列
            if close_col is None:
                for probe in range(min(3, raw.shape[1])):
                    # 日期列之后找一个能转数值的列作为净值
                    cand = date_col + 1 + probe if date_col + 1 + probe < raw.shape[1] else None
                    if cand is None:
                        break
                    sample = raw.iloc[header_row + 1, cand]
                    try:
                        float(sample)
                        close_col = cand
                        break
                    except (TypeError, ValueError):
                        continue
            break

    if date_col is not None and close_col is not None:
        # 格式 B: 6列净值 或 3列日期/净值/基准
        d = pd.to_datetime(raw.iloc[header_row + 1:, date_col], errors="coerce")
        c = pd.to_numeric(raw.iloc[header_row + 1:, close_col], errors="coerce")
        df = pd.DataFrame({"date": d, "close": c}).dropna(subset=["date", "close"]).reset_index(drop=True)
        df["open"] = df["close"].shift(1).fillna(df["close"])
        df["high"] = df[["open", "close"]].max(axis=1) * 1.005
        df["low"] = df[["open", "close"]].min(axis=1) * 0.995
        df["volume"] = 0
        return {"code": code, "df": df, "fmt": "nav"}

    raise ValueError(f"无法识别格式 (列数={n_cols})")


def main():
    print("=" * 60)
    print("  Choice 历史数据补齐合并")
    print("=" * 60)

    merged_count = 0
    skipped = []

    for path in FILES:
        try:
            parsed = load_choice_excel(path)
            code = parsed["code"]
            choice_df = parsed["df"]
            fmt = parsed["fmt"]

            # 系统当前缓存（取 eastmoney 作为主缓存）
            cur = data._read_csv(EASTMONEY_DIR / f"{code}.csv")

            if len(cur) == 0:
                print(f"  [跳过] {code} 系统无缓存")
                skipped.append(code)
                continue

            cur_start = cur["date"].min()
            cur_end = cur["date"].max()
            choice_start = choice_df["date"].min()
            choice_end = choice_df["date"].max()

            # 只取 Choice 比系统更早的部分
            hist = choice_df[choice_df["date"] < cur_start].copy()
            if len(hist) == 0:
                print(f"  [跳过] {code} Choice({choice_start:%Y-%m-%d}~{choice_end:%Y-%m-%d}) 不早于系统({cur_start:%Y-%m-%d})")
                skipped.append(code)
                continue

            # 合并: 历史 + 当前，去重
            combined = pd.concat([hist, cur], ignore_index=True)
            combined = combined.drop_duplicates(subset="date").sort_values("date").reset_index(drop=True)

            # 写回 eastmoney 缓存
            data._write_csv(EASTMONEY_DIR / f"{code}.csv", combined)

            # 更新元数据
            last_date = combined["date"].iloc[-1].strftime("%Y-%m-%d")
            data.upsert_meta(code, POOL.get(code, {}).get("code", code), "eastmoney+choice",
                             last_date, len(combined))

            print(f"  [OK] {code} {fmt:5s} 历史{len(hist):>4d}行 + 当前{len(cur):>4d}行 = {len(combined):>4d}行 "
                  f"({combined['date'].iloc[0]:%Y-%m-%d} ~ {last_date})")
            merged_count += 1

        except Exception as e:
            print(f"  [错误] {path.name}: {e}")
            skipped.append(path.name)

    print()
    print(f"完成: 合并 {merged_count} 只, 跳过 {len(skipped)} 只")
    if skipped:
        print(f"跳过列表: {skipped}")


if __name__ == "__main__":
    main()
