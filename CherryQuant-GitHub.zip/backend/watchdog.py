# -*- coding: utf-8 -*-
"""
CherryQuant 服务守护脚本
- 检查 127.0.0.1:8000 是否在监听 + /api/health 是否正常
- 未运行 → 自动拉起；假死（端口占用但无响应）→ 强杀后重启
- 由 Windows 计划任务每 5 分钟调用一次（也可手动运行）
用法: python backend/watchdog.py
"""
import os
import socket
import subprocess
import sys
import time
import urllib.request
from datetime import datetime

BASE = r"D:\Projects\quant-web"
LOG = os.path.join(BASE, "data", "watchdog.log")
SERVER_LOG = os.path.join(BASE, "server.log")
PY = sys.executable
PORT = 8000
UVICORN_ARGS = [PY, "-X", "utf8", "-m", "uvicorn", "main:app",
                "--app-dir", "backend", "--host", "127.0.0.1", "--port", str(PORT)]


def log(msg: str):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")
    except Exception:
        pass


def port_listening() -> bool:
    s = socket.socket()
    s.settimeout(2)
    try:
        s.connect(("127.0.0.1", PORT))
        return True
    except OSError:
        return False
    finally:
        s.close()


def healthy() -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/api/health", timeout=6) as r:
            return r.status == 200
    except Exception:
        return False


def pids_on_port() -> list:
    """通过 netstat 找占用端口的进程号（不依赖 psutil）"""
    pids = []
    try:
        out = subprocess.run(["netstat", "-ano"], capture_output=True, text=True,
                             encoding="utf-8", errors="ignore", timeout=15).stdout
        for line in out.splitlines():
            if f":{PORT}" in line and "LISTENING" in line:
                parts = line.split()
                if parts and parts[-1].isdigit():
                    pids.append(parts[-1])
    except Exception:
        pass
    return list(dict.fromkeys(pids))  # 去重保序


def start_server():
    flags = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    with open(SERVER_LOG, "a", encoding="utf-8") as out:
        subprocess.Popen(UVICORN_ARGS, cwd=BASE, creationflags=flags,
                         stdout=out, stderr=subprocess.STDOUT, close_fds=True)


def main():
    if not port_listening():
        start_server()
        log("未运行 -> 已自动拉起")
        return
    if healthy():
        return  # 正常，静默返回（不写日志，避免刷屏）
    # 端口在监听但健康检查失败 → 假死，强杀后重启
    for pid in pids_on_port():
        subprocess.run(["taskkill", "/F", "/PID", pid],
                       capture_output=True, text=True, timeout=15)
    time.sleep(2)
    start_server()
    log("假死 -> 已强制重启")


if __name__ == "__main__":
    main()
