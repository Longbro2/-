# -*- coding: utf-8 -*-
"""CherryQuant 系统全流程验证脚本 — 端到端跑一遍所有核心 API"""
import json, sys, time, traceback
import requests

BASE = "http://127.0.0.1:8000"
passed, failed, warns = [], [], []

def call(name, path, params=None, timeout=30, extract=None):
    t0 = time.time()
    try:
        r = requests.get(BASE + path, params=params, timeout=timeout)
        dt = round(time.time() - t0, 2)
        if r.status_code != 200:
            failed.append((name, f"HTTP {r.status_code}", dt))
            return None
        d = r.json()
        if isinstance(d, dict) and d.get("error"):
            failed.append((name, f"业务错误: {d['error']}", dt))
            return None
        # 提取摘要
        if extract:
            summary = extract(d)
            passed.append((name, summary, dt))
        else:
            passed.append((name, f"OK ({len(d) if isinstance(d,(list,dict)) else '?'} 项)", dt))
        return d
    except Exception as e:
        failed.append((name, f"异常: {type(e).__name__}: {e}", round(time.time()-t0,2)))
        traceback.print_exc()
        return None

print("=" * 72)
print("  CherryQuant V5.2 — 系统全流程验证")
print("=" * 72)

# ── 0. 基础 ──
d = call("健康检查", "/api/health", extract=lambda d: f"v{d['version']} migrated={d['migrated']}")

# ── 1. 数据层 ──
d = call("数据状态", "/api/data/status", extract=lambda d:
    f"{len(d['items'])}只, 新鲜{sum(1 for i in d['items'] if i.get('fresh'))}只" if d else "")
d = call("有效池", "/api/signals/valid-pool", extract=lambda d:
    f"{len(d.get('valid_pool', []))}只验证有效" if d else "")

# ── 2. 信号层 ──
d = call("市场温度", "/api/signals/market", timeout=60, extract=lambda d:
    f"温度{d.get('temp')}% BUY{d.get('buy')} SELL{d.get('sell')} HOLD{d.get('hold')} [{d.get('status')}]" if d else "")
d = call("全池扫描", "/api/signals/scan", timeout=90, extract=lambda d:
    f"{len(d.get('signals', []))}条信号" if d else "")
d = call("交易指令", "/api/signals/trade-orders", timeout=60, extract=lambda d:
    f"{len(d.get('orders', []))}条指令" if d else "")

# ── 3. 组合回测（本次核心）──
d = call("组合回测", "/api/backtest/portfolio", params={"capital": 100000, "buy_th": 45, "sell_th": 25},
         timeout=90, extract=lambda d:
    f"{d['n_holdings']}只/{d['n_days']}天 收益{d['portfolio_return']}% 夏普{d['portfolio_sharpe']} "
    f"回撤{d['portfolio_max_dd']}% | 基准{d['benchmark_return']}% α{d['alpha']}%")

# ── 4. 单标的回测 ──
d = call("策略对比(有色)", "/api/backtest/compare/516650", timeout=60, extract=lambda d:
    f"{len(d['results'])}个策略 最优[{d['results'][0]['strategy']} 夏普{d['results'][0]['sharpe']}]" if d else "")
d = call("阈值优化(有色)", "/api/backtest/optimize/516650", timeout=120, extract=lambda d:
    f"BUY{d.get('buy_th')}/SELL{d.get('sell_th')} 测试夏普{d.get('test',{}).get('sharpe')}" if d else "")

# ── 5. 账户层 ──
d = call("持仓", "/api/portfolio/positions", timeout=30, extract=lambda d:
    f"{len(d.get('positions', d.get('items', [])))}只" if d else "")
d = call("风控检查", "/api/portfolio/risk", timeout=30, extract=lambda d:
    f"{d.get('status', d.get('msg', 'OK'))}" if d else "")
d = call("成交记录", "/api/portfolio/trades", timeout=30, extract=lambda d:
    f"{len(d.get('trades', d.get('items', [])))}笔" if d else "")

# ── 6. 宏观层 ──
d = call("宏观总览", "/api/macro/overview", timeout=30, extract=lambda d:
    f"{len(d.get('items', d))}项" if d else "")
d = call("宏观事件", "/api/macro/events", timeout=30, extract=lambda d:
    f"{len(d.get('events', d.get('items', [])))}事件" if d else "")

# ── 7. ML 层 ──
d = call("ML信号", "/api/ml/signals", timeout=60, extract=lambda d:
    f"{len(d.get('signals', d.get('items', [])))}条" if d else "")

# ── 8. 摘要层 ──
d = call("今日摘要", "/api/summary/daily", timeout=60, extract=lambda d:
    f"{len(d)}节" if d else "")

# ── 汇总 ──
print()
print("=" * 72)
print("  验证结果汇总")
print("=" * 72)
print(f"  ✅ 通过: {len(passed)} 项    ❌ 失败: {len(failed)} 项")
print()
for name, summary, dt in passed:
    print(f"  ✅ {name:<12} {summary}  ({dt}s)")
if failed:
    print()
    for name, msg, dt in failed:
        print(f"  ❌ {name:<12} {msg}  ({dt}s)")
print()
sys.exit(1 if failed else 0)
