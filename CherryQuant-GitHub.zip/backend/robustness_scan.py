# -*- coding: utf-8 -*-
"""
参数稳健性扫描（诚实区间展示，不选优）
- 复用 long_history_backtest 的引擎（T+1开盘成交/含成本/止损/点内有效）
- 扫描: TopN ∈ {3,5} × 调仓 ∈ {10,20,40} × 温度 {关,开} = 12 组 × 3 窗口
- 目的: 看结果对参数的敏感度, 识别"只有一个参数组合赚钱"的过拟合陷阱
用法: python backend/robustness_scan.py
"""
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import long_history_backtest as lb  # noqa: E402

STARTS = ["2018-01-01", "2021-01-01", "2023-01-01"]

print(f"{'起点':<12} {'TopN':>4} {'调仓':>4} {'温度':>4} | {'总收益%':>8} {'年化%':>7} {'夏普':>6} {'回撤%':>7} {'vs等权pp':>8}")
print("-" * 84)
results = []
for start in STARTS:
    b = lb.run_pool(start)
    if b is None:
        continue
    eqb, dtb = b
    tb, ab, shb, mb = lb.metrics(eqb, dtb)
    for topn in (3, 5):
        lb.TOP_N = topn
        for rebal in (10, 20, 40):
            lb.REBAL = rebal
            for temp in (False, True):
                r = lb.run_system(start, temp=temp)
                if r is None:
                    continue
                eq, dt, stops = r
                t, a, sh, m = lb.metrics(eq, dt)
                results.append({"start": start, "topn": topn, "rebal": rebal,
                                "temp": temp, "t": t, "a": a, "sh": sh, "m": m})
                print(f"{start:<12} {topn:>4} {rebal:>4} {'开' if temp else '关':>4} | "
                      f"{t:>+8.1f} {a:>+7.1f} {sh:>+6.2f} {m:>+7.1f} {t-tb:>+8.1f}")
    print(f"{'全池等权':<12} {'-':>4} {'-':>4} {'-':>4} | {tb:>+8.1f} {ab:>+7.1f} {shb:>+6.2f} {mb:>+7.1f} {'0.0':>8}")
    print()

rdf = pd.DataFrame(results)
print("窗口内 12 组参数的总收益范围（稳健性直观读数）:")
for start in STARTS:
    g = rdf[rdf["start"] == start]
    if len(g) == 0:
        continue
    print(f"  {start}: 最好 {g['t'].max():+7.1f}% | 中位 {g['t'].median():+7.1f}% | "
          f"最差 {g['t'].min():+7.1f}% | 夏普范围 [{g['sh'].min():.2f}, {g['sh'].max():.2f}]")
print("\n注: 参数组合间差异大 = 对参数敏感 = 过去的'最优参数'是拟合产物; 差异小 = 策略逻辑稳健。")
