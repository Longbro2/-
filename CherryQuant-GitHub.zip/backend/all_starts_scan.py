# -*- coding: utf-8 -*-
"""
全起点扫描：从 2014 年到 2026 年，每个 1 月 1 日都作为回测起点跑一遍（只要数据够120天）。
- 复用 long_history_backtest 引擎（T+1开盘成交/含成本/止损/点内有效/温度择时）
- 目的: 不挑起点，把所有可能的时间窗口全部摊开看
用法: python backend/all_starts_scan.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import long_history_backtest as lb  # noqa: E402

print(f"{'起点':<12} {'年数':>5} | {'系统年化%':>8} {'系统夏普':>8} {'系统回撤%':>9} {'止损次':>6} | {'等权年化%':>8} {'超额年化pp':>9}")
print("-" * 84)
for year in range(2014, 2027):
    start = f"{year}-01-01"
    r = lb.run_system(start, temp=True)
    b = lb.run_pool(start)
    if r is None or b is None:
        continue
    eq, dt, stops = r
    eqb, dtb = b
    t, a, sh, m = lb.metrics(eq, dt)
    tb, ab, shb, mb = lb.metrics(eqb, dtb)
    yrs = (dt[-1] - dt[0]).days / 365.25
    n0 = sum(1 for c in lb.data if not lb.close_panel.loc[dt[0], c] != lb.close_panel.loc[dt[0], c] and lb.close_panel.loc[dt[0], c] > 0)
    print(f"{start:<12} {yrs:>5.1f} | {a:>+8.1f} {sh:>+8.2f} {m:>+9.1f} {stops:>6} | {ab:>+8.1f} {a-ab:>+9.1f}")

print("\n注: 系统=完整系统(含温度择时); 等权=全池等权同成本同调仓。空行=数据不足120天。")
