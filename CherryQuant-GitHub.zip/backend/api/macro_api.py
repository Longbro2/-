# -*- coding: utf-8 -*-
"""宏观瞭望 API：美股/商品行情 + 宏观事件 + 利好利空分析"""
from fastapi import APIRouter

from engine.macro import analyze_macro, fetch_global_markets, get_upcoming_events

router = APIRouter()


@router.get("/overview")
def overview():
    """宏观瞭望综合：外盘行情 + 事件 + 总结"""
    return analyze_macro()


@router.get("/markets")
def markets():
    """仅外盘/商品实时行情"""
    return {"markets": fetch_global_markets()}


@router.get("/events")
def events(days: int = 30):
    """临近宏观/行业事件"""
    return {"events": get_upcoming_events(days)}
