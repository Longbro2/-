# -*- coding: utf-8 -*-
"""数据管理 API：刷新、上传 Choice、缓存状态、清理"""
import re
import shutil
from pathlib import Path

from fastapi import APIRouter, Body, UploadFile, File
from pydantic import BaseModel

from engine import data
from engine.config import POOL, UPLOAD_DIR, CODE2NAME

router = APIRouter()


@router.get("/status")
def data_status():
    """全部池内 ETF 的数据状态（来源/日期/行数/新鲜度）"""
    items = data.freshness_report()
    # 补充腾讯源映射（freshness_report 内已按 eastmoney→akshare→tencent→choice 探测）
    return {"items": items}


@router.post("/refresh")
def refresh(force: bool = False, payload: dict = Body(None)):
    """联网刷新全部池内数据。force=True 强制覆盖缓存。
    兼容两种传参：query 的 ?force=true，或前端 JSON body {"force": ...}
    ——前端一直把 force 放 body，旧接口只认 query，导致“强制刷新”从未真正生效。"""
    if payload and payload.get("force") is not None:
        force = bool(payload["force"])
    result = data.refresh_all(force=force)
    # 第 23 项：行情已变更 → 使派生扫描缓存失效（显式刷新必须拿到新建议）
    try:
        from engine.signals import invalidate_scan_cache
        invalidate_scan_cache()
    except Exception:
        pass
    return result


@router.post("/fetch/{code}")
def fetch_one(code: str, force: bool = False, payload: dict = Body(None)):
    """单只拉取。兼容 query 与 JSON body 两种 force 传参（同 /refresh）。"""
    if payload and payload.get("force") is not None:
        force = bool(payload["force"])
    df = data.fetch(code, force=force)
    if len(df) == 0:
        return {"ok": False, "code": code, "msg": "获取失败"}
    return {"ok": True, "code": code,
            "name": CODE2NAME.get(code, code),
            "rows": len(df),
            "last_date": df["date"].iloc[-1].strftime("%Y-%m-%d")}


@router.post("/upload")
async def upload_choice(file: UploadFile = File(...)):
    """上传 Choice 导出的 K 线 Excel 并解析入库。"""
    fname = Path(file.filename or "").name  # 去路径成分，防目录穿越
    if not fname.lower().endswith((".xlsx", ".xls")):
        return {"ok": False, "msg": "仅支持 .xlsx/.xls 文件"}
    save_path = UPLOAD_DIR / fname
    with open(save_path, "wb") as f:
        shutil.copyfileobj(file.file, f)
    try:
        result = data.import_choice_file(save_path)
        return {"ok": True, **result}
    except Exception as e:
        return {"ok": False, "msg": f"解析失败: {e}"}


@router.delete("/cache/{code}")
def delete_cache(code: str):
    if not re.fullmatch(r"\d{6}", code or ""):
        return {"ok": False, "msg": "code 必须为 6 位数字"}
    removed = data.remove_cache(code)
    return {"ok": True, "removed": removed}


@router.post("/garbage")
def clean_garbage():
    """清理非法缓存文件（代码非6位数字）"""
    removed = data.remove_garbage()
    return {"ok": True, "removed": removed}


class PoolUpdate(BaseModel):
    name: str
    code: str
    buy_th: int = 50
    sell_th: int = 30


@router.get("/pool")
def get_pool():
    return {"pool": POOL}
