# -*- coding: utf-8 -*-
"""ML 信号 API：用训练好的模型预测全池上涨概率"""
from fastapi import APIRouter

from engine.ml import load_model, predict_proba_all, train_model

router = APIRouter()


@router.get("/signals")
def ml_signals():
    """用已保存的模型预测全池 ETF 上涨概率"""
    model = load_model()
    if model is None:
        return {"ok": False, "msg": "模型未训练，请先训练"}
    pred = predict_proba_all(model)
    if len(pred) == 0:
        return {"ok": False, "msg": "预测失败"}
    # 转信号
    pred["signal"] = pred["proba"].apply(
        lambda p: "BUY" if p > 0.55 else ("SELL" if p < 0.45 else "HOLD"))
    pred["score"] = (pred["proba"] * 100).round(1)  # 概率转评分
    return {"ok": True, "signals": pred.to_dict(orient="records")}


@router.post("/retrain")
def retrain():
    """重新训练模型（用最新数据）"""
    model, metrics = train_model()
    if model is None:
        return {"ok": False, "msg": "训练失败", "metrics": metrics}
    from engine.ml import save_model, reset_model_cache
    save_model(model)
    reset_model_cache()  # 清内存模型缓存，同一进程内后续 /signals 立即用新模型
    # 第 23 项：模型已变 → 扫描缓存里的旧 ML 信号也必须失效
    try:
        from engine.signals import invalidate_scan_cache
        invalidate_scan_cache()
    except Exception:
        pass
    return {"ok": True, "metrics": metrics}
