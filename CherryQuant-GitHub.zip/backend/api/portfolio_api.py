# -*- coding: utf-8 -*-
"""账户 API：持仓、成交记录、手动记账"""
from datetime import datetime

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from engine import db, signals
from engine.config import POOL, CODE2NAME

router = APIRouter()


@router.get("/correlation")
def correlation():
    """持仓 ETF 相关性矩阵 + 高相关警告"""
    from engine.correlation import correlation_matrix
    from engine import db
    positions = db.load_positions()
    codes = list(positions.keys())
    result = correlation_matrix(codes)
    # 附加名称
    result["names"] = {c: positions[c]["name"] for c in codes}
    return result


@router.get("/risk")
def risk():
    """组合风险分析：波动率/风险贡献/VaR"""
    from engine.risk import portfolio_risk
    from engine import db
    from engine.config import CODE2NAME
    positions = db.load_positions()
    codes = list(positions.keys())
    # 用真实市值占比做组合风险权重（旧实现不传 weights → 按等权算，
    # 实际重仓单票时风险贡献/VaR 会严重失真、误导新手）
    weights, total_mv = {}, 0.0
    for code, pos in positions.items():
        try:
            df = signals.fetch(code, offline=True)
            px = float(df["close"].iloc[-1]) if len(df) else 0
        except Exception:
            px = 0
        mv = pos["shares"] * px
        weights[code] = mv
        total_mv += mv
    result = portfolio_risk(codes, weights=weights if total_mv > 0 else None)
    if "holdings" in result:
        for h in result["holdings"]:
            h["name"] = CODE2NAME.get(h["code"], positions.get(h["code"], {}).get("name", h["code"]))
    return result


@router.get("/rebalance")
def rebalance(total_capital: float = None):
    """自动再平衡计划：具体买/卖多少份额。

    total_capital: 可选，账户总权益（现金+持仓）。传入后目标仓位按总权益计算，
    避免只用持仓市值导致“半仓后再半仓”的重复减仓。
    """
    from engine.rebalance import rebalance_plan
    return rebalance_plan(total_capital=total_capital)


@router.get("/positions")
def positions():
    """当前持仓 + 实时市值/盈亏/风控。

    修复（第 21 项）：缺行情的标的 current_price/market_value/pnl 返回 None 并标记
    no_data=True；总额只汇总“有有效报价”的部分，并显式返回缺失标的与不完整标记，
    不再用 0 当价格（否则总市值 0、总盈亏 -100% 的假象）。
    """
    positions = db.load_positions()
    out = []
    valid_mv = 0.0
    valid_cost = 0.0
    missing = []
    cost_total = 0.0
    for code, pos in positions.items():
        df = signals.fetch(code, offline=True)
        has_quote = len(df) > 0
        current = float(df["close"].iloc[-1]) if has_quote else None
        sl = signals.stop_loss_check(code, pos, current)
        cost_total += pos["cost"]
        if has_quote:
            mv = pos["shares"] * current
            valid_mv += mv
            valid_cost += pos["cost"]
        else:
            mv = None
            missing.append({"code": code, "name": pos.get("name", CODE2NAME.get(code, code))})
        out.append({
            "code": code, "name": pos.get("name", CODE2NAME.get(code, code)),
            "shares": pos["shares"], "cost_price": pos["cost_price"],
            "current_price": current,
            "market_value": (round(mv, 2) if mv is not None else None),
            "cost": pos["cost"],
            "pnl_pct": (None if not has_quote else sl["pnl_pct"]),
            "drawdown": (None if not has_quote else sl["drawdown"]),
            "peak": sl["peak"],
            "risk_thresholds": sl.get("thresholds"),
            "stop_triggered": (False if not has_quote else sl["stop_triggered"]),
            "take_profit": (False if not has_quote else sl["take_profit"]),
            "no_data": (not has_quote),
        })
    out.sort(key=lambda x: (x["market_value"] is None, -(x["market_value"] or 0)))
    return {
        "positions": out,
        "total_market_value": round(valid_mv, 2),
        "total_cost": round(cost_total, 2),
        "total_cost_priced": round(valid_cost, 2),
        "total_pnl": round(valid_mv - valid_cost, 2),
        "total_pnl_pct": (round((valid_mv / valid_cost - 1) * 100, 2) if valid_cost else None),
        "valuation_complete": (len(missing) == 0),
        "missing_quotes": missing,
        "note": ("全部持仓有有效报价" if not missing
                 else f"{len(missing)} 只缺少行情，总额仅统计有报价部分"),
    }


@router.get("/trades")
def trades():
    return {"trades": db.load_trades()}


class TradeIn(BaseModel):
    action: str          # BUY / SELL
    code: str
    price: float
    shares: float
    amount: float = 0
    fee: float = 0       # 迭代 A：手续费（可选，默认 0；写入资金账本 FEE 行）


@router.post("/trades")
def add_trade(t: TradeIn):
    """手动记录一笔成交。

    后台校验（不依赖前端）：动作只允许 BUY/SELL；价格/份数必须是有限正数；
    禁止未持有卖出与超额卖出；amount 口径 = 成交额(price×shares，不含费用)。
    持仓、峰值、成交、资金账本在同一个 SQLite 事务内完成，失败整体回滚。
    迭代 A：可选 fee 参数记录手续费；账户已建账本时现金不足会被拒绝。
    """
    name = CODE2NAME.get(t.code, t.code)
    try:
        result = db.apply_trade(
            action=t.action, code=t.code, price=t.price, shares=t.shares,
            amount=(t.amount if t.amount else None), name=name,
            fee=(t.fee or 0),
        )
    except db.TradeRejected as e:
        raise HTTPException(status_code=400, detail=str(e))
    # 第 23 项：账户状态已变 → 清扫描缓存，避免建议/持仓摘要拿旧数据
    try:
        from engine.signals import invalidate_scan_cache
        invalidate_scan_cache()
    except Exception:
        pass
    return {"ok": True, "trade": result,
            "message": (f"{result['action']} {name}({t.code}) {t.shares}股 @ {t.price}"
                        + (f" fee={result.get('fee')}" if result.get("fee") else ""))}


@router.post("/reset")
def reset_account():
    """清空持仓、成交、峰值、资金账本与账户锚点（单事务，谨慎操作）"""
    db.reset_account()
    try:
        from engine.signals import invalidate_scan_cache
        invalidate_scan_cache()
    except Exception:
        pass
    return {"ok": True, "message": "账户已重置（持仓/成交/峰值已清空）"}
