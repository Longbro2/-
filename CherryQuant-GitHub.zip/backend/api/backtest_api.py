# -*- coding: utf-8 -*-
"""回测 API：多策略对比、阈值优化（样本外验证）、组合回测"""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional

from engine import backtest
from engine.config import POOL, CODE2NAME

router = APIRouter()


@router.get("/portfolio")
def portfolio(codes: Optional[str] = None, capital: float = 100000,
              buy_th: int = 45, sell_th: int = 25,
              start: Optional[str] = None, risk: bool = True):
    """
    组合回测：多只 ETF 按系统信号同时持仓。
    codes 逗号分隔（默认全池）；capital 组合初始资金；buy_th/sell_th 评分阈值；
    risk 是否启用与实盘一致的止损/止盈。
    """
    from engine.portfolio_backtest import portfolio_backtest
    code_list = [c.strip() for c in codes.split(",") if c.strip()] if codes else None
    return portfolio_backtest(code_list, capital=capital, buy_th=buy_th,
                              sell_th=sell_th, start=start, enable_risk=risk)


@router.get("/compare/{code}")
def compare(code: str, start: Optional[str] = None, risk: bool = True):
    """单只 ETF 多策略对比"""
    return backtest.strategy_comparison(code, start=start, enable_risk=risk)


@router.get("/optimize/{code}")
def optimize(code: str, start: Optional[str] = None, test_ratio: float = 0.3, risk: bool = True):
    """阈值优化 + 样本外验证"""
    result = backtest.find_best_thresholds(code, start=start, test_ratio=test_ratio,
                                           enable_risk=risk)
    if result is None:
        return {"ok": False, "msg": "数据不足，需至少120条日线"}
    return {"ok": True, **result}


@router.get("/optimize-all")
def optimize_all(start: Optional[str] = None, test_ratio: float = 0.3, risk: bool = True):
    """全池阈值优化（可能较慢）"""
    results = []
    for name, info in POOL.items():
        r = backtest.find_best_thresholds(info["code"], start=start,
                                          test_ratio=test_ratio, enable_risk=risk)
        if r:
            r["name"] = name
            results.append(r)
    results.sort(key=lambda x: x.get("test", {}).get("sharpe", -99), reverse=True)
    return {"results": results}
