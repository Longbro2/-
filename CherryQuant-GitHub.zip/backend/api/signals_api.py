# -*- coding: utf-8 -*-
"""信号 API：每日扫描、单只信号、K线、市场温度"""
from fastapi import APIRouter

from engine import signals
from engine.data import fetch
from engine.config import POOL, CODE2NAME
from engine.signals import calc_indicators, gen_signal

router = APIRouter()


@router.get("/scan")
def scan():
    """全池扫描：信号排名 + 持仓风控 + 市场温度 + 纪律锁 + 操作建议"""
    return signals.scan_all_signals()


@router.get("/advice")
def advice():
    """直接返回操作建议（买什么/卖什么/加仓/持有）"""
    scan = signals.scan_all_signals()
    return scan["advice"]


@router.get("/market")
def market():
    """市场温度：复用全池扫描缓存（30s TTL），避免每请求重算 20 只信号+板块动量"""
    scan = signals.scan_all_signals()
    return signals.market_temperature(scan["signals"])


@router.get("/rotation")
def rotation():
    """行业轮动/板块强弱分析"""
    from engine.rotation import sector_rotation
    return sector_rotation()


@router.get("/valid-pool")
def valid_pool():
    """有效池：只显示验证有效的标的 + 当前信号/资金/指令"""
    scan = signals.scan_all_signals()
    valid = []
    for s in scan["signals"]:
        if s.get("verify") == "valid":
            # 找对应操作指令
            inst = next((i for i in scan.get("instructions", []) if i["code"] == s["code"]), None)
            valid.append({
                "name": s["name"], "code": s["code"],
                "signal": s["signal"], "score": s["score"],
                "sharpe": s.get("test_sharpe"),
                "main_net_5d": s.get("main_net_5d", 0),
                "action": inst["action"] if inst else None,
                "reason": inst["reason"] if inst else None,
                "holding": s.get("holding", False),
            })
    valid.sort(key=lambda x: -x["score"])
    invalid = [s["name"] for s in scan["signals"] if s.get("verify") == "invalid"]
    return {
        "valid_pool": valid,
        "invalid_list": invalid,
        "market_temp": scan["market"]["temp"],
        "valid_count": len(valid),
        "invalid_count": len(invalid),
    }


@router.get("/trade-orders")
def trade_orders():
    """一键生成可复制的交易指令"""
    from engine.trade_orders import generate_trade_orders
    return generate_trade_orders()


@router.get("/optimize-rebalance")
def optimize_rebalance():
    """收益优化调仓路线图：结构性调仓(验证)+跟信号(规则/ML)+止损纪律三合一"""
    from engine.optimizer import optimize_rebalance as _optimize
    return _optimize()


@router.get("/recommended")
def recommended():
    """推荐组合：验证有效+评分高的Top8轮动（历史回测最优）"""
    from engine.recommend import recommended_portfolio
    return recommended_portfolio()


@router.get("/ranking")
def ranking():
    """短期强度排名：综合评分+资金流+今日表现+验证加成"""
    from engine.ranking import short_term_ranking
    return short_term_ranking()


@router.get("/guide")
def guide():
    """跟着系统走：今日操作指南"""
    from engine.guide import build_guide
    return build_guide()


@router.get("/kline/{code}")
def kline(code: str, limit: int = 250):
    """某 ETF 的 K 线 + 均线/RSI/MACD 序列（供前端绘图）"""
    df = fetch(code, offline=True)
    if len(df) == 0:
        return {"ok": False, "msg": "无数据"}
    df = df.tail(limit).reset_index(drop=True)
    # 图表指标与 K 线按同一根对齐（旧实现 lag=True 会把均线整体画晚一根）
    ind = calc_indicators(df, lag=False)

    # 转 ECharts 友好格式
    dates = df["date"].dt.strftime("%Y-%m-%d").tolist()
    ohlc = df[["open", "close", "low", "high"]].round(4).values.tolist()
    vols = df["volume"].tolist()
    return {
        "ok": True,
        "code": code, "name": CODE2NAME.get(code, code),
        "dates": dates, "ohlc": ohlc, "volumes": vols,
        "ma5": [None if pd_isna(v) else round(v, 4) for v in ind["ma5"]],
        "ma20": [None if pd_isna(v) else round(v, 4) for v in ind["ma20"]],
        "ma50": [None if pd_isna(v) else round(v, 4) for v in ind["ma50"]],
        "rsi": [None if pd_isna(v) else round(v, 2) for v in ind["rsi"]],
    }


def pd_isna(v):
    import pandas as pd
    return pd.isna(v)


@router.get("/detail/{code}")
def detail(code: str):
    """单只 ETF 最新信号明细"""
    for name, info in POOL.items():
        if info["code"] == code:
            df = fetch(code)
            if len(df) < 60:
                return {"ok": False, "msg": "数据不足"}
            s = gen_signal(name, info, df)
            return {"ok": True, **s}
    return {"ok": False, "msg": "不在池中"}
