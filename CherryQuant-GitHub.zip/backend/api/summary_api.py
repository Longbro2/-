# -*- coding: utf-8 -*-
"""今日操作摘要 API：聚合信号+指令+宏观+持仓 成一张速览"""
from fastapi import APIRouter

from engine import signals, macro
from engine.config import RISK

router = APIRouter()


@router.get("/daily")
def daily_summary():
    """生成今日操作摘要（整合所有维度）"""
    scan = signals.scan_all_signals()
    macro_view = macro.analyze_macro()

    # 持仓操作指令
    holdings_inst = [i for i in scan.get("instructions", [])
                     if any(h["code"] == i["code"] for h in scan["holdings"])]

    # 候选买入（未持仓的强信号）
    candidates = [i for i in scan.get("instructions", [])
                  if not any(h["code"] == i["code"] for h in scan["holdings"])
                  and i["action"] in ("买入", "关注")]

    # 风险提示
    risk_alerts = []
    for h in scan["holdings"]:
        if h["status"] == "止损触发":
            risk_alerts.append({"code": h["code"], "name": h["name"], "type": "止损触发"})
        elif h["pnl_pct"] is not None and h["pnl_pct"] < -8:
            risk_alerts.append({"code": h["code"], "name": h["name"], "type": "接近止损"})
        elif h.get("main_net_5d") is not None and h["main_net_5d"] < -2000:
            risk_alerts.append({"code": h["code"], "name": h["name"], "type": "资金大幅流出"})

    # 风控距离（修复第 20 项）：
    #  - 等级优先服从真实触发状态（止损触发/止盈触发），不再一律按成本线判 "安全"；
    #  - 展示实际生效阈值：成本止损、峰值回撤止损（取两者中先触发的高线）、
    #    固定止盈、移动止盈（激活后按峰值回撤）；阈值来自 signals 的统一风控引擎。
    risk_distance = []
    for h in scan["holdings"]:
        cost = h.get("cost_price")
        cur = h.get("current_price")
        peak = h.get("peak")
        status = h.get("status")
        th = h.get("risk_thresholds") or {}
        if h.get("no_data") or not cur or not cost:
            risk_distance.append({
                "code": h["code"], "name": h["name"], "status": status,
                "current": cur, "cost": cost, "stop": None, "take": None,
                "dist_stop_pct": None, "dist_take_pct": None,
                "level": "nodata", "note": "行情缺失，无法计算止损/止盈距离",
            })
            continue
        stop_loss_line = cost * (1 + th.get("stop_loss", RISK.get("stop_loss", -10.0)) / 100.0)
        stop_dd_line = (peak or cost) * (1 + th.get("stop_drawdown", RISK.get("stop_drawdown", -8.0)) / 100.0)
        eff_stop = max(stop_loss_line, stop_dd_line)      # 两条止损线中先触发的那条
        take_lines = [cost * (1 + th.get("take_profit", RISK.get("take_profit", 15.0)) / 100.0)]
        if th.get("use_trailing_stop", RISK.get("use_trailing_stop", True)) and peak and \
                peak >= cost * (1 + th.get("trailing_activate", RISK.get("trailing_activate", 8.0)) / 100.0):
            take_lines.append(peak * (1 + th.get("trailing_stop", RISK.get("trailing_stop", -8.0)) / 100.0))
        eff_take = min(take_lines)                         # 固定/移动止盈中先触发的那条
        dist_stop = (cur - eff_stop) / cur * 100
        dist_take = (eff_take - cur) / cur * 100
        if status == "止损触发":
            level, note = "danger", "已触发止损"
        elif status == "止盈触发":
            level, note = "take", "已触发止盈"
        elif status == "数据缺失":
            level, note = "nodata", "行情缺失"
        elif dist_stop < 3:
            level, note = "danger", "临近止损"
        elif (h.get("pnl_pct") is not None and h["pnl_pct"] < -8) or \
                (h.get("drawdown") is not None and h["drawdown"] < -6):
            level, note = "warn", "亏损/回撤接近阈值"
        else:
            level, note = "ok", "距离风控线尚有余量"
        risk_distance.append({
            "code": h["code"], "name": h["name"], "status": status,
            "current": cur, "cost": cost, "peak": peak,
            "stop": round(float(eff_stop), 3), "take": round(float(eff_take), 3),
            "stop_kind": "成本止损/峰值回撤止损中先触发者",
            "take_kind": "固定止盈/移动止盈中先触发者",
            "adaptive": bool(th.get("adaptive")),
            "dist_stop_pct": round(dist_stop, 1),
            "dist_take_pct": round(dist_take, 1),
            "level": level, "note": note,
        })

    return {
        "date": scan["generated_at"],
        "market": scan["market"],
        "discipline": scan["discipline"],
        "holdings": scan["holdings"],
        "portfolio": scan.get("portfolio"),
        "holdings_instructions": holdings_inst,
        "candidates": candidates,
        "macro": macro_view,
        "risk_alerts": risk_alerts,
        "risk_distance": risk_distance,
        "instructions": scan.get("instructions"),
    }
