# -*- coding: utf-8 -*-
"""资金账本 API：账户权益、现金账本、入金/出金、历史成交导入。

契约：`D:\\ds\\CherryQuant-迭代A-资金账本-契约与分工.md` §4（唯一口径）。
- 业务口径全部在 engine/account.py（§2），本层只做参数校验 + HTTP 错误映射；
- 校验失败/现金不足（db.TradeRejected）→ HTTPException(400, detail=str(e))；
- 所有写操作成功后 invalidate_scan_cache()，避免信号/建议缓存拿旧账户状态。
"""
import math
from typing import Any, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from engine import account, db

router = APIRouter()


def _invalidate_cache():
    """账户状态已变 → 清扫描缓存（与 portfolio_api 写接口保持一致）。"""
    try:
        from engine.signals import invalidate_scan_cache
        invalidate_scan_cache()
    except Exception:
        pass


class CashIn(BaseModel):
    """入金/出金请求体：amount 必填，date/note 可选。"""
    amount: float
    date: Optional[str] = None
    note: Optional[str] = None


class ImportTradesIn(BaseModel):
    """历史成交导入请求体：confirm=false 只预览，true 单事务写库。"""
    trades: List[Any] = Field(default_factory=list)
    confirm: bool = False


def _validate_amount(amount) -> float:
    """amount 必须是有限正数，否则 400（不依赖 engine 层兜底）。"""
    try:
        amount_f = float(amount)
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail="amount 必须是数字")
    if not math.isfinite(amount_f) or amount_f <= 0:
        raise HTTPException(status_code=400, detail="amount 必须是有限正数")
    return amount_f


def _equity_response(result: dict = None) -> dict:
    """写操作（入金/出金）响应：{"ok", "entry", "equity"}。

    entry/equity 优先用 engine 层本次写库返回的真实结果；兜底再自行取最新账本行
    与轻量权益（带 TWR 的完整权益由 GET /equity 统一提供）。
    """
    result = result or {}
    entry = result.get("entry")
    if not isinstance(entry, dict):
        entries = account.list_ledger(1).get("entries") or []
        entry = entries[0] if entries else {}
    equity = result.get("equity")
    if not isinstance(equity, dict):
        equity = account.get_account_equity(with_twr=False)
    return {"ok": True, "entry": entry, "equity": equity}


@router.get("/equity")
def equity():
    """账户权益总览：现金/持仓市值/总权益/已实现盈亏/TWR 等（契约 §2 全字段）。"""
    return account.get_account_equity()


@router.get("/ledger")
def ledger(limit: int = 100):
    """现金账本（最近 limit 条）：base_cash/cash/entries(cash_after 余额链)。"""
    return account.list_ledger(limit)


@router.post("/deposit")
def deposit(body: CashIn):
    """入金：amount 非有限正数 → 400；成功后返回最新账本行与账户权益。"""
    amount = _validate_amount(body.amount)
    try:
        result = account.deposit(amount, date=body.date, note=body.note)
    except db.TradeRejected as e:
        raise HTTPException(status_code=400, detail=str(e))
    _invalidate_cache()
    return _equity_response(result)


@router.post("/withdraw")
def withdraw(body: CashIn):
    """出金：现金不足 → 400（detail 含“现金不足”）。"""
    amount = _validate_amount(body.amount)
    try:
        result = account.withdraw(amount, date=body.date, note=body.note)
    except db.TradeRejected as e:
        raise HTTPException(status_code=400, detail=str(e))
    _invalidate_cache()
    return _equity_response(result)


def _build_preview_response(res: dict) -> dict:
    """按契约 §4 固定预览响应字段（不多不少）。"""
    return {
        "preview": True,
        "total": res.get("total"),
        "to_import": res.get("to_import"),
        "skipped_duplicates": res.get("skipped_duplicates"),
        "duplicates": res.get("duplicates", []),
        "cash_impact": res.get("cash_impact"),
        "cash_after": res.get("cash_after"),
        "equity_after": res.get("equity_after"),
        "diff": res.get("diff", []),
        "note": res.get("note", ""),
    }


def _build_confirm_response(res: dict, equity: dict) -> dict:
    """按契约 §4 固定导入响应字段（不多不少）。"""
    return {
        "ok": True,
        "imported": res.get("imported", 0),
        "skipped_duplicates": res.get("skipped_duplicates", 0),
        "cash": res.get("cash", equity.get("cash")),
        "total_equity": res.get("total_equity", equity.get("total_equity")),
    }


@router.post("/import-trades")
def import_trades(body: ImportTradesIn):
    """历史成交导入：confirm=false 只预览不写库；confirm=true 单事务导入（重复行跳过）。

    非法行（action/price/shares 非法）由 engine 层抛 db.TradeRejected → 400。
    """
    trades = list(body.trades or [])
    try:
        if body.confirm:
            res = account.import_trades(trades)
        else:
            res = account.preview_import_trades(trades)
    except db.TradeRejected as e:
        raise HTTPException(status_code=400, detail=str(e))
    if body.confirm:
        _invalidate_cache()
        equity = account.get_account_equity(with_twr=False)
        return _build_confirm_response(res or {}, equity)
    return _build_preview_response(res or {})
