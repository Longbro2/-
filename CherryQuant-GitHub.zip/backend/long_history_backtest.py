# -*- coding: utf-8 -*-
"""
CherryQuant 完整系统诚实回测（预登记单一配置）
- 数据: data/cache/em_long/*.csv（东财上市以来全历史 OHLC，前复权）
- 评分: 与 engine.signals._score 纯技术因子同口径（不含资金流）
- 执行: 决策日 T 收盘信息 → T+1 开盘价成交（无未来函数）
- 风控: 成本-10%止损 / 峰值回撤-8%止损 / 固定+15%止盈，触发后次日开盘卖
- 选股: Top5 等权, 每20个交易日全周转调仓; 点内有效性(近250日年化夏普>0.3)优先, 不足3只退回全池按分取
- 成本: 佣金万3 + 滑点千1, 买卖双向; 100股整手
- 基准: 全池等权, 同调仓频率同成本
用法: python backend/long_history_backtest.py
"""
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from engine.config import POOL, DATA_DIR  # noqa: E402

LONG_DIR = DATA_DIR / "cache" / "em_long"
CODE2NAME = {info["code"]: name for name, info in POOL.items()}

COMM = 0.0003
SLIP = 0.001
TOP_N = 5
REBAL = 20
MIN_VALID = 3
PIT_SHARPE = 0.3
STOP_LOSS = -0.10
STOP_DD = -0.08
TAKE_PROFIT = 0.15
INIT_CAP = 100000.0
LT_TERM = False  # 长期趋势项: True=评分纳入250日动量(长期牛加分/长期熊扣分)


# ---------- 评分（与 signals.py / research_common.py 同口径，close-only） ----------
def calc_indicators(df):
    df = df.copy()
    c = df["close"]
    df["ma5"] = c.rolling(5).mean()
    df["ma20"] = c.rolling(20).mean()
    df["ma50"] = c.rolling(50).mean()
    delta = c.diff()
    gain = delta.where(delta > 0, 0).rolling(14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(14).mean()
    df["rsi"] = 100 - 100 / (1 + gain / loss)
    ema12 = c.ewm(span=12).mean()
    ema26 = c.ewm(span=26).mean()
    df["macd"] = ema12 - ema26
    df["macd_signal"] = df["macd"].ewm(span=9).mean()
    df["mom_5d"] = (c.pct_change() + 1).rolling(5).apply(np.prod, raw=True) - 1
    c_arr = c.values
    n = len(df)
    df["pat_w"] = False
    if n > 60:
        pat_w = np.zeros(n, dtype=bool)
        for i in range(60, n):
            seg = c_arr[i - 40:i + 1]
            if abs(seg[:20].min() / seg[20:].min() - 1) < 0.03 and c_arr[i] > seg.max() * 0.95:
                pat_w[i] = True
        df["pat_w"] = pat_w
    df["pat_div"] = False
    if n > 40:
        rsi_arr = df["rsi"].values
        c_roll_min = c.rolling(20).min()
        min_prev = c.rolling(20).min().shift(1)
        new_low = (c_arr <= c_roll_min.values) & (c_arr < min_prev.values)
        rsi_prev_min = df["rsi"].rolling(20).min().shift(1)
        rsi_higher = rsi_arr > rsi_prev_min.values
        valid = ~np.isnan(min_prev.values) & ~np.isnan(rsi_prev_min.values)
        pat_div = np.zeros(n, dtype=bool)
        pat_div[40:] = (new_low[40:] & rsi_higher[40:] & valid[40:])
        df["pat_div"] = pat_div
    df["pat_brk"] = False
    if n > 30:
        h15 = c.rolling(15).max().shift(1)
        l15 = c.rolling(15).min().shift(1)
        h15v, l15v = h15.values, l15.values
        valid = ~np.isnan(h15v) & ~np.isnan(l15v)
        cond_amp = (h15v / l15v - 1) < 0.08
        pat_brk = np.zeros(n, dtype=bool)
        pat_brk[30:] = (cond_amp[30:] & (c_arr > h15v)[30:] & valid[30:])
        df["pat_brk"] = pat_brk
    df["macd_quality"] = 0
    if n > 2:
        macd_v = df["macd"].values
        sig_v = df["macd_signal"].values
        cross_up = (macd_v[1:] > sig_v[1:]) & (macd_v[:-1] <= sig_v[:-1])
        idx = np.where(cross_up)[0] + 1
        for i in idx:
            df.loc[df.index[i], "macd_quality"] = 1 if macd_v[i] < 0 else 2
    for col in ["ma5", "ma20", "ma50", "rsi", "macd", "macd_signal",
                "mom_5d", "pat_w", "pat_div", "pat_brk", "macd_quality"]:
        df[col] = df[col].shift(1)
    return df


def score_series(df):
    ind = calc_indicators(df)
    c_arr = df["close"].values
    n = len(ind)
    scores = np.full(n, np.nan)
    for i in range(60, n):
        row = ind.iloc[i]
        prev = ind.iloc[i - 1]
        macd_b = bool(row["macd"] > row["macd_signal"])
        macd_cross = bool(prev["macd"] <= prev["macd_signal"]) and macd_b
        ma_b = bool(row["ma5"] > row["ma20"] > row["ma50"])
        r = row["rsi"]
        m5 = float(row["mom_5d"]) if pd.notna(row["mom_5d"]) else 0.0
        c = c_arr[i]
        r60 = (c / c_arr[i - 60] - 1) * 100 if c_arr[i - 60] > 0 else 0.0
        r20 = (c / c_arr[i - 20] - 1) * 100 if c_arr[i - 20] > 0 else 0.0
        r5 = (c / c_arr[i - 5] - 1) * 100 if c_arr[i - 5] > 0 else 0.0
        if r60 > 5 and r5 > -2:
            tq = "强趋势"
        elif r60 > 5 and r20 < 0 and r5 > 0:
            tq = "回调企稳"
        elif r60 < -10 and r5 > 3:
            tq = "超跌反弹"
        elif r60 < -5:
            tq = "下跌趋势"
        else:
            tq = "震荡"
        s = 50.0
        s += 15 if macd_b else -15
        s += 5 if macd_cross else 0
        s += 15 if ma_b else -15
        s += 10 if 40 < r < 80 else 0
        s += m5 * 30
        s += 15 if bool(row.get("pat_w")) else 0
        s += 5 if bool(row.get("pat_brk")) else 0
        s += 8 if int(row.get("macd_quality", 0)) == 2 else 0
        s -= 3 if int(row.get("macd_quality", 0)) == 1 else 0
        s += {"强趋势": 5.0, "回调企稳": 4.0, "超跌反弹": 1.0,
              "震荡": 0.0, "下跌趋势": -5.0}.get(tq, 0.0)
        # 长期趋势项（250日动量）：修正"60日视野"的缺陷——长期牛市回调不该被当弱势票
        if LT_TERM and i >= 250 and c_arr[i - 250] > 0:
            r250 = (c / c_arr[i - 250] - 1) * 100
            if r250 > 30:
                s += 4.0
            elif r250 > 10:
                s += 2.0
            elif r250 < -20:
                s -= 4.0
        scores[i] = float(max(0, min(100, s)))
    return pd.Series(scores, index=pd.to_datetime(df["date"]))


def pit_valid(closes, asof, min_sharpe=0.3):
    w = closes[closes.index <= asof].dropna()
    rets = w.pct_change().dropna().tail(250)
    if len(rets) < 60:
        return False
    sd = rets.std()
    if not sd or sd <= 0:
        return False
    return (rets.mean() / sd) * np.sqrt(252) > min_sharpe


# ---------- 数据 ----------
data = {}
for code in CODE2NAME:
    p = os.path.join(LONG_DIR, f"{code}.csv")
    if not os.path.exists(p):
        continue
    df = pd.read_csv(p)
    df["date"] = pd.to_datetime(df["date"])
    data[code] = df

all_dates = sorted(set().union(*[set(df["date"]) for df in data.values()]))
panel = pd.DatetimeIndex(all_dates)

close_panel = pd.DataFrame(index=panel, columns=list(data.keys()), dtype=float)
open_panel = pd.DataFrame(index=panel, columns=list(data.keys()), dtype=float)
for code, df in data.items():
    close_panel[code] = pd.Series(df["close"].values, index=df["date"]).reindex(panel).ffill()
    open_panel[code] = pd.Series(df["open"].values, index=df["date"]).reindex(panel)
raw_close = {c: pd.Series(df["close"].values, index=df["date"]) for c, df in data.items()}

scores = {c: score_series(df) for c, df in data.items()}


def next_bar(code, d):
    idx = data[code]["date"]
    after = idx[idx > d]
    return after.iloc[0] if len(after) else None


def metrics(eq, dates):
    total = (eq[-1] / INIT_CAP - 1) * 100
    years = (dates[-1] - dates[0]).days / 365.25
    annual = ((eq[-1] / INIT_CAP) ** (1 / years) - 1) * 100 if years > 0 else 0.0
    r = pd.Series(eq, index=dates).pct_change().dropna()
    sharpe = (r.mean() / r.std()) * np.sqrt(252) if len(r) > 1 and r.std() > 0 else 0.0
    mdd = ((pd.Series(eq) / pd.Series(eq).cummax()) - 1).min() * 100
    return total, annual, sharpe, mdd


def run_system(start, temp=False):
    sub = panel[panel >= pd.Timestamp(start)]
    if len(sub) < 120:
        return None
    cash = INIT_CAP
    holdings = {}  # code -> {'sh':, 'cost':, 'peak':}
    eq = np.zeros(len(sub))
    stop_count = 0
    for j, d in enumerate(sub):
        mv = cash
        for code, h in holdings.items():
            px = close_panel.loc[d, code]
            if np.isnan(px):
                continue
            mv += h["sh"] * px
            h["peak"] = max(h["peak"], px)
        eq[j] = mv
        # 止损止盈检查（T 收盘触发 → T+1 开盘卖）
        for code in list(holdings.keys()):
            h = holdings[code]
            px = close_panel.loc[d, code]
            if np.isnan(px) or px <= 0:
                continue
            trig = (px <= h["cost"] * (1 + STOP_LOSS) or
                    px <= h["peak"] * (1 + STOP_DD) or
                    px >= h["cost"] * (1 + TAKE_PROFIT))
            if trig:
                nb = next_bar(code, d)
                if nb is None:
                    continue
                opx = open_panel.loc[nb, code]
                if np.isnan(opx):
                    opx = close_panel.loc[nb, code]
                cash += h["sh"] * opx * (1 - SLIP) * (1 - COMM)
                stop_count += 1
                del holdings[code]
        if j % REBAL != 0:
            continue
        # 选股（T 收盘后信息）
        avail = {}
        for code in data:
            key = d.strftime("%Y-%m-%d")
            sc = scores[code].loc[key] if key in scores[code].index else np.nan
            px = close_panel.loc[d, code]
            if not np.isnan(sc) and not np.isnan(px) and px > 0:
                avail[code] = sc
        if not avail:
            continue
        valid = [c for c in avail if pit_valid(raw_close[c], d, PIT_SHARPE)]
        pool_codes = valid if len(valid) >= MIN_VALID else list(avail.keys())
        targets = sorted(pool_codes, key=lambda c: -avail[c])[:TOP_N]
        # 市场温度择时（与实盘口径一致: BUY占比>=60%满仓 / 40-60%半仓 / <40%空仓）
        invest = 1.0
        if temp:
            hot = sum(1 for c in avail if avail[c] >= 50) / len(avail) if avail else 0.0
            if hot >= 0.60:
                invest = 1.0
            elif hot >= 0.40:
                invest = 0.5
            else:
                invest = 0.0
            if invest <= 0:
                targets = []
        # 全卖全买（T+1 开盘）
        for code, h in list(holdings.items()):
            nb = next_bar(code, d)
            if nb is None:
                continue
            opx = open_panel.loc[nb, code]
            if np.isnan(opx):
                opx = close_panel.loc[nb, code]
            cash += h["sh"] * opx * (1 - SLIP) * (1 - COMM)
            del holdings[code]
        if not targets:
            continue
        # ---- 修复：调仓预算必须来自"卖出后的实际现金"，不能用前一日估值 mv ----
        # 旧实现 budget = mv*invest/len(targets)，跳空低开时卖出拿到的钱少于 mv，
        # 会花掉并不存在的钱（合成场景出现负现金 = 隐性借款）。
        tradable = []
        for code in targets:
            nb = next_bar(code, d)
            if nb is None:
                continue
            opx = open_panel.loc[nb, code]
            if np.isnan(opx):
                opx = close_panel.loc[nb, code]
            if np.isnan(opx) or opx <= 0:
                continue
            tradable.append((code, opx))
        if not tradable:
            continue
        available = max(0.0, cash) * invest
        budget = available / len(tradable)
        for code, opx in tradable:
            px = opx * (1 + SLIP)
            sh = int(budget / (px * (1 + COMM)) // 100 * 100)
            if sh <= 0:
                continue
            cost = sh * px * (1 + COMM)
            if cost > cash:      # 手续费边界兜底，绝不透支
                continue
            cash -= cost
            holdings[code] = {"sh": sh, "cost": opx, "peak": opx}
    return eq, sub, stop_count


def run_pool(start):
    sub = panel[panel >= pd.Timestamp(start)]
    if len(sub) < 120:
        return None
    cash = INIT_CAP
    holdings = {}
    eq = np.zeros(len(sub))
    for j, d in enumerate(sub):
        mv = cash
        for code, sh in holdings.items():
            px = close_panel.loc[d, code]
            if not np.isnan(px):
                mv += sh * px
        eq[j] = mv
        if j % REBAL != 0:
            continue
        avail = [c for c in data if not np.isnan(close_panel.loc[d, c]) and close_panel.loc[d, c] > 0]
        if not avail:
            continue
        for code, sh in list(holdings.items()):
            nb = next_bar(code, d)
            if nb is None:
                continue
            opx = open_panel.loc[nb, code]
            if np.isnan(opx):
                opx = close_panel.loc[nb, code]
            cash += sh * opx * (1 - SLIP) * (1 - COMM)
            del holdings[code]
        # ---- 修复：预算 = 卖出后的实际现金，而不是前一日估值 mv ----
        tradable = []
        for code in avail:
            nb = next_bar(code, d)
            if nb is None:
                continue
            opx = open_panel.loc[nb, code]
            if np.isnan(opx):
                opx = close_panel.loc[nb, code]
            if np.isnan(opx) or opx <= 0:
                continue
            tradable.append((code, opx))
        if not tradable:
            continue
        budget = max(0.0, cash) / len(tradable)
        for code, opx in tradable:
            px = opx * (1 + SLIP)
            sh = int(budget / (px * (1 + COMM)) // 100 * 100)
            if sh <= 0:
                continue
            cost = sh * px * (1 + COMM)
            if cost > cash:
                continue
            cash -= cost
            holdings[code] = sh
    return eq, sub


if __name__ == "__main__":
    print(f"数据: em_long {len(data)} 只, {panel[0].date()} ~ {panel[-1].date()}, {len(panel)} 个交易日")
    print("=" * 100)
    print(f"完整系统诚实回测 | Top{TOP_N} | {REBAL}日调仓 | 止损-10%/-8% | 止盈+15% | T+1开盘成交 | 万3佣+千1滑")
    print("=" * 100)
    for start in ["2016-01-01", "2018-01-01", "2021-01-01", "2023-01-01"]:
        r0 = run_system(start, temp=False)
        r1 = run_system(start, temp=True)
        b = run_pool(start)
        if r0 is None:
            print(f"[{start}] 数据不足")
            continue
        eq0, dt, stops0 = r0
        eq1, _, stops1 = r1
        eqb, dtb = b
        t0, a0, sh0, m0 = metrics(eq0, dt)
        t1, a1, sh1, m1 = metrics(eq1, dt)
        tb, ab, shb, mb = metrics(eqb, dtb)
        yrs = (dt[-1] - dt[0]).days / 365.25
        n0 = sum(1 for c in data if not np.isnan(close_panel.loc[dt[0], c]))
        print(f"\n[{start} 起, {yrs:.1f}年, 期初有数据 {n0} 只]")
        print(f"  完整系统(无温度) : 总收益 {t0:+8.1f}%  年化 {a0:+6.1f}%  夏普 {sh0:5.2f}  回撤 {m0:6.1f}%  止损{stops0}次")
        print(f"  完整系统(含温度) : 总收益 {t1:+8.1f}%  年化 {a1:+6.1f}%  夏普 {sh1:5.2f}  回撤 {m1:6.1f}%  止损{stops1}次")
        print(f"  全池等权        : 总收益 {tb:+8.1f}%  年化 {ab:+6.1f}%  夏普 {shb:5.2f}  回撤 {mb:6.1f}%")
        print(f"  超额α(含温度)   : {t1-tb:+8.1f}pp")
    print("\n注: 评分不含资金流因子; 池为事后挑选的热门赛道; 早期(2016-2020)可交易标的极少, 轮动意义有限。")
