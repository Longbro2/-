# -*- coding: utf-8 -*-
"""
CherryQuant Web — 每日宏观/新闻搜集辅助脚本
提示词: 提醒用户用 web_search 搜索今日与持仓板块相关的新闻，
       提取关键事件，更新 config.py 的 MACRO_EVENTS。

实际搜索由 AI 执行（需要判断力），本脚本负责:
  1. 记录上次搜集时间
  2. 生成"待搜集板块清单"（基于当前持仓）
  3. 展示宏观瞭望当前状态
"""
import sys
import json
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from engine import db, signals
from engine.macro import analyze_macro

LAST_FILE = Path(__file__).resolve().parent.parent / "data" / "last_news_check.json"


def get_holdings_sectors() -> list:
    """基于当前持仓，返回需要关注新闻的板块"""
    positions = db.load_positions()
    sector_map = {
        "159828": "创新药/医药", "512010": "医药",
        "516650": "有色金属/铜", "159530": "机器人",
        "513010": "恒生科技/港股", "560390": "电网设备",
        "562510": "旅游/消费", "560680": "消费",
    }
    sectors = []
    for code in positions:
        if code in sector_map:
            sectors.append(sector_map[code])
    return sectors


def main():
    print("=" * 60)
    print("  CherryQuant 每日新闻搜集")
    print("=" * 60)
    print(f"时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print()

    # 1. 当前持仓 → 需关注的板块
    sectors = get_holdings_sectors()
    print("【当前持仓需关注的板块】")
    for s in sectors:
        print(f"  - {s}")
    print()

    # 2. 宏观瞭望当前状态
    print("【宏观瞭望当前事件】")
    macro = analyze_macro()
    for e in macro["events"]:
        print(f"  [{e.get('status','')}] {e['name']}")
    print()

    # 3. 上次搜集时间
    last = ""
    if LAST_FILE.exists():
        try:
            last = json.loads(LAST_FILE.read_text(encoding="utf-8")).get("last_check", "")
        except Exception:
            pass
    print(f"【上次新闻搜集】: {last or '从未'}")
    print()
    print("【提示】")
    print("  请用 web_search 搜索以下方向的最新新闻，并更新 config.py 的 MACRO_EVENTS：")
    for s in sectors:
        print(f"    - {s} 近期新闻/政策/事件")
    print("  更新后，宏观瞭望页面会自动展示新事件。")
    print()

    # 记录本次
    LAST_FILE.parent.mkdir(parents=True, exist_ok=True)
    LAST_FILE.write_text(json.dumps({
        "last_check": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "sectors": sectors,
    }, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
