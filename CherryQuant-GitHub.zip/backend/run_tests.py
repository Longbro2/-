# -*- coding: utf-8 -*-
"""
CherryQuant — 一键测试脚本
运行全部单元测试 + 系统自检，快速发现回归。

用法: python -X utf8 backend/run_tests.py
"""
import sys
import subprocess
import os
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
os.chdir(BASE)

def run(cmd, label):
    print(f"\n{'='*50}")
    print(f"  {label}")
    print(f"{'='*50}")
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if r.stdout:
        print(r.stdout[-1500:])
    if r.returncode != 0 and r.stderr:
        print(r.stderr[-800:])
    return r.returncode

print("CherryQuant 一键测试")
print("===================")

# 1. 单元测试
rc1 = run("python -X utf8 -m pytest backend/tests/ -q", "1. 单元测试 (pytest)")
passed = rc1 == 0

# 2. 系统自检
rc2 = run("python -X utf8 backend/system_verify.py", "2. 系统自检 (16项)")
sys_ok = rc2 == 0

print(f"\n{'='*50}")
print("  测试结果汇总")
print(f"{'='*50}")
print(f"  单元测试: {'✅ 通过' if passed else '❌ 失败'}")
print(f"  系统自检: {'✅ 通过' if sys_ok else '❌ 失败'}")
print(f"\n  总体: {'✅ 全部通过' if (passed and sys_ok) else '❌ 有问题需检查'}")
sys.exit(0 if (passed and sys_ok) else 1)
