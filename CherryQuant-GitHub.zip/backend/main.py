# -*- coding: utf-8 -*-
"""
CherryQuant Web — FastAPI 入口
启动: uvicorn main:app --host 127.0.0.1 --port 8000
"""
import sys
from pathlib import Path

# 确保可导入 engine
sys.path.insert(0, str(Path(__file__).resolve().parent))

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from engine import db
from api import data_api, signals_api, backtest_api, portfolio_api, macro_api, ml_api, summary_api, account_api

# 初始化数据库 + 迁移旧数据
db.init_db()
migrated = db.migrate_legacy()

# 启动时异步核对 ETF 名称（防配置错误，后台执行不阻塞启动）
try:
    import threading

    def _async_name_check():
        try:
            from engine.check_names import verify_etf_names
            _name_check = verify_etf_names()
            if not _name_check["all_correct"]:
                print("[warn] ETF 名称核对发现异常:")
                for m in _name_check.get("mismatch", []):
                    print(f"  [warn] ❌ {m['code']}: 系统叫[{m['config_name']}] 实际是[{m['real_name']}]")
                for f in _name_check.get("failed", []):
                    print(f"  [warn] ⚠️ {f['code']}: 拉取失败")
            else:
                print(f"[info] ETF 名称核对通过: {_name_check['total']} 只全部匹配")
        except Exception as e:
            print(f"[warn] ETF 名称核对跳过: {e}")

    threading.Thread(target=_async_name_check, daemon=True).start()
except Exception:
    pass

app = FastAPI(title="CherryQuant Web", version="5.2.0",
              description="A股 ETF 量化信号 & 回测系统")

# CORS：本地开发收紧为仅 localhost。若部署公网需按需修改，切勿用 "*"。
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000", "http://127.0.0.1:8000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 路由
app.include_router(data_api.router, prefix="/api/data", tags=["数据"])
app.include_router(signals_api.router, prefix="/api/signals", tags=["信号"])
app.include_router(backtest_api.router, prefix="/api/backtest", tags=["回测"])
app.include_router(portfolio_api.router, prefix="/api/portfolio", tags=["账户"])
app.include_router(account_api.router, prefix="/api/account", tags=["资金账本"])
app.include_router(macro_api.router, prefix="/api/macro", tags=["宏观"])
app.include_router(ml_api.router, prefix="/api/ml", tags=["机器学习"])
app.include_router(summary_api.router, prefix="/api/summary", tags=["摘要"])


# 全局异常兜底：引擎异常返回 JSON(500) 而非 HTML 500，前端可统一处理。
# 注意：响应体含 NaN/Infinity 属 JSON 编码层错误，需在各接口序列化前清洗。
@app.exception_handler(Exception)
async def unhandled_exception(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"detail": f"服务器内部错误: {type(exc).__name__}: {exc}"},
    )


@app.get("/api/health")
def health():
    return {"status": "ok", "version": "5.2.0", "migrated": migrated}


# 静态前端（放在最后，避免遮蔽 API）
frontend = Path(__file__).resolve().parent.parent / "frontend"
app.mount("/", StaticFiles(directory=str(frontend), html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
