# -*- coding: utf-8 -*-
"""
长期趋势项 A/B 对照：LT_TERM 开 vs 关，全起点对比
用法: python backend/lt_term_ab.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import long_history_backtest as lb  # noqa: E402

STARTS = [f"{y}-01-01" for y in range(2014, 2027)]

results = {"off": [], "on": []}
for mode in ("off", "on"):
    lb.LT_TERM = (mode == "on")
    # 重新计算评分（LT_TERM 影响 score_series）
    lb.scores = {c: lb.score_series(df) for c, df in lb.data.items()}
    print(f"===== LT_TERM = {mode} =====")
    print(f"{'起点':<12} {'年数':>5} | {'年化%':>8} {'夏普':>8} {'回撤%':>9} | {'等权年化%':>8} {'超额pp':>8}")
    for start in STARTS:
        r = lb.run_system(start, temp=True)
        b = lb.run_pool(start)
        if r is None or b is None:
            continue
        eq, dt, stops = r
        eqb, dtb = b
        t, a, sh, m = lb.metrics(eq, dt)
        tb, ab, shb, mb = lb.metrics(eqb, dtb)
        yrs = (dt[-1] - dt[0]).days / 365.25
        results[mode].append({"start": start, "years": yrs, "annual": a, "sharpe": sh, "mdd": m, "alpha": a - ab})
        print(f"{start:<12} {yrs:>5.1f} | {a:>+8.1f} {sh:>+8.2f} {m:>+9.1f} | {ab:>+8.1f} {a-ab:>+8.1f}")
    print()

import numpy as np  # noqa: E402
print("========== 汇总 ==========")
for mode in ("off", "on"):
    rs = results[mode]
    if not rs:
        continue
    ann = [r["annual"] for r in rs]
    alp = [r["alpha"] for r in rs]
    mdd = [r["mdd"] for r in rs]
    print(f"LT_TERM={mode}: 起点数={len(rs)}  年化中位={np.median(ann):+.2f}%  最好={max(ann):+.1f}%  最差={min(ann):+.1f}%  "
          f"正超额占比={100*sum(1 for x in alp if x > 0)/len(alp):.0f}%  回撤中位={np.median(mdd):+.1f}%")
print("\n判据: 年化中位数和正超额占比更高、回撤中位数更低 → 长期趋势项值得加入实盘评分。")
