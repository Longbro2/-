# -*- coding: utf-8 -*-
"""
CherryQuant 当期信号报告（诚实口径）
- 数据: data/cache/em_long/*.csv（东财全历史 OHLC，前复权，最新到最近交易日）
- 评分: 与 long_history_backtest.score_series 同口径（纯技术因子）
- 有效性: 滚动点内（近250日年化夏普>0.3）
- 输出: 买入关注Top5 / 观望 / 避开 名单 + 市场温度仓位建议
用法: python backend/today_signals.py
"""
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from long_history_backtest import (  # noqa: E402
    data, scores, raw_close, calc_indicators, pit_valid, CODE2NAME,
)
from engine.config import POOL, DATA_DIR  # noqa: E402

BUY_TH = {info["code"]: info["buy_th"] for _, info in POOL.items()}
SELL_TH = {info["code"]: info["sell_th"] for _, info in POOL.items()}

# 资金流因子（东财接口约120天）：5日主力净流入(万元)
FFLOW_DIR = DATA_DIR / "cache" / "fflow"
fflow5 = {}
for f in FFLOW_DIR.glob("*.csv"):
    try:
        ff = pd.read_csv(f)
        ff["date"] = pd.to_datetime(ff["date"])
        ff["m5"] = ff["main_net"].rolling(5).sum() / 1e4
        fflow5[f.stem] = float(ff["m5"].iloc[-1])
    except Exception:
        pass


def trend_state(df, i):
    c = df["close"].values
    if i < 60:
        return "数据不足", 0.0, 0.0
    r60 = (c[i] / c[i - 60] - 1) * 100
    r20 = (c[i] / c[i - 20] - 1) * 100
    r5 = (c[i] / c[i - 5] - 1) * 100
    if r60 > 5 and r5 > -2:
        return "强趋势", r60, r20
    if r60 > 5 and r20 < 0 and r5 > 0:
        return "回调企稳", r60, r20
    if r60 < -10 and r5 > 3:
        return "超跌反弹", r60, r20
    if r60 < -5:
        return "下跌趋势", r60, r20
    return "震荡", r60, r20


def main():
    rows = []
    for code, df in data.items():
        key = df["date"].iloc[-1].strftime("%Y-%m-%d")
        sc = scores[code].iloc[-1] if not pd.isna(scores[code].iloc[-1]) else np.nan
        valid = pit_valid(raw_close[code], df["date"].iloc[-1])
        tq, r60, r20 = trend_state(df, len(df) - 1)
        c = df["close"].values
        i = len(df) - 1

        def rn(n):
            return (c[i] / c[i - n] - 1) * 100 if i >= n and c[i - n] > 0 else np.nan

        vol_ratio = (df["volume"].iloc[-1] / df["volume"].tail(20).mean()
                     if df["volume"].tail(20).mean() > 0 else 0.0)
        buy_th, sell_th = BUY_TH.get(code, 50), SELL_TH.get(code, 25)
        if pd.isna(sc):
            sig = "数据不足"
        elif sc >= buy_th:
            sig = "BUY"
        elif sc <= sell_th:
            sig = "SELL"
        else:
            sig = "HOLD"
        rows.append({
            "code": code, "name": CODE2NAME[code], "score": sc, "signal": sig,
            "valid": "有效" if valid else "一般", "tq": tq,
            "r5": rn(5), "r20": rn(20), "r60": rn(60), "r120": rn(120), "r250": rn(250),
            "rmax": (c[i] / c[0] - 1) * 100 if c[0] > 0 else np.nan,
            "vol_ratio": vol_ratio, "flow5": fflow5.get(code, np.nan),
            "price": df["close"].iloc[-1], "date": key,
        })
    rdf = pd.DataFrame(rows).sort_values("score", ascending=False)

    print(f"数据截至: {data[list(data)[0]]['date'].iloc[-1].date()}  (东财前复权, 20只)")
    print("=" * 160)
    print(f"{'排名':<4} {'代码':<8} {'名称':<8} {'评分':>6} {'信号':<6} {'点内':<5} {'趋势':<8} "
          f"{'5日%':>7} {'20日%':>7} {'60日%':>7} {'120日%':>8} {'250日%':>8} {'上市以来%':>9} "
          f"{'量比':>6} {'主力5日(万)':>11} {'现价':>8}")
    print("-" * 160)
    for i, r in rdf.iterrows():
        sc = f"{r['score']:.0f}" if not pd.isna(r['score']) else "  ?"
        fl = f"{r['flow5']:+.0f}" if not pd.isna(r['flow5']) else "  ?"
        def fmt(v, w=7):
            return f"{v:+{w}.1f}" if pd.notna(v) else f"{'—':>{w}}"
        print(f"{rdf.index.get_loc(i)+1:<4} {r['code']:<8} {r['name']:<8} {sc:>6} {r['signal']:<6} "
              f"{r['valid']:<5} {r['tq']:<8} {fmt(r['r5'])} {fmt(r['r20'])} {fmt(r['r60'])} "
              f"{fmt(r['r120'], 8)} {fmt(r['r250'], 8)} {fmt(r['rmax'], 9)} "
              f"{r['vol_ratio']:>6.2f} {fl:>11} {r['price']:>8.3f}")

    # 买入关注 = 点内有效 & 信号BUY 的 Top5
    focus = rdf[(rdf["valid"] == "有效") & (rdf["signal"] == "BUY")].head(5)
    print("\n" + "=" * 160)
    print("【买入关注 Top5】（点内有效 + BUY 信号，按评分排序）")
    for _, r in focus.iterrows():
        fl = f"{r['flow5']:+.0f}万" if not pd.isna(r['flow5']) else "无数据"
        rm = f"{r['rmax']:+.1f}%" if pd.notna(r['rmax']) else "—"
        print(f"  {r['name']}({r['code']})  评分{r['score']:.0f}  趋势:{r['tq']}  "
              f"5日{r['r5']:+.1f}% 20日{r['r20']:+.1f}% 60日{r['r60']:+.1f}% "
              f"120日{r['r120']:+.1f}% 250日{r['r250']:+.1f}% 上市以来{rm}  主力5日{fl}  现价{r['price']:.3f}")

    # 市场温度：全池评分>=50 占比
    valid_scores = rdf["score"].dropna()
    hot = (valid_scores >= 50).mean() * 100
    if hot > 60:
        pos = "偏暖（>60%标的评分≥50）→ 建议仓位: 满仓区（可用资金的60-100%）"
    elif hot >= 40:
        pos = "中性（40-60%标的评分≥50）→ 建议仓位: 半仓区（30-60%）"
    else:
        pos = "偏冷（<40%标的评分≥50）→ 建议仓位: 防御区（≤30%，空仓等回暖）"
    print(f"\n市场温度: {hot:.0f}% {pos}")

    sell = rdf[rdf["signal"] == "SELL"]
    if len(sell):
        print("【当前SELL/避开】" + ", ".join(f"{r['name']}({r['code']})评分{r['score']:.0f}" for _, r in sell.iterrows()))
    print("\n风险提示: 信号仅供研究参考，不构成投资建议；历史表现不代表未来。")


if __name__ == "__main__":
    main()
