# -*- coding: utf-8 -*-
"""
CherryQuant Web — 资金流稳定性检查
每天运行一次，记录 20 只 ETF 的资金流数据可用性，追加到日志。
一周后汇总评估：数据源是否稳定、能否连续拉取、有无异常波动。

运行: python backend/check_fflow_stability.py
"""
import sys
import json
import os
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from engine import fflow
from engine.config import POOL

LOG_FILE = Path(__file__).resolve().parent.parent / "data" / "fflow_stability.jsonl"


def check_once() -> dict:
    """检查全部 ETF 资金流数据可用性"""
    today = datetime.now().strftime("%Y-%m-%d %H:%M")
    ok = 0
    stale = 0
    failed = []
    latest_dates = []
    main_nets = {}

    for name, info in POOL.items():
        code = info["code"]
        try:
            df = fflow.fetch_fflow(code, offline=True)
            if len(df) == 0:
                # 尝试联网拉取
                df = fflow.fetch_fflow(code, force=True)
            if len(df) == 0:
                failed.append(code)
                continue
            ok += 1
            last = df["date"].iloc[-1]
            last_str = last.strftime("%Y-%m-%d") if hasattr(last, "strftime") else str(last)
            latest_dates.append(last_str)
            # 记录最新主力净流入
            main_nets[code] = round(float(df["main_net"].iloc[-1]) / 1e4, 1)  # 万元
            if last_str < datetime.now().strftime("%Y-%m-%d"):
                stale += 1
        except Exception as e:
            failed.append(f"{code}:{e}")

    return {
        "time": today,
        "total": len(POOL),
        "ok": ok,
        "stale": stale,
        "failed": failed,
        "latest_dates": latest_dates,
        "main_nets": main_nets,
    }


def append_log(entry: dict):
    """追加到 JSONL 日志"""
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def summary():
    """汇总日志，输出稳定性报告"""
    if not LOG_FILE.exists():
        return "暂无日志"
    entries = []
    with open(LOG_FILE, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                entries.append(json.loads(line))

    days = len(entries)
    if days == 0:
        return "暂无日志"

    total_ok = sum(e["ok"] for e in entries)
    total_total = sum(e["total"] for e in entries)
    success_rate = total_ok / total_total * 100 if total_total else 0
    all_failures = [f for e in entries for f in e["failed"]]

    return {
        "days_tracked": days,
        "success_rate": round(success_rate, 1),
        "total_checks": total_total,
        "ok_checks": total_ok,
        "failure_events": len(all_failures),
        "failures": all_failures[:10],
        "entries": entries,
    }


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--summary":
        result = summary()
        if isinstance(result, str):
            print(result)
        else:
            print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        entry = check_once()
        append_log(entry)
        print(json.dumps(entry, ensure_ascii=False, indent=2))
        print(f"\n✅ 已记录到 {LOG_FILE}")
        # 如果今天数据都正常，给个提示
        if entry["failed"]:
            print(f"⚠️ {len(entry['failed'])} 只资金流获取失败")
