# -*- coding: utf-8 -*-
"""
CherryQuant Web — 每日止盈止损检查
检查持仓是否触发止盈/止损，返回需要提醒的标的。
由 cron 定时任务每天调用。

用法: python backend/check_stop.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))

from engine import db, signals
from engine.config import CODE2NAME


def check_stops() -> list:
    """返回触发了止盈/止损的持仓列表"""
    positions = db.load_positions()
    if not positions:
        return []

    alerts = []
    for code, pos in positions.items():
        df = signals.fetch(code, offline=True)
        if len(df) == 0:
            continue
        current = float(df["close"].iloc[-1])
        sl = signals.stop_loss_check(code, pos, current)

        name = pos.get("name", CODE2NAME.get(code, code))
        cost = pos["cost_price"]

        if sl["stop_triggered"]:
            alerts.append({
                "code": code, "name": name,
                "type": "止损", "reason": f"亏损{sl['pnl_pct']}% / 回撤{sl['drawdown']}%",
                "cost": cost, "current": current, "pnl_pct": sl["pnl_pct"],
            })
        elif sl["take_profit"]:
            reason = f"盈利{sl['pnl_pct']}%"
            if sl.get("trailing_take"):
                reason += f"（从峰值{sl['peak']}回撤触发）"
            alerts.append({
                "code": code, "name": name,
                "type": "止盈", "reason": reason,
                "cost": cost, "current": current, "pnl_pct": sl["pnl_pct"],
            })

    return alerts


if __name__ == "__main__":
    alerts = check_stops()
    if alerts:
        print("⚠️ 触发止盈/止损的持仓:")
        for a in alerts:
            print(f"  [{a['type']}] {a['name']}({a['code']}): {a['reason']} | 现价{a['current']}")
    else:
        print("✅ 今日无触发止盈/止损的持仓")
