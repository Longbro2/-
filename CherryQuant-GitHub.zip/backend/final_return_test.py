# -*- coding: utf-8 -*-
"""最终收益测试：最新系统（验证Top3 + 评分加权 + 温度择时）
覆盖多区间，展示各维度收益数据。
"""
import sys
sys.path.insert(0, 'D:/Projects/quant-web/backend')
import numpy as np
import pandas as pd
from engine.data import _read_csv, _csv_path
from engine.signals import calc_indicators, _score
from engine.config import POOL
from engine.verify import load_verify_map

vmap = load_verify_map()

# ============ 加载 + 预计算 ============
print('加载数据并预计算...')
all_data, all_scores = {}, {}
for name, info in POOL.items():
    code = info['code']
    df = _read_csv(_csv_path('tencent', code))
    if len(df) < 100:
        continue
    all_data[code] = df
    ind = calc_indicators(df, lag=True)
    c_arr = df['close'].values
    n = len(ind)
    scores = np.full(n, np.nan)
    for i in range(60, n):
        row = ind.iloc[i]
        macd_b = bool(row['macd'] > row['macd_signal'])
        prev = ind.iloc[i-1]
        macd_cross = bool(prev['macd'] <= prev['macd_signal']) and macd_b
        ma_b = bool(row['ma5'] > row['ma20'] > row['ma50'])
        rsi = row['rsi']
        mom5 = row['mom_5d'] if pd.notna(row['mom_5d']) else 0
        c = c_arr[i]
        r60 = (c/c_arr[i-60]-1)*100 if c_arr[i-60] > 0 else 0
        r20 = (c/c_arr[i-20]-1)*100 if c_arr[i-20] > 0 else 0
        r5 = (c/c_arr[i-5]-1)*100 if c_arr[i-5] > 0 else 0
        if r60 > 3 and r5 > -2: tq = '强趋势'
        elif r60 > 3 and r20 < 0 and r5 > 0: tq = '回调企稳'
        elif r60 < -10 and r5 > 3: tq = '超跌反弹'
        elif r60 < -5: tq = '下跌趋势'
        else: tq = '震荡'
        scores[i] = _score(macd_b, macd_cross, ma_b, rsi, mom5,
                           bool(row.get('pat_w')), bool(row.get('pat_div')),
                           bool(row.get('pat_brk')), int(row.get('macd_quality', 0)),
                           trend_quality=tq)
    all_scores[code] = pd.Series(scores, index=pd.to_datetime(df['date']))

# 面板
all_dates = set()
for s in all_scores.values():
    all_dates.update(s.index.strftime('%Y-%m-%d'))
dates = sorted(all_dates)
close_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
score_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
for code, df in all_data.items():
    dstr = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
    close_panel.loc[dstr, code] = df['close'].values
    sc = all_scores[code]
    sc_idx = sc.index.strftime('%Y-%m-%d')
    score_panel.loc[sc_idx, code] = sc.values
print(f'  面板: {len(dates)} 天, {len(all_data)} 标的')

# ============ 回测函数 ============
def run_backtest(start='2016-01-01', topn=3, use_weight=True, temp_filter=True):
    start_idx = next((i for i, d in enumerate(dates) if d >= start), 0)
    sub_dates = dates[start_idx:]
    n_days = len(sub_dates)
    equity = 100000.0
    holdings = []
    nav = np.zeros(n_days)
    rebal_days = set(range(0, n_days, 20))

    for j, d in enumerate(sub_dates):
        if j in rebal_days:
            scores_today = score_panel.loc[d]
            close_today = close_panel.loc[d]
            available = {}
            avg = []
            for code in all_data.keys():
                sc = scores_today[code]; px = close_today[code]
                if not np.isnan(sc) and not np.isnan(px) and px > 0:
                    available[code] = (sc, px); avg.append(sc)
            market_temp = np.mean(avg) if avg else 50
            ratio = 1.0
            if temp_filter:
                ratio = 1.0 if market_temp > 60 else (0.5 if market_temp >= 40 else 0.0)

            for code, sh in holdings:
                px = close_panel.loc[d, code]
                if not np.isnan(px): equity += sh * float(px)
            holdings = []

            if available and ratio > 0:
                valid = [c for c, (sc, px) in available.items() if vmap.get(c, {}).get('verdict') == 'valid']
                if len(valid) >= 3:
                    selected = sorted(valid, key=lambda c: -available[c][0])[:topn]
                else:
                    selected = sorted(available.keys(), key=lambda c: -available[c][0])[:topn]
                invest = equity * ratio
                if selected and invest > 0:
                    if use_weight:
                        # 评分加权，单只40%上限
                        scs = np.array([available[c][0] for c in selected])
                        w = np.maximum(scs - 40, 1) ** 1.5
                        w = w / w.sum()
                        MAX = 0.4
                        over = w > MAX
                        if over.any():
                            surplus = (w[over] - MAX).sum()
                            w[over] = MAX
                            if (~over).any():
                                w[~over] += surplus / (~over).sum()
                        allocs = invest * w
                    else:
                        allocs = np.full(len(selected), invest / len(selected))
                    for code, alloc in zip(selected, allocs):
                        px = available[code][1]
                        sh = int(alloc / px // 100 * 100)
                        if sh > 0:
                            holdings.append((code, sh))
                            equity -= sh * px
        mv = equity
        for code, sh in holdings:
            px = close_panel.loc[d, code]
            if not np.isnan(px): mv += sh * float(px)
        nav[j] = mv

    nav = pd.Series(nav, index=pd.to_datetime(sub_dates))
    total = (nav.iloc[-1] / nav.iloc[0] - 1) * 100
    years = (pd.Timestamp(sub_dates[-1]) - pd.Timestamp(sub_dates[0])).days / 365
    annual = ((nav.iloc[-1] / nav.iloc[0]) ** (1 / years) - 1) * 100 if years > 0 and nav.iloc[0] > 0 else 0
    r = nav.pct_change().dropna()
    sharpe = (r.mean() / r.std()) * np.sqrt(252) if r.std() > 0 else 0
    mdd = float(((nav / nav.cummax()) - 1).min() * 100)
    # 年化波动率
    vol = float(r.std() * np.sqrt(252) * 100)
    # 胜率（盈利月份占比）
    monthly = nav.resample('ME').last()
    mret = monthly.pct_change().dropna()
    win_rate = float((mret > 0).mean() * 100) if len(mret) else 0
    return {'total': total, 'annual': annual, 'sharpe': sharpe, 'mdd': mdd,
            'vol': vol, 'win_rate': win_rate, 'years': years, 'n_days': n_days}


# ============ 运行 ============
print()
print('=' * 76)
print('  最终收益报告：验证Top3 + 评分加权 + 温度择时')
print('=' * 76)
print()
print('%-16s %-10s %-9s %-8s %-8s %-8s %-8s' % ('区间', '总收益', '年化', '夏普', '回撤', '波动', '月胜率'))
print('-' * 76)

starts = ['2016-01-01', '2018-01-01', '2020-01-01', '2021-01-01', '2022-01-01', '2023-01-01']
for s in starts:
    r = run_backtest(s)
    print('%-16s %+8.1f%% %+7.1f%% %7.2f %6.1f%% %6.1f%% %6.1f%%' % (
        f'{s[:4]}起({r["years"]:.1f}年)', r['total'], r['annual'], r['sharpe'], r['mdd'], r['vol'], r['win_rate']))

print()
print('=' * 76)
print('  对比：当前系统 vs 基准')
print('=' * 76)
print()

# 对照：无温度择时(满仓) vs 有温度择时
print('%-16s %-14s %-14s' % ('区间(近5.6年)', '满仓穿越', '温度择时'))
print('-' * 46)
for s in ['2021-01-01', '2023-01-01']:
    r_full = run_backtest(s, temp_filter=False)
    r_temp = run_backtest(s, temp_filter=True)
    print('%-16s %+9.1f%%(回撤%.0f%%) %+9.1f%%(回撤%.0f%%)' % (
        f'{s[:4]}起', r_full['total'], r_full['mdd'], r_temp['total'], r_temp['mdd']))

# 对照：等权 vs 评分加权
print()
print('%-16s %-14s %-14s' % ('区间(近5.6年)', '等权', '评分加权'))
print('-' * 46)
for s in ['2021-01-01', '2023-01-01']:
    r_eq = run_backtest(s, use_weight=False)
    r_wt = run_backtest(s, use_weight=True)
    print('%-16s %+9.1f%% %+9.1f%%' % (f'{s[:4]}起', r_eq['total'], r_wt['total']))

print()
print('完成。')
