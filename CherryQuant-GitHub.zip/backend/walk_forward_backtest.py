# -*- coding: utf-8 -*-
"""滚动回测（Walk-Forward）— 防过拟合验证（口径已对齐主引擎）
核心思想：每年只用"之前的数据"定参（点内验证有效标的），然后在"之后"真实回测。
- 评分/tq 阈值：research_common.score_series（与 engine.backtest.ScoreStrategy 一致）
- 成本：佣金万3 + 滑点千1，买卖双向
- 滚动回测完全点内（无未来函数）；静态回测保留全历史标签作对照（有偏，仅用于演示偏差大小）
"""
import sys
sys.path.insert(0, 'D:/Projects/quant-web/backend')
import numpy as np
import pandas as pd
from engine.data import _read_csv, _csv_path
from engine.config import POOL
from research_common import score_series, pit_valid, buy_lot, sell_proceeds

# ============ 1. 加载数据 + 预计算分数序列 ============
print('加载数据并预计算分数...')
all_data, all_scores, closes = {}, {}, {}
for name, info in POOL.items():
    code = info['code']
    df = _read_csv(_csv_path('tencent', code))
    if len(df) < 100:
        continue
    all_data[code] = df
    all_scores[code] = score_series(df)
    closes[code] = pd.Series(
        df['close'].values,
        index=pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d'))
print(f'  {len(all_data)} 只标的')

# ============ 2. 面板 ============
all_dates = set()
for s in all_scores.values():
    all_dates.update(s.index.strftime('%Y-%m-%d'))
dates = sorted(all_dates)
close_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
score_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
for code, df in all_data.items():
    dstr = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
    close_panel.loc[dstr, code] = df['close'].values
    sc = all_scores[code]
    sc_idx = sc.index.strftime('%Y-%m-%d')
    score_panel.loc[sc_idx, code] = sc.values


def _roll(code, train_end_date, valid_set_out=None):
    """点内验证：train_end_date 之前近一年年化夏普>0.3 → 当时有效"""
    return pit_valid(closes[code], train_end_date, min_sharpe=0.3)


def _run_panel(sub_dates, valid_fn, rebalance=20, topn=3):
    """通用面板回测：valid_fn(d) → 当日有效的代码集合(set)。
    每 rebalance 天调仓：先全部卖出(计成本) → 按温度定仓位 → 点内有效+评分 TopN。
    返回 nav Series。"""
    n_days = len(sub_dates)
    equity = 100000.0
    holdings = {}
    nav = np.zeros(n_days)
    rebal_days = set(range(0, n_days, rebalance))
    for j, d in enumerate(sub_dates):
        if j in rebal_days:
            scores_today = score_panel.loc[d]
            close_today = close_panel.loc[d]
            available = {}
            avg = []
            for code in all_data.keys():
                sc = scores_today[code]
                px = close_today[code]
                if not np.isnan(sc) and not np.isnan(px) and px > 0:
                    available[code] = (sc, px)
                    avg.append(sc)
            market_temp = np.mean(avg) if avg else 50
            ratio = 1.0 if market_temp > 60 else (0.5 if market_temp >= 40 else 0.0)

            for code, sh in holdings.items():
                px = close_panel.loc[d, code]
                if not np.isnan(px):
                    equity += sell_proceeds(sh, float(px))
            holdings = {}

            if available and ratio > 0:
                valid = [c for c in available if c in valid_fn(d)]
                if len(valid) >= 3:
                    selected = sorted(valid, key=lambda c: -available[c][0])[:topn]
                else:
                    selected = sorted(available.keys(), key=lambda c: -available[c][0])[:topn]
                invest = equity * ratio
                if selected and invest > 0:
                    per = invest / len(selected)
                    for code in selected:
                        px = available[code][1]
                        sh, spend = buy_lot(per, float(px))
                        if sh > 0:
                            holdings[code] = sh
                            equity -= spend
        mv = equity
        for code, sh in holdings.items():
            px = close_panel.loc[d, code]
            if not np.isnan(px):
                mv += sh * float(px)
        nav[j] = mv
    return pd.Series(nav, index=sub_dates)


def _stats(nav: pd.Series) -> dict:
    total = (nav.iloc[-1] / nav.iloc[0] - 1) * 100
    years = (pd.Timestamp(nav.index[-1]) - pd.Timestamp(nav.index[0])).days / 365
    annual = ((nav.iloc[-1] / nav.iloc[0]) ** (1 / years) - 1) * 100 if years > 0 and nav.iloc[0] > 0 else 0
    r = nav.pct_change().dropna()
    sharpe = (r.mean() / r.std()) * np.sqrt(252) if r.std() > 0 else 0
    mdd = float(((nav / nav.cummax()) - 1).min() * 100)
    return {'total': total, 'annual': annual, 'sharpe': sharpe, 'mdd': mdd, 'years': years}


def walk_forward_backtest(train_years=1, start='2018-01-01', topn=3, rebalance=20):
    """滚动回测：每 250 个交易日窗口，用窗口起点往前 train_years 年数据做点内验证。"""
    start_idx = next((i for i, d in enumerate(dates) if d >= start), 0)
    sub_dates = dates[start_idx:]
    n_days = len(sub_dates)
    window_start_idx = 0
    valid_cache = {}  # window_begin_idx -> set(valid)

    def valid_fn(d):
        # 找到包含 d 的最近窗口起点
        ws = 0
        for w, vs in valid_cache.items():
            if w <= d:
                ws = w
        return valid_cache.get(ws, set())

    # 预滚动：逐窗口计算 valid_set（纯点内，不查未来）
    idx_map = {d: j for j, d in enumerate(sub_dates)}
    # 简化为按日历每 250 天评估一次：窗口起点=每个 j % 250 == 0
    for j, d in enumerate(sub_dates):
        if j % 250 == 0:
            cutoff = (pd.Timestamp(d) - pd.DateOffset(years=train_years)).strftime('%Y-%m-%d')
            valid_cache[d] = {c for c in all_data.keys() if _roll(c, cutoff)}

    nav = _run_panel(sub_dates, valid_fn, rebalance=rebalance, topn=topn)
    st = _stats(nav)
    st['n_days'] = n_days
    return st


def static_backtest(start='2018-01-01', topn=3, rebalance=20):
    """静态对照：仍用全历史验证标签选标的（保留该有偏口径以展示偏差；含成本）。"""
    from engine.verify import load_verify_map
    vmap = load_verify_map()
    start_idx = next((i for i, d in enumerate(dates) if d >= start), 0)
    sub_dates = dates[start_idx:]

    def valid_fn(d):
        return {c for c, v in vmap.items() if v.get('verdict') == 'valid'}

    nav = _run_panel(sub_dates, valid_fn, rebalance=rebalance, topn=topn)
    st = _stats(nav)
    st['n_days'] = len(sub_dates)
    return st


# ============ 运行 ============
print()
print('=' * 72)
print('  滚动回测（Walk-Forward）vs 静态回测 — 防过拟合验证（含佣金滑点）')
print('=' * 72)
print()
print('静态回测 = 用全部历史标签选标的再回测同段（有未来函数嫌疑，仅作对照）')
print('滚动回测 = 每窗口只用之前数据做点内验证（真实无未来函数）')
print()

print('%-14s %-12s %-10s %-8s %-8s' % ('区间', '总收益', '年化', '夏普', '回撤'))
print('-' * 56)

for start in ['2018-01-01', '2021-01-01', '2023-01-01']:
    r_static = static_backtest(start)
    r_roll = walk_forward_backtest(train_years=1, start=start)
    print(f'[{start[:4]}起 {r_roll["years"]:.1f}年]')
    print(f'  静态回测: %+7.1f%% %+7.1f%% %6.2f %6.1f%%' % (r_static['total'], r_static['annual'], r_static['sharpe'], r_static['mdd']))
    print(f'  滚动回测: %+7.1f%% %+7.1f%% %6.2f %6.1f%%' % (r_roll['total'], r_roll['annual'], r_roll['sharpe'], r_roll['mdd']))
    print()
