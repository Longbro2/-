# -*- coding: utf-8 -*-
"""
CherryQuant Web — 交易指令生成器
把系统操作指令格式化为可复制的交易指令文本，方便粘贴到券商APP。
"""
from . import signals


def generate_trade_orders() -> dict:
    """
    生成可执行的交易指令文本。
    只输出需要行动的：加仓/买入/卖出/止盈/减仓/警惕(持仓)。
    """
    scan = signals.scan_all_signals()
    instructions = scan.get("instructions", [])
    holdings = {h["code"] for h in scan["holdings"]}

    orders = []
    lines = ["【CherryQuant 交易指令】", f"日期: {scan['generated_at'][:10]}", ""]

    # 需要行动的指令
    actionable = {"买入", "加仓", "卖出", "止盈", "减仓", "警惕"}
    for i in instructions:
        if i["action"] in actionable:
            action_txt = {
                "买入": "买入", "加仓": "买入(加仓)",
                "卖出": "卖出", "止盈": "卖出(止盈)",
                "减仓": "卖出(减仓)", "警惕": "关注(谨慎)",
            }.get(i["action"], i["action"])
            is_holding = i["code"] in holdings
            line = f"{action_txt}：{i['name']} {i['code']}"
            if i.get("current_price"):
                line += f"  现价{i['current_price']}"
            if i.get("stop"):
                line += f"  止损{i['stop']}"
            if i.get("take"):
                line += f"  止盈{i['take']}"
            if i.get("position_hint") and i["position_hint"] != "未持仓":
                line += f"  {i['position_hint']}"
            if not is_holding:
                line += "  [未持仓-新开仓]"
            line += f"  理由:{i['reason']}"
            lines.append(line)
            orders.append({
                "action": i["action"], "name": i["name"], "code": i["code"],
                "price": i.get("current_price"),
                "stop": i.get("stop"), "take": i.get("take"),
                "reason": i["reason"],
                "position_hint": i.get("position_hint"),
            })

    # 风险提示
    lines.append("")
    lines.append("【风控提醒】")
    for h in scan["holdings"]:
        if h["pnl_pct"] is not None and h["pnl_pct"] < -8:
            lines.append(f"- {h['name']} 亏损{h['pnl_pct']}%，接近止损线")

    # 纪律提示
    disc = scan.get("discipline", {})
    lines.append("")
    lines.append(f"【纪律】买入{ '允许' if disc.get('allowed') else '已锁定' } | {disc.get('msg', '')}")

    return {
        "text": "\n".join(lines),
        "orders": orders,
        "market_temp": scan["market"]["temp"],
    }
