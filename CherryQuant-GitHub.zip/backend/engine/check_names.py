# -*- coding: utf-8 -*-
"""
CherryQuant Web — ETF 名称核对工具
自动从腾讯行情拉取每只ETF的官方名称，与 config.py 池配置比对，
发现"系统叫的名字 ≠ 真实跟踪标的"的配置错误。

用法:
  from engine.check_names import verify_etf_names
  result = verify_etf_names()   # 返回核对结果
"""
import time
import requests
from .config import POOL


def fetch_real_name(code: str, timeout: int = 6) -> str | None:
    """从腾讯拉取某ETF的官方简称"""
    prefix = "sh" if code.startswith(("5", "6")) else "sz"
    sym = prefix + code
    try:
        r = requests.get(
            f"https://qt.gtimg.cn/q={sym}",
            headers={"User-Agent": "Mozilla/5.0", "Referer": "https://gu.qq.com/"},
            timeout=timeout,
        )
        fields = r.text.split("=", 1)[1].split("~")
        if len(fields) > 1 and fields[1]:
            return fields[1].strip()
    except Exception:
        pass
    return None


def name_matches(config_name: str, real_name: str) -> bool:
    """判断配置名和腾讯官方名是否匹配（忽略ETF后缀差异）"""
    if not real_name:
        return True  # 拉取失败不误报
    # 去掉常见的ETF后缀词，比较核心关键词
    config_core = config_name.replace("ETF", "").strip()
    real_core = real_name.replace("ETF", "").replace("华夏", "").replace("易方达", "") \
        .replace("国泰", "").replace("广发", "").replace("天弘", "").replace("华泰柏瑞", "") \
        .replace("南方", "").replace("华宝", "").replace("鹏华", "").replace("工银", "") \
        .replace("汇添富", "")
    # 配置名是真实名的子串，或反向（双向匹配一个即可）
    return (config_core in real_core) or (real_core in config_core) or (config_core == real_core)


def verify_etf_names(quiet: bool = True) -> dict:
    """
    核对全池ETF名称。返回:
      ok: 名称匹配的列表
      mismatch: 名称不匹配的列表（需人工检查）
      failed: 拉取失败的列表
    """
    ok, mismatch, failed = [], [], []
    for name, info in POOL.items():
        code = info["code"]
        real = fetch_real_name(code)
        if real is None:
            failed.append({"code": code, "config_name": name})
            continue
        if name_matches(name, real):
            ok.append({"code": code, "config_name": name, "real_name": real})
        else:
            mismatch.append({"code": code, "config_name": name, "real_name": real})
        time.sleep(0.15)  # 避免被限流

    return {
        "total": len(POOL),
        "ok": ok,
        "mismatch": mismatch,
        "failed": failed,
        "all_correct": len(mismatch) == 0 and len(failed) == 0,
    }


if __name__ == "__main__":
    import json
    result = verify_etf_names(quiet=False)
    print(f"=== ETF 名称核对结果 ===")
    print(f"总计 {result['total']} 只")
    print(f"✅ 匹配 {len(result['ok'])} 只")
    if result["mismatch"]:
        print(f"\n❌ 不匹配 {len(result['mismatch'])} 只:")
        for m in result["mismatch"]:
            print(f"  {m['code']}: 系统叫[{m['config_name']}] 实际是[{m['real_name']}]")
    if result["failed"]:
        print(f"\n⚠️ 拉取失败 {len(result['failed'])} 只:")
        for f in result["failed"]:
            print(f"  {f['code']}: {f['config_name']}")
    print(f"\n全部正确: {result['all_correct']}")
