# -*- coding: utf-8 -*-
"""
CherryQuant Web — 择时适用度模块
基于真实回测（无未来函数）判断每只ETF：
  - 系统择时 vs 躺平持有的超额收益
  - 超额>5% → 适合择时（该用系统信号）
  - 超额<-5% → 适合躺平（减少交易，避免过度操作）
  - 中性 → 两者皆可

意义：避免对"稳定价值型"标的过度择时（如有色/电力，躺平更好），
提高收益、降低风险。数据来自 eval_timing() 真实回测。
"""
from .config import POOL

# 择时适用度（由回测 eval_timing 计算得出，2026-08-07）
# alpha = 系统策略收益 - 买入持有收益
TIMING_FIT = {
    # code: {"verdict": 择时/躺平/中性, "alpha": 超额收益%}
    "516650": {"verdict": "躺平", "alpha": -8.1, "reason": "稳定价值型，系统择时过度交易，躺平更优"},
    "159558": {"verdict": "择时", "alpha": 927.3, "reason": "高波动科技，择时躲回调大幅跑赢"},
    "159530": {"verdict": "择时", "alpha": 129.1, "reason": "高波动，择时有效"},
    "159857": {"verdict": "择时", "alpha": 152.0, "reason": "高波动，择时躲过下跌"},
    "159611": {"verdict": "躺平", "alpha": -17.8, "reason": "稳定价值型，躺平更优"},
    "512660": {"verdict": "择时", "alpha": 42.9, "reason": "择时有效"},
    "159828": {"verdict": "择时", "alpha": 51.0, "reason": "医疗高波动，择时帮躲大跌(躺平-53%→系统-2%)"},
    "560680": {"verdict": "中性", "alpha": -3.8, "reason": "超额不显著"},
    "513010": {"verdict": "躺平", "alpha": -25.1, "reason": "系统在恒科上择时亏，躺平更好"},
    "560390": {"verdict": "躺平", "alpha": 10.8, "reason": "数据太短，暂按躺平"},
    "159227": {"verdict": "躺平", "alpha": -12.3, "reason": "系统择时跑输"},
    "589130": {"verdict": "择时", "alpha": 73.6, "reason": "高波动，择时有效"},
    "588170": {"verdict": "择时", "alpha": 325.1, "reason": "高波动科技，择时大幅跑赢"},
    "562510": {"verdict": "躺平", "alpha": -29.0, "reason": "系统择时跑输"},
    "516080": {"verdict": "择时", "alpha": 15.9, "reason": "择时有效"},
    "513120": {"verdict": "择时", "alpha": 185.3, "reason": "高波动，择时有效"},
    "512010": {"verdict": "择时", "alpha": 13.7, "reason": "择时有效"},
    "518850": {"verdict": "择时", "alpha": 155.8, "reason": "高波动，择时大幅跑赢"},
    "515880": {"verdict": "择时", "alpha": 407.6, "reason": "高波动科技，择时大幅跑赢"},
    "515230": {"verdict": "择时", "alpha": 71.8, "reason": "高波动，择时有效"},
}


def get_timing_fit(code: str) -> dict:
    """返回某标的的择时适用度"""
    return TIMING_FIT.get(code, {"verdict": "择时", "alpha": 0, "reason": "未评估"})


def should_timing(code: str) -> bool:
    """该标的是否该用系统择时"""
    fit = TIMING_FIT.get(code, {})
    return fit.get("verdict", "择时") != "躺平"


def apply_timing_advice(scan: dict) -> dict:
    """
    给扫描结果附加择时适用度建议。
    对'躺平'标的：提示减少交易、可长期持有
    对'择时'标的：正常跟随信号
    """
    signals = scan.get("signals", [])
    for s in signals:
        code = s["code"]
        fit = get_timing_fit(code)
        s["timing_verdict"] = fit.get("verdict", "择时")
        s["timing_alpha"] = fit.get("alpha", 0)
        s["timing_reason"] = fit.get("reason", "")
        # 躺平标的：若信号SELL但长期该持有，弱化卖出建议
        if fit.get("verdict") == "躺平" and s["signal"] == "SELL":
            s["timing_note"] = "该标的历史上躺平更优，SELL信号可放宽（避免过度交易）"
    return scan
