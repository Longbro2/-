# -*- coding: utf-8 -*-
"""
CherryQuant Web — 收益优化调仓引擎
目标：让收益变大。把三类优化整合成一份可执行的调仓路线图：
  1. 结构性调仓 —— 资金从「验证无效」标的挪向「验证有效」标的（样本外验证证明：有效池收益远高于无效持仓）
  2. 严格跟信号 —— 只跟系统规则 + ML 双确认的买卖信号，不信"感觉"
  3. 止损纪律 —— 先保命再谈收益：止损/止盈/回撤控制是收益的前提

输出：
  holdings_plan: 每只持仓的动作（持有/加仓/减仓/卖出/止盈/止损）+ 理由 + 优先级
  buy_candidates: 值得买入的候选（未持仓 + 验证有效 + 信号强）
  sell_priority / buy_priority: 按优先级排序的钱流方向
  summary: 一句话结论
  risk_notes: 诚实风险提示
"""
import numpy as np

from .verify import load_verify_map
from .decision import decide_holding, decide_buy, ORDER as DECISION_ORDER
from . import db
from .config import CODE2NAME


# 动作优先级（越小越紧急）
PRIORITY = {"止损卖出": 0, "止盈卖出": 1, "减仓": 2, "卖出(结构)": 2,
            "加仓": 3, "买入": 3, "持有": 9, "观望": 10, "回避": 11}


def _verify_weight(v: str) -> float:
    """验证状态 → 长期可靠性权重（结构性调仓的第一依据）"""
    return {"valid": 1.0, "weak": 0.5, "invalid": 0.15, "nodata": 0.4}.get(v, 0.4)


def _signal_weight(sig: str, score: float) -> float:
    """当前信号强度（短期择时依据）"""
    if sig == "BUY":
        return 0.5 + min(0.5, score / 200.0)
    if sig == "SELL":
        return -0.8
    return 0.0


def _fflow_weight(fflow5) -> float:
    """资金流（5日主力净流入，万元）→ -1~1"""
    if fflow5 is None or np.isnan(fflow5):
        return 0.0
    return max(-1.0, min(1.0, fflow5 / 3000.0))


def _ml_weight(ml: dict) -> float:
    """ML 概率 → -1~1，0.5中性"""
    p = (ml or {}).get("proba")
    if p is None:
        return 0.0
    return (float(p) - 0.5) * 2.0


def optimize_rebalance(scan: dict = None) -> dict:
    """
    生成收益优化调仓路线图。
    scan: scan_all_signals() 结果，可复用避免重复计算。
    """
    from .signals import scan_all_signals
    scan = scan or scan_all_signals()
    signals = {s["code"]: s for s in scan["signals"]}
    holdings = {h["code"]: h for h in scan["holdings"]}
    vmap = load_verify_map()
    ml_signals = scan.get("ml_signals", {})
    market_temp = scan["market"]["temp"]

    # ============ 1. 持仓逐只决策 ============
    holdings_plan = []
    for code, pos in holdings.items():
        s = signals.get(code, {})
        verify = vmap.get(code, {}).get("verdict", "nodata")
        ml = ml_signals.get(code, {})
        pnl = pos.get("pnl_pct")
        score = s.get("score", 0)
        sig = s.get("signal", "?")

        # 收益分：长期可靠性(0.5) + 短期择时(0.3) + 资金流(0.1) + ML(0.1)
        profit_score = (
            0.5 * _verify_weight(verify) +
            0.3 * _signal_weight(sig, score) +
            0.1 * _fflow_weight(s.get("main_net_5d")) +
            0.1 * _ml_weight(ml)
        )

        # ---- 动作判定（统一决策引擎，与 advice/instructions 一致） ----
        action, reason, priority = decide_holding(s, pos, verify, ml)
        # 统一决策返回的 action 已含结构性卖出，补充分数上下文。
        # 注意：止损/止盈触发的“卖出”是纪律动作(应全卖)，不能被验证无效
        # 改写成“卖出(结构)”(卖一半)——旧实现会把硬止损悄悄降级成半仓卖出。
        if action == "卖出" and verify == "invalid" and pos.get("status") not in ("止损触发", "止盈触发"):
            action = "卖出(结构)"

        holdings_plan.append({
            "code": code, "name": pos.get("name", CODE2NAME.get(code, code)),
            "shares": pos["shares"], "price": s.get("price"),
            "pnl_pct": pnl, "score": score, "signal": sig,
            "verify": verify, "verify_label": vmap.get(code, {}).get("label", "?"),
            "action": action, "reason": reason, "priority": priority,
            "profit_score": round(profit_score, 2),
            # 卖出比例：结构性卖出卖一半(低位保留反弹机会)，止损/止盈全卖
            "sell_ratio": 0.5 if action in ("卖出(结构)", "减仓") else 1.0,
        })

    # ============ 2. 买入候选（未持仓 + 验证有效 + 信号强） ============
    holding_codes = set(holdings.keys())
    buy_candidates = []
    for s in scan["signals"]:
        code = s["code"]
        if code in holding_codes:
            continue
        verify = vmap.get(code, {}).get("verdict", "nodata")
        ml = ml_signals.get(code, {})
        score = s.get("score", 0)
        sig = s.get("signal", "?")

        if verify != "valid" and sig != "BUY":
            continue
        profit_score = (
            0.5 * _verify_weight(verify) +
            0.3 * _signal_weight(sig, score) +
            0.1 * _fflow_weight(s.get("main_net_5d")) +
            0.1 * _ml_weight(ml)
        )
        # 候选门槛：综合分 >= 0.5，且不是 ML 强看空
        ml_proba = ml.get("proba")
        if profit_score < 0.5 or (ml_proba is not None and ml_proba < 0.4):
            continue

        reason_parts = []
        if verify == "valid":
            reason_parts.append(f"验证有效({vmap[code].get('label','✅')})")
        if sig == "BUY":
            reason_parts.append(f"信号BUY(评分{score:.0f})")
        if s.get("main_net_5d", 0) and s["main_net_5d"] > 0:
            reason_parts.append(f"资金流入{s['main_net_5d']:.0f}万")
        if ml_proba is not None and ml_proba > 0.55:
            reason_parts.append(f"ML看多({ml_proba:.2f})")

        buy_candidates.append({
            "code": code, "name": s["name"], "price": s.get("price"),
            "score": score, "signal": sig, "verify": verify,
            "verify_label": vmap.get(code, {}).get("label", "?"),
            "fflow5": s.get("main_net_5d"), "ml_proba": ml_proba,
            "profit_score": round(profit_score, 2),
            # 资金流强度分（0-1）：资金流是IC最强因子，强势板块优先
            "fflow_score": max(0, min(1, (float(s.get("main_net_5d", 0) or 0) + 5000) / 30000.0)),
            "reason": "，".join(reason_parts) or "综合评分靠前",
        })

    # ============ 3. 排序 ============
    holdings_plan.sort(key=lambda x: (x["priority"], -x["profit_score"]))
    # 买入候选：资金流强度(0.5) + 综合分(0.3) + 验证(0.2) 加权，让强势板块优先
    buy_candidates.sort(key=lambda x: -(
        0.5 * x.get("fflow_score", 0.5) +
        0.3 * x.get("profit_score", 0) +
        0.2 * (1.0 if x.get("verify") == "valid" else 0.3)
    ))

    # ============ 3.5 小资金模式（集中度优化） ============
    # 资金规模小时最忌过度分散；但 2026-09-02 变体扫描实测 Top5 优于 Top3，
    # 故小资金也不再强压到 4 只以下（最多仍是5只内集中）。
    # 缺行情持仓 market_value=None（第 21 项）：不能参与 sum，否则整页 500
    total_mv = sum(h.get("market_value") for h in scan["holdings"]
                   if h.get("market_value") is not None)
    small_capital = total_mv < 5000
    max_recommend_buys = 2 if small_capital else 5   # 小资金只推前2只
    max_holdings_target = 5 if small_capital else len(holdings_plan)
    if small_capital:
        # 若持仓数已超目标，把"持有(状态正常)"中验证较弱的标记为可合并
        for h in holdings_plan:
            if (h["action"] == "持有" and h["verify"] != "valid"
                    and len([x for x in holdings_plan if x["action"] not in ("卖出", "卖出(结构)", "减仓")]) > max_holdings_target):
                h["action"] = "减仓"
                h["reason"] += f"（小资金集中度：资金{total_mv:.0f}元，建议压缩持仓到{max_holdings_target}只）"
                h["priority"] = min(h["priority"], PRIORITY["减仓"])
        # 买入候选只保留最强者
        buy_candidates = buy_candidates[:max_recommend_buys]

    # ============ 4. 结构性结论 ============
    # 需要卖出的持仓（腾资金） vs 值得买入的候选（接资金）
    sell_items = [h for h in holdings_plan if h["action"] in ("卖出(结构)", "减仓", "卖出", "止盈", "止损卖出", "止盈卖出")]
    keep_items = [h for h in holdings_plan if h["action"] in ("持有", "加仓")]
    add_items = [h for h in holdings_plan if h["action"] == "加仓"]

    # ===== 统一风控入口（修复）：温度择时时买入和加仓必须一起受约束 =====
    # 旧实现只清空 buy_candidates，add_items 不受温度影响 → 会出现
    # “一边提示空仓、一边生成加仓计划”的自相矛盾输出。
    discipline_note = None
    if market_temp < 40:
        discipline_note = (f"市场温度 {market_temp:.0f}<40（偏空）：纪律=空仓，"
                           f"买入候选与加仓全部暂停，待温度回升再动手")
        buy_candidates = []
        if add_items:
            for h in add_items:
                h["action"] = "持有"
                h["reason"] = h["reason"] + "（温度<40 纪律暂停加仓）"
            add_items = []
    elif market_temp < 60:
        discipline_note = f"市场温度 {market_temp:.0f}（中性）：纪律=半仓，控制总仓位"

    sell_names = "、".join(h["name"] for h in sell_items[:3]) + ("等" if len(sell_items) > 3 else "")
    buy_names = "、".join(b["name"] for b in buy_candidates[:3]) + ("等" if len(buy_candidates) > 3 else "")

    parts = []
    if sell_items:
        half = [h for h in sell_items if h.get("sell_ratio", 1) < 1]
        full = [h for h in sell_items if h.get("sell_ratio", 1) >= 1]
        if half:
            parts.append(f"建议减仓(卖一半留反弹) {len(half)} 只：{', '.join(h['name'] for h in half)}")
        if full:
            parts.append(f"建议卖出 {len(full)} 只：{', '.join(h['name'] for h in full)}")
    if add_items:
        parts.append(f"建议加仓 {len(add_items)} 只：{', '.join(a['name'] for a in add_items)}")
    if buy_candidates:
        parts.append(f"买入候选 {len(buy_candidates)} 只：{buy_names}")
    if small_capital:
        parts.append(f"⚡小资金模式：总资金{total_mv:.0f}元，建议集中到≤{max_holdings_target}只，减少交易成本")
    if not parts:
        parts.append("当前持仓结构健康，无需大幅调仓")
    parts.append(f"市场温度 {market_temp}")

    # ============ 5. 风控提醒 ============
    risk_notes = []
    for h in holdings_plan:
        if h["pnl_pct"] is not None and h["pnl_pct"] < -8:
            risk_notes.append(f"{h['name']} 亏损{h['pnl_pct']}%，逼近-10%止损线")
        if h["action"] in ("卖出", "止损卖出") and h["verify"] != "invalid":
            risk_notes.append(f"{h['name']} 需尽快执行卖出")
    # ===== 温度择时纪律：统一在 discipline_note（上方）处理，此处只输出提示 =====
    if discipline_note:
        risk_notes.append(discipline_note)

    # ============ 6. 可复制指令 ============
    order_lines = ["【CherryQuant 收益优化调仓】", f"日期: {scan['generated_at'][:10]}", ""]
    for h in sell_items:
        order_lines.append(f"减/卖 {h['name']} {h['code']} | {h['action']} | {h['reason']}")
    for a in add_items:
        order_lines.append(f"加仓 {a['name']} {a['code']} | 现价{a['price']} | {a['reason']}")
    for b in buy_candidates[:max_recommend_buys]:
        order_lines.append(f"买入 {b['name']} {b['code']} | 现价{b['price']} | {b['reason']}")
    order_lines.append("")
    order_lines.append("【风控】止损-10%/回撤-8%/止盈+15%，纪律优先于一切。")
    order_lines.append("【频率】每40个交易日做一次完整再平衡（变体扫描实测优于每20日）。")
    if small_capital:
        order_lines.append(f"【小资金】总资金{total_mv:.0f}元，建议持仓≤{max_holdings_target}只，避免频繁交易。")
    order_text = "\n".join(order_lines)

    # ============ 7. 具体交易计划（份数 + 金额 + 批次） ============
    # 资金流：卖出腾出的钱 → 优先加仓(验证有效) → 再买入新仓。
    # 每笔按 ETF 一手=100份 整数倍。批次=执行顺序（1立即/2第一批买/3第二批买）。
    # 结构性卖出(验证无效)默认卖一半，保留低位反弹机会；止损/止盈全卖。
    trade_plan = []
    step_no = 0
    sell_proceeds = 0.0
    for h in sell_items:
        if h.get("price") and h.get("shares"):
            ratio = h.get("sell_ratio", 1.0)
            total_shares = int(h["shares"])
            # 卖出份数：向下取整到100的整数倍。持仓<2手(200份)时卖一半=0份无意义 → 直接清仓
            if ratio < 1 and total_shares < 200:
                sell_shares = total_shares  # 不足2手，卖一半留不下1手，直接清仓
                ratio_txt = "清仓"
            else:
                sell_shares = int(total_shares * ratio // 100 * 100)
                if sell_shares <= 0 and total_shares >= 100:
                    sell_shares = 100  # 至少卖1手
                ratio_txt = f"卖{ratio:.0%}"
            if sell_shares <= 0:
                continue  # 无实际卖出
            amount = sell_shares * h["price"]
            sell_proceeds += amount
            step_no += 1
            kept = total_shares - sell_shares
            trade_plan.append({
                "step": step_no, "batch": 1, "action": "卖出",
                "name": h["name"], "code": h["code"],
                "shares": sell_shares, "price": round(h["price"], 3),
                "amount": round(amount, 0),
                "reason": h["reason"] + (f"（{ratio_txt}，留{kept}份观察反弹）" if kept > 0 else f"（{ratio_txt}）"),
            })

    available = sell_proceeds  # 可动用资金 = 卖出回笼
    add_sorted = sorted(add_items, key=lambda x: (0 if x["verify"] == "valid" else 1, -x["profit_score"]))
    for a in add_sorted:
        if available <= 0 or not a.get("price"):
            continue
        lot = 100  # 加仓先买1手，分批更稳
        cost = lot * a["price"]
        if available >= cost:
            step_no += 1
            batch = 2 if a["verify"] == "valid" else 3  # 验证有效先加，弱验证等站稳
            trade_plan.append({
                "step": step_no, "batch": batch, "action": "加仓",
                "name": a["name"], "code": a["code"],
                "shares": lot, "price": round(a["price"], 3),
                "amount": round(cost, 0),
                "reason": a["reason"] + ("" if batch == 2 else "（等站稳再分批加）"),
            })
            available -= cost

    skipped_insufficient = []
    for b in buy_candidates:
        if available <= 0 or not b.get("price"):
            break
        lot = 100
        cost = lot * b["price"]
        if available >= cost:
            step_no += 1
            trade_plan.append({
                "step": step_no, "batch": 3, "action": "买入",
                "name": b["name"], "code": b["code"],
                "shares": lot, "price": round(b["price"], 3),
                "amount": round(cost, 0),
                "reason": b["reason"],
            })
            available -= cost
        else:
            skipped_insufficient.append(f"{b['name']}(1手约{b['price']*100:.0f}元，资金不足)")

    buy_total = sum(t["amount"] for t in trade_plan if t["action"] in ("买入", "加仓"))
    trade_plan.append({
        "step": step_no + 1, "batch": 0, "action": "汇总",
        "name": "资金结算", "code": "",
        "shares": 0, "price": 0,
        "amount": round(sell_proceeds - buy_total, 0),
        "reason": f"卖出回笼≈{sell_proceeds:.0f}元，买入/加仓≈{buy_total:.0f}元，结余≈{sell_proceeds - buy_total:.0f}元"
                  + (f"；资金不足未排入:{'、'.join(skipped_insufficient)}" if skipped_insufficient else ""),
    })

    # 用 trade_plan 重写可复制指令（带份数与金额）
    order_lines = ["【CherryQuant 调仓指令·含数量】", f"日期: {scan['generated_at'][:10]}", ""]
    for t in trade_plan:
        if t["action"] == "汇总":
            order_lines.append("")
            order_lines.append(f"💡 {t['reason']}")
            continue
        order_lines.append(
            f"批次{t['batch']} {t['action']} {t['name']} {t['code']} "
            f"{t['shares']}份 × {t['price']} ≈ {t['amount']:.0f}元 | {t['reason']}")
    order_lines.append("")
    order_lines.append("【风控】止损-10%/回撤-8%/止盈+15%，纪律优先于一切。")
    order_lines.append("【频率】每40个交易日做一次完整再平衡（变体扫描实测优于每20日）。")
    if small_capital:
        order_lines.append(f"【小资金】总资金{total_mv:.0f}元，建议持仓≤{max_holdings_target}只，分批执行避免频繁交易。")
    order_text_full = "\n".join(order_lines)

    return {
        "generated_at": scan["generated_at"],
        "market_temp": market_temp,
        "summary": "；".join(parts),
        "holdings_plan": holdings_plan,
        "buy_candidates": buy_candidates,
        "sell_priority": [h for h in sell_items],
        "buy_priority": [b for b in buy_candidates[:max_recommend_buys]],
        "risk_notes": risk_notes,
        "order_text": order_text,
        "trade_plan": trade_plan,
        "order_text_full": order_text_full,
        # 小资金模式
        "small_capital_mode": small_capital,
        "total_market_value": round(total_mv, 0),
        "max_holdings_target": max_holdings_target,
        # 元信息：让用户知道这是"建议"，不是投资指令
        "disclaimer": "调仓建议由系统规则生成，历史回测不代表未来；小资金调仓需考虑手续费成本，建议分批执行。",
    }
