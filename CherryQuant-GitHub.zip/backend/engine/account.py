# -*- coding: utf-8 -*-
"""CherryQuant · 迭代 A：完整资金账本（现金 / 总权益 / TWR / 对账导入）。

口径（唯一，见 D:\\ds\\CherryQuant-迭代A-资金账本-契约与分工.md）：
  - cash = base_cash + Σ cash_ledger.amount（仅 CASH_EFFECT_TYPES；REALIZED_PNL 是信息行）
  - 总权益 = 现金 + 持仓市值；任一持仓缺报价 → valuation_complete=False + missing_quotes
  - 入金/出金只改变现金与总权益，不计入收益；收益用 TWR（时间加权）剔除出入金影响
  - 买卖与账本写入在同一事务（db.apply_trade），逐笔可核对

历史账户兼容：
  - 老库（有成交、无账本）在 db.init_db 迁移时以“历史成交净额”写 base_cash；
  - 运行中未初始化账户（只有成交、无入金）：ledger_initialized=False，再平衡走旧锚点；
    首次入金/出金时自动补 base_cash 把已有成交账本净额对冲为 0。
"""
import math
from datetime import datetime

import pandas as pd

from . import db
from .config import CODE2NAME
from .data import fetch

LEDGER_TYPES = db.LEDGER_TYPES
CASH_EFFECT_TYPES = db.CASH_EFFECT_TYPES

_EPS = 1e-9


# ==================== 基础校验/工具 ====================

def _validate_positive(amount, field: str = "amount") -> float:
    try:
        v = float(amount)
    except (TypeError, ValueError):
        raise db.TradeRejected(f"{field} 必须是数字")
    if not math.isfinite(v) or v <= 0:
        raise db.TradeRejected(f"{field} 必须是有限正数")
    return v


def _norm_date(date) -> str:
    if not date:
        return datetime.now().isoformat(timespec="seconds")
    s = str(date)
    return s[:10]


# ==================== 现金/账本 ====================

def get_base_cash() -> float:
    return round(db.get_base_cash(), 2)


def ledger_initialized() -> bool:
    return db.ledger_initialized()


def cash_balance() -> float:
    return db.cash_balance()


def total_fees() -> float:
    return db.total_fees()


def list_ledger(limit: int = 200) -> dict:
    """账本明细：base_cash + 每行 cash_after（按时间顺序累计）。"""
    base = db.get_base_cash()
    rows = db.load_cash_ledger()
    entries = []
    cash = base
    for r in rows:
        amt = float(r["amount"] or 0.0)
        is_cash = r["type"] in CASH_EFFECT_TYPES
        if is_cash:
            cash = round(cash + amt, 2)
        entries.append({
            "id": r["id"],
            "date": str(r["date"] or "")[:10],
            "type": r["type"],
            "amount": round(amt, 2),
            "note": r["note"],
            "trade_id": r["trade_id"],
            "cash_effect": is_cash,
            "cash_after": round(cash, 2),
        })
    if limit is not None and int(limit) > 0:
        entries = entries[-int(limit):]
    return {
        "base_cash": round(base, 2),
        "cash": round(cash, 2),
        "ledger_initialized": db.ledger_initialized(),
        "entries": entries,
        "note": db.get_account_meta("ledger_baseline_note") or "",
    }


def deposit(amount: float, date=None, note: str = None) -> dict:
    """入金：只增加现金与总权益，不计入收益（TWR 剔除）。"""
    amt = _validate_positive(amount)
    entry = db.add_cash_ledger_entry(_norm_date(date), "DEPOSIT", amt,
                                     note or "入金", None)
    eq = get_account_equity()
    return {"ok": True, "entry": entry, "cash": eq["cash"],
            "total_equity": eq["total_equity"], "equity": eq}


def withdraw(amount: float, date=None, note: str = None) -> dict:
    """出金：现金不足拒绝（400）。"""
    amt = _validate_positive(amount)
    cash = db.cash_balance()
    if amt > cash + _EPS:
        raise db.TradeRejected(
            f"现金不足：当前现金 {cash:.2f}，无法取出 {amt:.2f}；"
            "可先卖出持仓或减少出金金额")
    entry = db.add_cash_ledger_entry(_norm_date(date), "WITHDRAW", -amt,
                                     note or "出金", None)
    eq = get_account_equity()
    return {"ok": True, "entry": entry, "cash": eq["cash"],
            "total_equity": eq["total_equity"], "equity": eq}


# ==================== 持仓估值 ====================

def get_positions_valuation() -> dict:
    """当前持仓估值（缺行情返回 None + no_data，不把价格当 0）。"""
    positions = db.load_positions()
    rows, missing = [], []
    market_value = 0.0
    asof = ""
    priced_cost = 0.0
    for code, pos in positions.items():
        name = pos.get("name") or CODE2NAME.get(code, code)
        try:
            df = fetch(code, offline=True)
        except Exception:
            df = pd.DataFrame()
        has_quote = df is not None and len(df) > 0
        current = float(df["close"].iloc[-1]) if has_quote else None
        if has_quote:
            asof = max(asof, str(df["date"].iloc[-1])[:10])
        mv = round(pos["shares"] * current, 2) if has_quote else None
        if mv is None:
            missing.append({"code": code, "name": name})
        else:
            market_value += mv
            priced_cost += float(pos.get("cost") or 0.0)
        rows.append({
            "code": code, "name": name, "shares": pos["shares"],
            "cost_price": pos["cost_price"], "cost": pos.get("cost"),
            "current_price": current, "market_value": mv,
            "no_data": (not has_quote),
            "pnl_pct": (round((current / pos["cost_price"] - 1) * 100, 2)
                        if has_quote and pos["cost_price"] else None),
        })
    rows.sort(key=lambda x: (x["market_value"] is None, -(x["market_value"] or 0)))
    return {
        "positions": rows,
        "market_value": round(market_value, 2),
        "priced_cost": round(priced_cost, 2),
        "valuation_complete": (len(missing) == 0),
        "missing_quotes": missing,
        "asof": asof,
    }


# ==================== 已实现盈亏 ====================

def _replay_trades(rows: list):
    """按成交时间顺序用移动加权均价回放，返回 (总已实现盈亏, 逐笔明细)。

    卖出已实现盈亏 = (卖出价 - 卖出前均价) * 卖出份数（毛额，不含手续费；费单独统计）。
    """
    ordered = sorted(rows, key=lambda r: (str(r.get("date") or ""), int(r.get("id") or 0)))
    book = {}          # code -> {"shares": float, "avg": float}
    total = 0.0
    details = []
    for r in ordered:
        code = r.get("code")
        action = (r.get("action") or "").strip().upper()
        try:
            shares = float(r.get("shares") or 0.0)
            price = float(r.get("price") or 0.0)
        except (TypeError, ValueError):
            continue
        if shares <= 0 or price <= 0:
            continue
        st = book.setdefault(code, {"shares": 0.0, "avg": 0.0})
        if action == "BUY":
            new_shares = st["shares"] + shares
            st["avg"] = ((st["shares"] * st["avg"]) + shares * price) / new_shares if new_shares else 0.0
            st["shares"] = new_shares
        elif action == "SELL":
            sold = min(shares, st["shares"])
            if sold <= 0:
                continue
            pnl = (price - st["avg"]) * sold
            st["shares"] -= sold
            total += pnl
            details.append({"id": r.get("id"), "date": str(r.get("date") or "")[:10],
                            "code": code, "shares": round(sold, 4),
                            "price": price, "realized_pnl": round(pnl, 2)})
    return round(total, 2), details


def compute_realized_pnl() -> float:
    total, _ = _replay_trades(db.load_trades())
    return round(total, 2)


# ==================== TWR（时间加权收益） ====================

def compute_twr() -> dict:
    """时间加权收益：用每日权益回放，剔除入金/出金影响。

    r_d = (equity_d - net_flow_d) / equity_{d-1} - 1；TWR = Π(1+r_d)-1。
    日历 = 相关持仓标的主行情日期的并集 ∪ 现金流/成交日期。
    缺报价日用最近已知价（twr_valuation_complete=False）。
    """
    ledger = db.load_cash_ledger()
    trades = db.load_trades()
    base_cash = db.get_base_cash()
    empty = {"twr": None, "start": "", "end": "", "days": 0,
             "valuation_complete": True, "note": "无资金/成交记录"}
    if not ledger and not trades:
        return empty

    def d10(x):
        return str(x or "")[:10]

    ledger_by_date, trade_by_date = {}, {}
    for e in ledger:
        ledger_by_date.setdefault(d10(e.get("date")), []).append(e)
    for t in trades:
        trade_by_date.setdefault(d10(t.get("date")), []).append(t)
    event_dates = sorted(set(ledger_by_date) | set(trade_by_date))
    start = event_dates[0]

    codes = sorted({t.get("code") for t in trades if t.get("code")})
    series = {}
    for code in codes:
        try:
            df = fetch(code, offline=True)
        except Exception:
            df = None
        if df is None or len(df) == 0:
            continue
        s = pd.Series(df["close"].astype(float).values,
                      index=pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d").values)
        s = s[~s.index.duplicated(keep="last")]
        series[code] = s

    calendar = set(event_dates)
    for s in series.values():
        calendar |= {d for d in s.index if d >= start}
    calendar = sorted(calendar)
    if not calendar:
        return empty

    cash = base_cash
    shares = {}
    last_price = {}
    equity_prev = None
    growth = 1.0
    days = 0
    valuation_complete = True

    for d in calendar:
        for e in ledger_by_date.get(d, []):
            if e.get("type") in CASH_EFFECT_TYPES:
                cash += float(e.get("amount") or 0.0)
        for t in trade_by_date.get(d, []):
            action = (t.get("action") or "").strip().upper()
            try:
                sh = float(t.get("shares") or 0.0)
            except (TypeError, ValueError):
                continue
            if action == "BUY":
                shares[t.get("code")] = shares.get(t.get("code"), 0.0) + sh
            elif action == "SELL":
                shares[t.get("code")] = shares.get(t.get("code"), 0.0) - sh

        market_value = 0.0
        for code, sh in shares.items():
            if sh <= _EPS:
                continue
            s = series.get(code)
            price = None
            if s is not None:
                sub = s[s.index <= d]
                if len(sub):
                    price = float(sub.iloc[-1])
                    last_price[code] = price
            if price is None:
                price = last_price.get(code)
                if price is None:
                    valuation_complete = False
                    continue
                valuation_complete = False
            market_value += sh * price

        equity = round(cash + market_value, 6)
        flow = sum(float(e.get("amount") or 0.0) for e in ledger_by_date.get(d, [])
                   if e.get("type") in ("DEPOSIT", "WITHDRAW"))
        if equity_prev is not None and equity_prev > _EPS:
            r = (equity - flow) / equity_prev - 1.0
            growth *= (1.0 + r)
            days += 1
        equity_prev = equity

    return {
        "twr": round((growth - 1.0) * 100, 2),
        "start": calendar[0],
        "end": calendar[-1],
        "days": days,
        "valuation_complete": valuation_complete,
        "note": "时间加权收益（已剔除入金/出金影响）",
    }


# ==================== 账户总权益 ====================

def get_account_equity(with_twr: bool = True) -> dict:
    """账户总权益 = 现金 + 持仓市值；含 TWR / 已实现盈亏 / 缺报价标记。"""
    val = get_positions_valuation()
    cash = db.cash_balance()
    base = db.get_base_cash()
    realized = compute_realized_pnl()
    fees = db.total_fees()
    initialized = db.ledger_initialized()
    total = round(cash + val["market_value"], 2)
    unrealized = round(sum(
        (p["current_price"] - p["cost_price"]) * p["shares"]
        for p in val["positions"] if p["current_price"] is not None and p["cost_price"]), 2)
    tw = compute_twr() if with_twr else {
        "twr": None, "start": "", "end": "", "days": 0,
        "valuation_complete": True, "note": "未计算",
    }
    # TWR 可信度：历史账户只有成交、没有入金/出金流水 → 无法从时间轴剔除出入金，TWR 不可信
    twr_reliable = bool(initialized and db.external_flow_count() > 0)
    if with_twr and not twr_reliable:
        tw = {"twr": None, "start": "", "end": "", "days": 0,
              "valuation_complete": True,
              "note": "账户无入金/出金流水（历史账户或未建账），TWR 不可用；请入金或 import-trades 对账后再看"}
    if initialized:
        cash_source = "期初基线 base_cash + 资金账本（入金/出金/成交/费用）"
    else:
        cash_source = "未初始化：无 base_cash 且无入金/出金记录（现金为成交账本净额）"
    notes = []
    if not initialized:
        notes.append("资金账本未初始化：请入金（/api/account/deposit）或导入对账（/api/account/import-trades）")
    if cash < -_EPS:
        notes.append(f"现金为负（{cash:.2f}）：请入金或核对历史成交")
    if not val["valuation_complete"]:
        notes.append(f"{len(val['missing_quotes'])} 只持仓缺报价，总权益仅统计有报价部分")
    if initialized and not twr_reliable:
        notes.append("无入金/出金流水，TWR 暂不可用（历史账户需对账）")
    return {
        "base_cash": round(base, 2),
        "cash": round(cash, 2),
        "market_value": val["market_value"],
        "total_equity": total,
        "realized_pnl": realized,
        "unrealized_pnl": unrealized,
        "total_fees": fees,
        "twr": tw.get("twr"),
        "twr_reliable": bool(with_twr and twr_reliable),
        "twr_start": tw.get("start"),
        "twr_end": tw.get("end"),
        "twr_days": tw.get("days"),
        "twr_valuation_complete": tw.get("valuation_complete"),
        "twr_note": tw.get("note"),
        "valuation_complete": val["valuation_complete"],
        "missing_quotes": val["missing_quotes"],
        "cash_source": cash_source,
        "ledger_initialized": initialized,
        "positions": val["positions"],
        "asof": val["asof"],
        "note": "；".join(notes),
    }


# ==================== 对账导入（import-trades） ====================

def _import_key(row: dict) -> tuple:
    return (str(row.get("date") or "")[:10],
            (row.get("action") or "").strip().upper(),
            str(row.get("code") or ""),
            round(float(row.get("price") or 0.0), 4),
            round(float(row.get("shares") or 0.0), 4))


def _normalize_import_rows(trades) -> list:
    if not isinstance(trades, list) or not trades:
        raise db.TradeRejected("trades 必须是非空数组")
    rows = []
    for i, t in enumerate(trades):
        if not isinstance(t, dict):
            raise db.TradeRejected(f"第{i + 1}行不是对象")
        action = (t.get("action") or "").strip().upper()
        if action not in ("BUY", "SELL"):
            raise db.TradeRejected(f"第{i + 1}行 action 必须是 BUY/SELL")
        code = t.get("code")
        if not isinstance(code, str) or not code.strip():
            raise db.TradeRejected(f"第{i + 1}行 code 不能为空")
        try:
            price = float(t.get("price"))
            shares = float(t.get("shares"))
            fee = float(t.get("fee") or 0.0)
        except (TypeError, ValueError):
            raise db.TradeRejected(f"第{i + 1}行 price/shares/fee 必须是数字")
        for fname, fv in (("price", price), ("shares", shares)):
            if not math.isfinite(fv) or fv <= 0:
                raise db.TradeRejected(f"第{i + 1}行 {fname} 必须是有限正数")
        if not math.isfinite(fee) or fee < 0:
            raise db.TradeRejected(f"第{i + 1}行 fee 必须是有限非负数")
        rows.append({"date": _norm_date(t.get("date")), "action": action,
                     "code": code.strip(), "price": price, "shares": shares, "fee": fee})
    return rows


def _existing_trade_keys() -> set:
    return {_import_key(t) for t in db.load_trades()}


def _split_duplicates(rows: list):
    existing = _existing_trade_keys()
    to_import, duplicates = [], []
    seen = set()
    for r in rows:
        k = _import_key(r)
        if k in existing or k in seen:
            duplicates.append(r)
        else:
            seen.add(k)
            to_import.append(r)
    return to_import, duplicates


def preview_import_trades(trades: list) -> dict:
    """对账导入预览：不写库，返回差额、现金影响与导入后估值。"""
    rows = _normalize_import_rows(trades)
    to_import, duplicates = _split_duplicates(rows)
    cash = db.cash_balance()
    impact = 0.0
    for r in to_import:
        if r["action"] == "BUY":
            impact -= r["price"] * r["shares"] + r["fee"]
        else:
            impact += r["price"] * r["shares"] - r["fee"]
    impact = round(impact, 2)
    val = get_positions_valuation()
    cash_after = round(cash + impact, 2)
    # 导入后估值：按成交价估算待导入成交带来的持仓市值变化（+买 -卖），避免 equity_after 偏低
    projected_mv = val["market_value"]
    for r in to_import:
        delta = r["shares"] * r["price"]
        projected_mv += delta if r["action"] == "BUY" else -delta
    return {
        "preview": True,
        "total": len(rows),
        "to_import": len(to_import),
        "skipped_duplicates": len(duplicates),
        "duplicates": duplicates,
        "diff": to_import,
        "cash_before": round(cash, 2),
        "cash_impact": impact,
        "cash_after": cash_after,
        "equity_after": round(cash_after + projected_mv, 2),
        "ledger_initialized": db.ledger_initialized(),
        "note": ("确认导入请传 confirm=true；重复成交（同日期/动作/代码/价格/份数）会跳过"
                 if to_import else "没有需要导入的新成交（全部重复或为空）"),
    }


def import_trades(trades: list) -> dict:
    """确认导入：单事务写入，重复成交跳过；现金不足整批回滚。"""
    rows = _normalize_import_rows(trades)
    to_import, duplicates = _split_duplicates(rows)
    if not to_import:
        eq = get_account_equity(with_twr=False)
        return {"ok": True, "imported": 0, "skipped_duplicates": len(duplicates),
                "cash": eq["cash"], "total_equity": eq["total_equity"],
                "trades": [], "note": "全部为重复成交，未写入"}
    result = db.apply_trades_batch(to_import)
    eq = get_account_equity(with_twr=False)
    return {"ok": True, "imported": result["count"],
            "skipped_duplicates": len(duplicates),
            "cash": eq["cash"], "total_equity": eq["total_equity"],
            "trades": result["applied"],
            "note": f"已导入 {result['count']} 笔，跳过重复 {len(duplicates)} 笔"}
