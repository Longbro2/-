# -*- coding: utf-8 -*-
"""
CherryQuant Web — 逐只 ETF 操作指令生成器
把信号/验证/资金流/组合优化/宏观整合成一句明确的"你要做什么"。

对每只 ETF 输出:
  action: 明确动作（买入/加仓/持有/减仓/卖出/观望/回避）
  reason: 一句话理由
  stop: 止损价
  take: 止盈价
  position_hint: 仓位建议
"""
from .verify import load_verify_map
from .decision import decide_holding, decide_buy


def _make_instruction(name: str, code: str, s: dict, pos: dict | None,
                      verify: dict, ml: dict | None = None,
                      portfolio_target: float | None = None,
                      current_pct: float | None = None) -> dict:
    """为单只 ETF 生成操作指令（统一决策引擎）"""
    signal = s.get("signal", "?")
    score = s.get("score", 0)
    v = verify.get("verdict", "nodata")
    fflow5 = s.get("main_net_5d", 0)
    cost_price = pos.get("cost_price") if pos else None
    current = s.get("price", 0)
    pnl_pct = (current / cost_price - 1) * 100 if (pos and cost_price) else None

    # 止损/止盈参考
    stop = round(cost_price * 0.9, 3) if cost_price else None
    take = round(cost_price * 1.15, 3) if cost_price else None

    # ===== 统一决策：持仓 vs 非持仓 =====
    if pos:
        action, reason, _ = decide_holding(s, {**pos, "pnl_pct": pnl_pct}, v, ml)
    else:
        action, reason, _ = decide_buy(s, v, ml)

    # ===== 仓位提示 =====
    if pos and portfolio_target is not None and current_pct is not None:
        diff = portfolio_target - current_pct
        if diff > 8:
            position_hint = f"建议加仓至~{portfolio_target:.0f}%（当前{current_pct:.0f}%）"
        elif diff < -8:
            position_hint = f"建议减仓至~{portfolio_target:.0f}%（当前{current_pct:.0f}%，超配）"
        elif abs(diff) <= 3:
            position_hint = f"仓位合适（~{current_pct:.0f}%）"
        else:
            position_hint = f"可微调至~{portfolio_target:.0f}%（当前{current_pct:.0f}%）"
    elif not pos:
        position_hint = "未持仓"
    else:
        position_hint = "—"

    ml_proba_out = (ml or {}).get("proba")
    return {
        "name": name, "code": code,
        "action": action, "reason": reason,
        "signal": signal, "score": round(score, 1),
        "verify": verify.get("label", "?"),
        "fflow5": fflow5,
        "ml_signal": (ml or {}).get("signal"),
        "ml_proba": round(ml_proba_out, 3) if ml_proba_out is not None else None,
        "stop": stop, "take": take,
        "position_hint": position_hint,
        "pnl_pct": round(pnl_pct, 1) if pnl_pct is not None else None,
        "current_price": current,
    }


def generate_instructions(scan: dict, ml_signals: dict | None = None) -> list:
    """为全池（含持仓）生成操作指令，按紧急程度排序。
    ml_signals: {code: {proba, signal}} 可选，用于双信号融合"""
    signals = {s["code"]: s for s in scan["signals"]}
    holdings = {h["code"]: h for h in scan["holdings"]}
    vmap = load_verify_map()
    pf = scan.get("portfolio", {})
    pf_target = {h["code"]: h["weight"] for h in pf.get("holdings", [])}
    pf_current = {h["code"]: h["current_pct"] for h in pf.get("holdings", [])}

    instructions = []
    # 先处理持仓，再处理未持仓的强候选
    codes = list(holdings.keys()) + [s["code"] for s in scan["signals"]
                                     if s["code"] not in holdings][:8]

    for code in codes:
        s = signals.get(code, {})
        pos = holdings.get(code)
        verify = vmap.get(code, {})
        ml = (ml_signals or {}).get(code, {})
        inst = _make_instruction(
            name=s.get("name", code), code=code, s=s, pos=pos,
            verify=verify, ml=ml,
            portfolio_target=pf_target.get(code),
            current_pct=pf_current.get(code),
        )
        instructions.append(inst)

    # 排序：用统一决策引擎的 ORDER（卖出>止盈>减仓>加仓>买入>警惕>持有>...）
    from .decision import sort_key
    instructions.sort(key=sort_key)

    # ===== 市场温度择时纪律层（2026-09-02 加入，回测实测：温度关→全窗口普遍腰斩）=====
    # 温度<40(偏空)：建议空仓——持仓全部转卖出(历史"躺平"标的除外)，未持仓候选不买入
    # 温度40-60：中性，维持决策引擎结论，只在提示语里说明半仓纪律
    temp = float(scan.get("market", {}).get("temp", 50))
    holdings_map = {h["code"]: h for h in scan.get("holdings", [])}
    try:
        from .timing_fit import get_timing_fit
    except Exception:
        get_timing_fit = None
    for inst in instructions:
        if inst["code"] not in holdings_map:
            continue  # 非持仓不动
        pos_action = inst.get("action", "")
        if pos_action in ("卖出", "止盈", "减仓"):
            continue  # 本来就要走/减
        if temp < 40:
            # 历史回测证明该标“躺平更优”时保留（避免温度空仓把长线好票全清掉）
            keep = False
            if get_timing_fit is not None:
                try:
                    keep = get_timing_fit(inst["code"]).get("verdict") == "躺平"
                except Exception:
                    keep = False
            if keep:
                inst["reason"] = f"历史躺平更优+市场温度{temp:.0f}偏空：保留底仓，不加不减"
            else:
                inst["action"] = "卖出"
                inst["reason"] = f"市场温度{temp:.0f}偏空，温度择时纪律：空仓等企稳（回测口径每40交易日评估）"
                inst["position_hint"] = "清仓等企稳"
    # 空仓信号下，未持仓的买入/加仓类指令降级为观望
    if temp < 40:
        for inst in instructions:
            if inst["code"] in holdings_map:
                continue
            if inst.get("action") in ("买入", "加仓", "关注"):
                inst["action"] = "观望"
                inst["reason"] = f"市场温度{temp:.0f}偏空，纪律：先空仓等待，不动手"
                inst["position_hint"] = "未持仓-等待"
    instructions.sort(key=sort_key)
    return instructions
