# -*- coding: utf-8 -*-
"""
CherryQuant Web — 跟着系统走（操作指南）
把系统的所有规则固化成一个"手把手教学"栏目，
用户每天打开就能知道：现在该买什么、该卖什么、该持有什么、该等什么。

输出:
  today_action: 今日操作（基于实时信号）
  holdings_guide: 持仓怎么处理
  waiting_list: 等待买入的标的（量价转好再买）
  rules: 纪律规则
  how_to_read: 怎么看懂系统
"""
from .signals import scan_all_signals
from .recommend import recommended_portfolio
from .ranking import short_term_ranking
from .volume_price import analyze_price_volume
from .timing_fit import get_timing_fit
from .config import POOL, CODE2NAME


def _today_action(scan, rec, rk) -> dict:
    """生成今日操作建议"""
    holdings = {h["code"]: h for h in scan["holdings"]}
    rotate = {x["code"]: x for x in rec["rotate"]}

    actions = []
    # 持仓处理
    for code, pos in holdings.items():
        name = pos.get("name", CODE2NAME.get(code, code))
        act = rotate.get(code, {})
        action = act.get("action", "持有")
        reason = act.get("reason", "持仓状态正常")
        # 量价判断
        try:
            pv = analyze_price_volume(code)
            pv_verdict = pv.get("entry_verdict", "观望")
        except Exception:
            pv_verdict = "观望"
        actions.append({
            "type": "holding", "code": code, "name": name,
            "action": action, "reason": reason,
            "pnl_pct": pos.get("pnl_pct"),
            "price": pos.get("current_price"),
            "pv_verdict": pv_verdict,
        })

    # 买入候选（量价可买的）
    for b in rk.get("top_buys", []):
        if b["code"] in holdings:
            continue
        pv_verdict = b.get("entry_verdict", "观望")
        if pv_verdict == "可买":
            actions.append({
                "type": "buy", "code": b["code"], "name": b["name"],
                "action": "买入", "reason": b.get("pv_reason", "量价健康"),
                "pv_verdict": pv_verdict,
                "price": b.get("price"),
            })
    return actions


def _waiting_list(rk) -> list:
    """等待买入的标的：排名高但量价未转好"""
    holding_codes = None  # 由外部传入
    return []


def build_guide(scan: dict = None) -> dict:
    """构建"跟着系统走"指南"""
    scan = scan or scan_all_signals()
    rec = recommended_portfolio(scan)
    rk = short_term_ranking(scan)
    holdings = {h["code"]: h for h in scan["holdings"]}

    # 今日操作
    actions = _today_action(scan, rec, rk)

    # 等待列表：排名靠前但量价回避/观望的（等转好再买）
    waiting = []
    for b in rk.get("ranked", []):
        if b["code"] in holdings:
            continue
        pv = b.get("entry_verdict", "观望")
        if b.get("verify") == "valid" and pv in ("观望", "回避"):
            waiting.append({
                "code": b["code"], "name": b["name"],
                "score": b["score"], "pv_verdict": pv,
                "reason": b.get("pv_reason", ""),
                "price": b.get("price"),
            })
            if len(waiting) >= 3:
                break

    # 纪律规则（固定文案）
    rules = [
        {"level": "红", "text": "止损纪律：持仓跌破止损位（成本-10%或峰值回撤-8%）必须卖，不犹豫"},
        {"level": "红", "text": "止盈纪律：盈利+15%或移动止盈触发，考虑落袋"},
        {"level": "黄", "text": "量价回避就不追：即使排名第1，量价显示'回避'也要等"},
        {"level": "黄", "text": "市场温度<40空仓，40-60半仓，>60可满仓"},
        {"level": "绿", "text": "系统说'保留'的（如躺平标的有色）拿着不动，别频繁交易"},
        {"level": "绿", "text": "调仓周期约20天，跟着系统节奏，别每天手痒"},
    ]

    # 怎么看懂系统
    how_to_read = [
        {"title": "短期排名", "desc": "'这个月买什么'。综合评分+资金+量价，✅可买/🟡观望/🔴回避"},
        {"title": "量价判断", "desc": "放量上涨=可买，缩量回调=健康洗盘，缩量上涨=乏力回避，放量下跌=危险"},
        {"title": "验证状态", "desc": "✅有效=长期可靠，❌无效=长期择时不靠谱（即使评分高也别碰）"},
        {"title": "择时适用度", "desc": "该择时的跟信号操作，该躺平的（有色/电力）减少交易"},
        {"title": "市场温度", "desc": ">60偏多可满仓，40-60中性半仓，<40偏空空仓"},
    ]

    return {
        "generated_at": scan["generated_at"],
        "market_temp": rec["temp_timing"],
        "summary": rec["summary"],
        "today_actions": actions,
        "waiting_list": waiting,
        "recommended": rec["recommended"],
        "rules": rules,
        "how_to_read": how_to_read,
        "disclaimer": "以上为系统规则建议，不构成投资建议；历史回测不代表未来，盈亏自负。",
    }
