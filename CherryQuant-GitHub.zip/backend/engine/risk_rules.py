# -*- coding: utf-8 -*-
"""统一风控判定（在线 stop_loss_check 与回测 Backtest 共用，避免两套阈值口径）。

设计依据（config.RISK）：
  - 固定止损：相对成本亏损 <= stop_loss（-10%）
  - 峰值回撤止损：从持仓期峰值回撤 <= stop_drawdown（-8%）
  - 固定止盈：相对成本盈利 > take_profit（+15%）
  - 移动止盈：盈利先超过 trailing_activate（+8%）激活，之后从峰值回撤超过
    trailing_stop（-8%）→ 止盈（让利润奔跑）
  - 趋势自适应：60日动量强 + 当前盈利时，放宽移动止盈/峰值止损线
两条口径：在线与回测都使用本函数的“固定止盈 OR 移动止盈”组合（旧回测在
use_trailing_stop=True 时漏掉了固定止盈，导致两端信号不一致）。
"""
from .config import RISK


def evaluate_risk(cost_price, peak_price, current_price, r60=None, risk=None) -> dict:
    """返回 {stop_triggered, take_profit, trailing_take, drawdown, pnl_pct,
    peak, cost_price, current_price, thresholds, no_data}。

    current_price <= 0 / None 视为无有效行情 → no_data=True，不触发任何风控。
    """
    risk = dict(RISK if risk is None else risk)

    if current_price is None or current_price <= 0:
        cost = float(cost_price or 0)
        peak = float(peak_price or cost or 0)
        return {
            "stop_triggered": False, "take_profit": False, "trailing_take": False,
            "drawdown": 0.0, "pnl_pct": 0.0, "peak": round(peak, 3),
            "cost_price": round(cost, 3), "current_price": 0.0,
            "no_data": True, "thresholds": _thresholds(risk, adaptive=False),
        }

    cur = float(current_price)
    cost = float(cost_price or 0)
    if cost <= 0:
        cost = cur
    peak = max(float(peak_price or 0), cur)

    drawdown = (cur / peak - 1) * 100 if peak > 0 else 0.0
    pnl_pct = (cur / cost - 1) * 100 if cost > 0 else 0.0

    # 趋势自适应：仅“有盈利 + 60日动量强”时放宽（截断亏损、让利润奔跑）
    adaptive = False
    trailing_activate = risk["trailing_activate"]
    trailing_stop = risk["trailing_stop"]
    stop_drawdown = risk["stop_drawdown"]
    if risk.get("trend_adaptive", True) and pnl_pct > 0 and r60 is not None:
        try:
            if float(r60) > risk.get("trend_r60_threshold", 3.0):
                adaptive = True
                trailing_activate = risk.get("trailing_activate_strong", 12.0)
                trailing_stop = risk.get("trailing_stop_strong", -12.0)
                stop_drawdown = risk.get("stop_drawdown_strong", -12.0)
        except (TypeError, ValueError):
            pass

    trailing_take = bool(
        risk.get("use_trailing_stop", True)
        and peak >= cost * (1 + trailing_activate / 100.0)
        and drawdown < trailing_stop
    )
    # 固定止盈与移动止盈是 OR：两端统一（旧回测在移动止盈模式下漏了固定止盈）
    take_profit = bool(pnl_pct > risk["take_profit"] or trailing_take)
    stop_triggered = bool(drawdown < stop_drawdown or pnl_pct < risk["stop_loss"])

    return {
        "stop_triggered": stop_triggered,
        "take_profit": take_profit,
        "trailing_take": trailing_take,
        "drawdown": round(float(drawdown), 1),
        "pnl_pct": round(float(pnl_pct), 1),
        "peak": round(float(peak), 3),
        "cost_price": round(float(cost), 3),
        "current_price": round(float(cur), 3),
        "no_data": False,
        "thresholds": _thresholds(risk, adaptive=adaptive,
                                  trailing_activate=trailing_activate,
                                  trailing_stop=trailing_stop,
                                  stop_drawdown=stop_drawdown),
    }


def _thresholds(risk, adaptive=False, trailing_activate=None, trailing_stop=None,
                stop_drawdown=None):
    """当前实际生效的阈值（供页面展示，避免前端自己再维护一套线）。"""
    return {
        "adaptive": bool(adaptive),
        "stop_loss": risk["stop_loss"],
        "stop_drawdown": (risk["stop_drawdown"] if stop_drawdown is None else stop_drawdown),
        "take_profit": risk["take_profit"],
        "use_trailing_stop": bool(risk.get("use_trailing_stop", True)),
        "trailing_activate": (risk["trailing_activate"] if trailing_activate is None else trailing_activate),
        "trailing_stop": (risk["trailing_stop"] if trailing_stop is None else trailing_stop),
    }
