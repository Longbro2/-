# -*- coding: utf-8 -*-
"""
CherryQuant Web — 短期强度排名模块
综合 系统评分 + 资金流 + 今日表现 + 验证加成，生成"短期可买排名"。

和"验证有效Top3"的区别：
  - 验证Top3 = 长期可靠（样本外验证有效）
  - 短期排名 = 综合当前强度（评分+资金+今日），用于"这个月买什么"

输出:
  ranked: 全池按短期综合强度排序
  top_buys: 推荐买入（验证有效 + 综合强）
  warnings: 需要警惕的（评分高但验证无效 / 资金流出但涨）
  summary: 一句话总结
"""
import time

from .signals import scan_all_signals
from .config import POOL


def _fetch_batch_quotes(codes: list) -> dict:
    """批量拉取实时行情（一次请求全部），返回 {code: {today_pct, price}}"""
    result = {}
    # 分组：5/6开头=sh，其余=sz
    sh_codes = [c for c in codes if c.startswith(("5", "6"))]
    sz_codes = [c for c in codes if not c.startswith(("5", "6"))]
    try:
        import requests
        for prefix, group in [("sh", sh_codes), ("sz", sz_codes)]:
            if not group:
                continue
            # 分批，每批最多50个
            for i in range(0, len(group), 50):
                batch = group[i:i + 50]
                syms = ",".join(prefix + c for c in batch)
                r = requests.get(f"https://qt.gtimg.cn/q={syms}",
                                 headers={"User-Agent": "Mozilla/5.0", "Referer": "https://gu.qq.com/"},
                                 timeout=8)
                for line in r.text.strip().split(";"):
                    if "=" not in line or "~" not in line:
                        continue
                    try:
                        import re
                        m = re.match(r'v_(\w+)="(.*)"', line.strip())
                        if not m:
                            continue
                        sym = m.group(1)  # e.g. sh516650
                        code = sym[2:]  # 去掉sh/sz前缀
                        parts = m.group(2).split("~")
                        if len(parts) > 35 and code in codes:
                            result[code] = {"today_pct": float(parts[32]), "price": float(parts[3])}
                    except Exception:
                        continue
    except Exception:
        pass
    return result


def short_term_ranking(scan: dict = None) -> dict:
    """
    短期强度排名。
    scan: scan_all_signals() 结果，可复用。
    """
    scan = scan or scan_all_signals()
    signals = scan["signals"]
    holdings = {h["code"]: h for h in scan["holdings"]}

    # 批量拉取实时行情（一次请求，避免逐只慢）
    all_codes = [s["code"] for s in signals]
    quotes = _fetch_batch_quotes(all_codes)

    # 验证加成（长期可靠性）
    verify_bonus = {"valid": 15, "weak": 5, "invalid": -10, "nodata": 0}

    ranked = []
    warnings = []

    for s in signals:
        code = s["code"]
        ff = s.get("main_net_5d", 0) or 0
        v = s.get("verify", "nodata")
        # 批量行情
        quote = quotes.get(code)
        today_pct = quote["today_pct"] if quote else 0
        price = quote["price"] if quote else s.get("price")

        # 综合强度分：评分 + 验证加成 + 资金流(万/1000) + 今日涨幅*2
        combo = s["score"] + verify_bonus.get(v, 0) + (ff / 1000) + today_pct * 2

        item = {
            "code": code, "name": s["name"],
            "signal": s["signal"], "score": s["score"],
            "verify": v, "verify_label": s.get("verify_label", "?"),
            "main_net_5d": ff, "today_pct": round(today_pct, 2),
            "price": price, "combo": round(combo, 1),
            "holding": code in holdings,
            "trend_quality": s.get("trend_quality"),
        }
        # 量价分析（V13 新增：判断能不能现在买）
        try:
            from .volume_price import analyze_price_volume
            pv = analyze_price_volume(code)
            if "error" not in pv:
                item["pv_health"] = pv["health_score"]
                item["entry_verdict"] = pv["entry_verdict"]
                item["verdict_class"] = pv["verdict_class"]
                item["pv_reason"] = pv["reason"]
        except Exception:
            pass
        ranked.append(item)

        # 警告：评分高但验证无效（陷阱）
        if s["score"] >= 70 and v == "invalid":
            warnings.append({
                "name": s["name"], "code": code, "score": s["score"],
                "reason": f"评分{s['score']:.0f}但验证无效({s.get('verify_label','?')})，长期不可靠",
            })
        # 警告：今日大涨但资金流出（诱多）
        if today_pct > 2 and ff < 0:
            warnings.append({
                "name": s["name"], "code": code, "score": s["score"],
                "reason": f"今日+{today_pct:.1f}%但主力资金{ff:.0f}万流出，警惕诱多",
            })

    # 排序：综合强度降序
    ranked.sort(key=lambda x: -x["combo"])

    # 推荐买入：验证有效 + 量价健康度>=60（可买/观望） + 今日非大跌
    # 关键：加入量价健康度过滤，避免"资金强但量价差"的盲目追进
    valid_ranked = [r for r in ranked if r["verify"] == "valid"]
    top_buys = [
        r for r in valid_ranked
        if r.get("pv_health", 50) >= 50 and r["today_pct"] > -1
    ][:5]
    # 若量价健康的不够，补充综合强度高的（但标注量价状态）
    if len(top_buys) < 3:
        extra = [r for r in valid_ranked if r not in top_buys][:3 - len(top_buys)]
        top_buys.extend(extra)

    # 总结
    if top_buys:
        top_names = "、".join(r["name"] for r in top_buys[:3])
        summary = f"短期强度Top：{top_names}；综合评分+资金+量价健康度筛选"
    else:
        summary = "当前无满足条件的短期买入标的"

    return {
        "generated_at": scan["generated_at"],
        "ranked": ranked,
        "top_buys": top_buys,
        "warnings": warnings,
        "summary": summary,
        "disclaimer": "短期排名综合评分/资金流/今日表现/验证，仅供短线参考；验证有效=长期可靠，短期排名=当前强度，两者结合使用。",
    }


if __name__ == "__main__":
    import json
    r = short_term_ranking()
    print("=== 短期强度排名 ===")
    print("总结:", r["summary"])
    print()
    for i, x in enumerate(r["ranked"][:10]):
        mark = "📌" if x["holding"] else ""
        print(f"  {i+1}. {x['name']:<8} 评分{x['score']:>5.1f} 资金{x['main_net_5d']:>+8.0f}万 今日{x['today_pct']:>+5.2f}% 综合{x['combo']:>6.1f} {mark}")
    print()
    if r["warnings"]:
        print("警告:")
        for w in r["warnings"]:
            print(f"  ⚠️ {w['name']}: {w['reason']}")
