# -*- coding: utf-8 -*-
"""
CherryQuant Web — 自动再平衡计算器
根据组合优化的目标权重 vs 当前实际持仓，计算每只ETF该买/卖多少份额。

逻辑:
  1. 账户总资金 = 资金账本总权益（现金 + 持仓市值）；旧账户未初始化时退回锚点
  2. 每只目标市值 = 总资金 × 目标权重 × 市场温度档位
  3. 差额 = 目标市值 - 当前市值
  4. 差额>0 → 需加仓（买），差额<0 → 需减仓（卖）
  5. 按现价折算成份额（100的整数倍）

修复（GPT 复核 E/#08）：
  - 默认调用（不传 total_capital）不再拿“剩余持仓市值”当总资金，否则半仓执行后
    目标市值随持仓缩水、每次刷新都要求继续减仓（1000→500→250→…的重复减仓）。
  - 缺行情的持仓：current_price/market_value 返回 None 并标 no_data=True，
    不再把价格当 0 参与算式，也不让整个接口报错。

迭代 A（现金账本，2026-11-10）：
  - 账户已初始化（base_cash 存在 或 有 DEPOSIT/WITHDRAW 外部入出金行；纯成交行不算）时，
    默认路径 = `account.get_account_equity()` 的 total_equity（现金 + 持仓市值），
    响应带 cash / ledger_initialized；不再用“持仓市值”或旧锚点当总资金。
  - 显式传 total_capital 时仍以外部值为准（兼容旧调用），并写 account_meta
    ['anchor_total_capital']（同时更新旧 app_meta 键，兼容历史页面/接口）。
  - 账户未初始化（旧账户/旧测试路径）保留原锚点逻辑：account_meta 锚点优先，
    回退旧 app_meta['account_total_capital']，再回退持仓市值初始化并提示。
  - 缺行情 no_data / valuation_complete / missing_quotes 逻辑保持不变。
"""
import numpy as np

from .data import fetch
from . import db
from .config import CODE2NAME

# 账户总资金锚点：
#   ANCHOR_KEY       —— 旧 app_meta 键（历史账户/旧接口仍在读，保留兼容）
#   LEDGER_ANCHOR_KEY—— 资金账本 account_meta 键（迭代 A §1 约定）
ANCHOR_KEY = "account_total_capital"
LEDGER_ANCHOR_KEY = "anchor_total_capital"

# 资金账本模块（迭代 A）。尚不可用时退回旧锚点逻辑，旧账户/旧测试不受影响。
try:
    from .account import get_account_equity
except Exception:  # pragma: no cover - 仅 foundation 未就绪的过渡期
    get_account_equity = None


# ==================== account_meta 读写（db.py helper，迭代 A §1） ====================

def _account_meta_get(key, default=None):
    """读取 account_meta 单键（db.get_account_meta 在 foundation 未就绪时安全降级）。"""
    fn = getattr(db, "get_account_meta", None)
    if not callable(fn):
        return default
    return fn(key, default)


def _account_meta_set(key, value):
    """写入 account_meta 单键；helper 不可用时返回 False（不重复实现 SQL）。"""
    fn = getattr(db, "set_account_meta", None)
    if not callable(fn):
        return False
    fn(key, value)
    return True


def _anchor_value():
    """读取账户总资金锚点：account_meta.anchor_total_capital 优先，回退旧 app_meta。"""
    raw = _account_meta_get(LEDGER_ANCHOR_KEY)
    if raw is None:
        raw = db.get_app_meta(ANCHOR_KEY)
    if raw is None:
        return None
    try:
        v = float(raw)
    except (TypeError, ValueError):
        return None
    return v if v > 0 else None


def _save_anchor(total_equity: float):
    """持久化账户总资金锚点（兼容旧账户）：account_meta 新键 + 旧 app_meta 键。"""
    val = f"{float(total_equity):.2f}"
    _account_meta_set(LEDGER_ANCHOR_KEY, val)
    try:
        db.set_app_meta(ANCHOR_KEY, val)
    except Exception:
        pass


# ==================== 账户总资金口径 ====================

def _account_equity_snapshot():
    """资金账本权益快照（with_twr=False）；账本模块不可用返回 None。"""
    if get_account_equity is None:
        return None
    eq = get_account_equity(with_twr=False)
    return eq if isinstance(eq, dict) else None


def _resolve_capital(total_capital, total_mv: float) -> dict:
    """解析账户总资金（现金+持仓）、来源与估值辅助字段。

    返回 {total_equity, capital_source, anchor_initialized, cash, ledger_initialized}
    - 账本已初始化：默认用账本 total_equity（现金+持仓市值）；显式 total_capital 覆盖。
    - 账户未初始化：保留旧锚点逻辑（account_meta 锚点 → 旧 app_meta 锚点 → 持仓市值初始化）。
    """
    explicit = total_capital is not None and float(total_capital) > 0
    eq = _account_equity_snapshot()
    # 判据用 account.get_account_equity() 返回的 ledger_initialized（base_cash 或外部入出金行）
    ledger_initialized = bool(eq and eq.get("ledger_initialized"))

    cash = None
    if ledger_initialized and eq is not None and eq.get("cash") is not None:
        try:
            cash = round(float(eq["cash"]), 2)
        except (TypeError, ValueError):
            cash = None

    # ---- 1. 资金账本已初始化：默认口径 = 现金 + 持仓市值 ----
    if ledger_initialized:
        if explicit:
            total_equity = float(total_capital)
            _save_anchor(total_equity)
            capital_source = "外部传入总资金（现金+持仓）"
        else:
            # 账本口径为唯一真相：即使总权益<=0 也用账本值（不回退旧锚点），如实说明
            try:
                total_equity = float(eq.get("total_equity") or 0.0)
            except (TypeError, ValueError):
                total_equity = 0.0
            capital_source = "账户总权益（现金+持仓，来自资金账本）"
            if total_equity <= 0:
                capital_source += "；当前总权益≤0（现金不足或估值缺失），请先入金/核对账本"
        return {
            "total_equity": total_equity,
            "capital_source": capital_source,
            "anchor_initialized": False,
            "cash": cash,
            "ledger_initialized": True,
        }

    # ---- 2. 账户未初始化：保留旧锚点逻辑（旧账户/旧测试兼容）----
    anchor = _anchor_value()
    anchor_initialized = False
    if explicit:
        total_equity = float(total_capital)
        _save_anchor(total_equity)
        capital_source = "外部传入总资金（现金+持仓）"
    elif anchor is not None:
        total_equity = anchor
        capital_source = ("账户总资金锚点 account_meta.anchor_total_capital / "
                          "旧 app_meta.account_total_capital（现金+持仓；"
                          "默认路径不会随持仓缩水而重复减仓）")
    else:
        # 无锚点：用当前持仓市值初始化（不伪造现金，只做预算基准并明确提示）
        total_equity = total_mv
        anchor_initialized = True
        if total_equity > 0:
            _save_anchor(total_equity)
            capital_source = ("未传总资金，已用当前持仓市值初始化账户总资金锚点"
                              "（不含现金，仅作预算基准；有现金请传 ?total_capital=现金+持仓）")
        else:
            capital_source = "无持仓市值且未传总资金，无法确定账户总资金"

    return {
        "total_equity": total_equity,
        "capital_source": capital_source,
        "anchor_initialized": anchor_initialized,
        "cash": cash,
        "ledger_initialized": False,
    }


def rebalance_plan(total_capital: float = None) -> dict:
    """生成再平衡计划。

    total_capital: 账户总权益（现金 + 持仓市值）。传入则写入/更新账户锚点并优先使用；
    不传时：资金账本已初始化 → 用账本总权益（现金+持仓）；否则读旧锚点——
    半仓执行后再次刷新不会重复减仓（默认路径）。
    """
    positions = db.load_positions()
    if not positions:
        return {"error": "无持仓"}

    # 获取信号（含组合优化目标权重）
    from .signals import scan_all_signals
    scan = scan_all_signals()
    pf = scan.get("portfolio")
    if not pf or not pf.get("holdings"):
        return {"error": "组合优化不可用"}

    # ---- 现价与当前市值（缺行情 = None，不再当 0 参与算式）----
    prices, cur_mvs, missing = {}, {}, []
    for code in positions:
        df = fetch(code, offline=True)
        price = float(df["close"].iloc[-1]) if len(df) else None
        prices[code] = price
        if price is None:
            cur_mvs[code] = None
            missing.append({"code": code, "name": positions[code].get("name", CODE2NAME.get(code, code))})
        else:
            cur_mvs[code] = positions[code]["shares"] * price
    total_mv = sum(v for v in cur_mvs.values() if v is not None)

    # ---- 账户总资金（现金+持仓）与来源（迭代 A：优先资金账本）----
    cap = _resolve_capital(total_capital, total_mv)
    total_equity = cap["total_equity"]
    capital_source = cap["capital_source"]
    anchor_initialized = cap["anchor_initialized"]

    # ===== 市场温度择时（2026-09-02 接入：回测实测温度关收益普遍腰斩）=====
    # <40 偏空 → 目标仓位 0%（空仓）；40-60 → 半仓；>60 → 满仓
    temp = float(scan.get("market", {}).get("temp", 50))
    regime = 1.0
    if temp < 40:
        regime = 0.0
    elif temp < 60:
        regime = 0.5
    regime_txt = ("空仓(温度<40)" if regime == 0 else
                  "半仓(温度40-60)" if regime < 1 else "满仓(温度>60)")

    # 目标权重 map
    target_map = {h["code"]: h["weight"] for h in pf["holdings"]}

    plans = []
    total_buy = 0.0
    total_sell = 0.0

    for code, pos in positions.items():
        name = pos.get("name", CODE2NAME.get(code, code))
        shares = pos["shares"]
        price = prices.get(code)
        cur_mv = cur_mvs.get(code)
        target_weight = target_map.get(code, 0) / 100.0
        target_mv = total_equity * target_weight * regime   # 温度择时缩放目标仓位（按账户总资金）

        no_data = price is None
        if no_data:
            # 缺行情：无法计算当前市值与差额，跳过买卖计算并显式标记
            diff = None
            action = "行情缺失"
            hint = "缺行情，无法计算当前市值/差额，请先刷新该标的数据"
            add_shares = sell_shares = 0
            cur_pct = None
        else:
            diff = target_mv - cur_mv
            cur_pct = round(cur_mv / total_equity * 100, 1) if total_equity > 0 else 0.0
            add_shares = sell_shares = 0
            if diff > 0 and price > 0:
                # 加仓：算出可买份额（100整数倍）
                add_shares = int(diff / price // 100 * 100)
                add_amount = add_shares * price
                action = "买入"
                total_buy += add_amount
                hint = f"加仓 {add_shares}份 (约{add_amount:.0f}元)"
            elif diff < -100 and price > 0:
                # 减仓：卖出份额
                sell_shares = int(-diff / price // 100 * 100)
                sell_amount = sell_shares * price
                action = "卖出"
                total_sell += sell_amount
                hint = f"减仓 {sell_shares}份 (约{sell_amount:.0f}元)"
            else:
                action = "持有"
                hint = "仓位基本合适"

        plans.append({
            "code": code, "name": name,
            "shares": shares, "price": (None if no_data else round(price, 3)),
            "cur_mv": (None if no_data else round(cur_mv, 0)),
            "cur_pct": cur_pct,
            "target_pct": round(target_weight * 100, 1),
            "target_mv": round(target_mv, 0),
            "diff": (None if diff is None else round(diff, 0)),
            "no_data": no_data,
            "action": action, "hint": hint,
            "add_shares": add_shares if action == "买入" else 0,
            "sell_shares": sell_shares if action == "卖出" else 0,
        })

    # 排序：买入在前，卖出在后，缺行情最后
    order = {"买入": 0, "卖出": 1, "持有": 2, "行情缺失": 3}
    plans.sort(key=lambda x: order.get(x["action"], 3))

    return {
        "total_market_value": round(total_mv, 0),
        "total_equity": round(total_equity, 2),
        "cash": cap["cash"],
        "ledger_initialized": cap["ledger_initialized"],
        "capital_source": capital_source,
        "anchor_initialized": anchor_initialized,
        "valuation_complete": (len(missing) == 0),
        "missing_quotes": missing,
        "total_buy": round(total_buy, 0),
        "total_sell": round(total_sell, 0),
        "plans": plans,
        "market_temp": round(temp, 1),
        "regime": regime_txt,
        "note": f"市场温度 {temp:.0f} → {regime_txt}（目标权重已按温度缩放）。"
                "目标市值按账户总资金计算（资金账本已初始化时=现金+持仓；未初始化时=旧锚点/"
                "持仓市值预算基准），默认路径不会随持仓缩水而重复减仓；"
                "建议每40个交易日做一次完整再平衡(变体扫描实测优于20日)，避免过度交易。"
                "再平衡后若卖出回笼资金不足以覆盖加仓，需补充现金或分批执行",
    }
