# -*- coding: utf-8 -*-
"""
CherryQuant Web — 行业轮动/板块强弱分析
计算各 ETF 所属板块的相对强弱（多周期动量），识别当前领涨/领跌赛道。
"""
import numpy as np
import pandas as pd

from .data import fetch
from .config import POOL


def sector_rotation(periods: tuple = (5, 20, 60)) -> dict:
    """
    计算全池 ETF 的板块相对强弱。
    返回按动量分排序的板块列表 + 强/弱板块分组。

    动量权重说明（V2 优化）:
      旧: r20*0.5 + r5*0.3 + r60*0.2  → 过度偏近期，把"中期强+短期回调"误判为弱势
      新: r60*0.4 + r20*0.35 + r5*0.25 → 中期趋势为主，兼顾短期回暖
      这样能识别"60日强+回调企稳"的板块（趋势跟随的买点），而不是只看最近20天。
    """
    rows = []
    for name, info in POOL.items():
        df = fetch(info["code"], offline=True)
        c = df["close"]
        if len(c) < max(periods) + 5:
            continue
        rets = {}
        for p in periods:
            if len(c) > p:
                rets[f"r{p}"] = (c.iloc[-1] / c.iloc[-1 - p] - 1) * 100

        # 综合动量分：中期趋势为主(0.4)，近20日(0.35)，近5日确认短期回暖(0.25)
        score = rets.get(f"r{periods[2]}", 0) * 0.4 + rets.get(f"r{periods[1]}", 0) * 0.35 \
                + rets.get(f"r{periods[0]}", 0) * 0.25

        # 趋势质量：中期强 + 短期回暖 = 最佳买点（避免追已涨高的）
        trend_quality = "强趋势" if (rets.get("r60", 0) > 5 and rets.get("r5", 0) > -2) else (
            "回调企稳" if (rets.get("r60", 0) > 5 and rets.get("r20", 0) < 0 and rets.get("r5", 0) > 0) else (
            "超跌反弹" if (rets.get("r60", 0) < -10 and rets.get("r5", 0) > 3) else (
            "下跌趋势" if rets.get("r60", 0) < -5 else "震荡")))

        rows.append({
            "name": name, "code": info["code"],
            "r5": round(rets.get("r5", 0), 1),
            "r20": round(rets.get("r20", 0), 1),
            "r60": round(rets.get("r60", 0), 1),
            "momentum": round(score, 1),
            "trend_quality": trend_quality,
        })

    rows.sort(key=lambda x: -x["momentum"])

    # 强弱分组
    strong = [r for r in rows if r["momentum"] > 5]
    weak = [r for r in rows if r["momentum"] < -5]
    neutral = [r for r in rows if -5 <= r["momentum"] <= 5]

    # 总结
    if strong:
        summary = f"当前强势板块：{', '.join(r['name'] for r in strong[:3])}；"
    else:
        summary = "当前无强势板块；"
    if weak:
        summary += f"弱势板块：{', '.join(r['name'] for r in weak[:3])}"
    else:
        summary += "无弱势板块"

    # 持仓板块强弱
    from . import db
    positions = db.load_positions()
    holding_sectors = []
    for r in rows:
        if r["code"] in positions:
            r_holding = {**r, "holding": True,
                         "weight_pct": round(positions[r["code"]]["shares"] *
                                             fetch(r["code"], offline=True)["close"].iloc[-1], 0)}
            holding_sectors.append(r_holding)

    return {
        "sectors": rows,
        "strong": strong,
        "weak": weak,
        "neutral": neutral,
        "holding_sectors": holding_sectors,
        "summary": summary,
        "updated_at": pd.Timestamp.now().strftime("%Y-%m-%d"),
    }
