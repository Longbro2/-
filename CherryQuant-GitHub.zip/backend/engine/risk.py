# -*- coding: utf-8 -*-
"""
CherryQuant Web — 组合风险模型
基于持仓的收益率协方差矩阵，量化组合风险：
  1. 每只 ETF 的年化波动率
  2. 组合整体波动率
  3. 每只 ETF 对组合风险的贡献度（风险分解）
  4. 组合 VaR / CVaR（风险价值）
"""
import numpy as np
import pandas as pd

from .data import fetch
from . import db

TRADING_DAYS = 252


def _returns_for_codes(codes: list) -> pd.DataFrame:
    """构建多只 ETF 的日收益率矩阵"""
    rets = {}
    for c in codes:
        df = fetch(c, offline=True)
        if len(df) > 30:
            rets[c] = df.set_index("date")["close"].pct_change()
    if not rets:
        return pd.DataFrame()
    return pd.DataFrame(rets).dropna()


def portfolio_risk(codes: list = None, weights: dict = None) -> dict:
    """
    计算组合风险。
    codes: 持仓代码列表（默认取全部持仓）
    weights: {code: 权重占比(0-1)}，默认等权
    """
    if codes is None:
        positions = db.load_positions()
        codes = list(positions.keys())
    if len(codes) < 1:
        return {"error": "无持仓"}

    ret_df = _returns_for_codes(codes)
    # 修复（第 22 项）：收益矩阵会丢掉无数据标的的列，权重/代码列表必须同步过滤，
    # 否则会出现矩阵维度错误（风险）或越界（相关性）。
    missing_codes = [c for c in codes if c not in ret_df.columns]
    avail = [c for c in codes if c in ret_df.columns]
    if not avail:
        return {"error": "全部持仓缺少行情", "missing_codes": missing_codes}
    if len(ret_df) < 30:
        return {"error": "数据不足", "missing_codes": missing_codes}
    codes = avail
    ret_df = ret_df[codes]

    # 默认等权（只在有数据的标的上分配）
    if weights is None:
        w = np.ones(len(codes)) / len(codes)
    else:
        w = np.array([weights.get(c, 0) for c in codes], dtype=float)
        s = w.sum()
        if s <= 0:
            w = np.ones(len(codes)) / len(codes)
        else:
            w = w / s

    # 协方差矩阵（年化）
    cov = ret_df.cov() * TRADING_DAYS

    # 每只年化波动率
    vols = np.sqrt(np.diag(cov))
    names = {c: c for c in codes}

    # 组合波动率
    port_var = w @ cov.values @ w.T
    port_vol = np.sqrt(port_var)
    port_vol_pct = port_vol * 100

    # 风险贡献（边际贡献×权重）/ 组合波动率
    # 边际风险贡献 MRC_i = (Σ w_j σ_ij) / σ_p
    mrc = (cov.values @ w) / port_vol
    rc = w * mrc  # 风险贡献
    rc_pct = rc / port_vol * 100  # 百分比贡献

    # VaR (95%, 单日)
    daily_ret_mean = ret_df.mean().values @ w
    daily_ret_std = port_vol / np.sqrt(TRADING_DAYS)
    # 正态近似 VaR
    var_95 = -(daily_ret_mean - 1.645 * daily_ret_std) * 100
    var_99 = -(daily_ret_mean - 2.326 * daily_ret_std) * 100

    # 持仓明细
    holdings_detail = []
    for i, c in enumerate(codes):
        holdings_detail.append({
            "code": c,
            "name": names.get(c, c),
            "weight_pct": round(float(w[i] * 100), 1),
            "vol_pct": round(float(vols[i] * 100), 1),       # 年化波动率
            "risk_contrib_pct": round(float(rc_pct[i]), 1),  # 风险贡献占比
        })
    holdings_detail.sort(key=lambda x: -x["risk_contrib_pct"])

    # 风险集中度：最大风险贡献占比
    max_rc = max(rc_pct) if len(rc_pct) else 0

    return {
        "codes": codes,
        "missing_codes": missing_codes,
        "coverage_days": len(ret_df),
        "valuation_complete": (len(missing_codes) == 0),
        "n_holdings": len(codes),
        "port_vol_pct": round(float(port_vol_pct), 2),
        "daily_var_95_pct": round(float(var_95), 2),
        "daily_var_99_pct": round(float(var_99), 2),
        "max_risk_contrib_pct": round(float(max_rc), 1),
        "holdings": holdings_detail,
        "corr_matrix": [[round(float(x), 2) for x in row] for row in ret_df.corr().values],
    }
