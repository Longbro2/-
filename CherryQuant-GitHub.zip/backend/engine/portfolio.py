# -*- coding: utf-8 -*-
"""
CherryQuant Web — 组合优化模块
基于 验证状态 × 评分 × 资金流 三维度，计算建议仓位权重。

核心思想:
  验证有效 + 评分高 + 资金流入 → 高权重
  验证无效 + 评分低 + 资金流出 → 低权重（减仓）

输出:
  holdings_weight: 每只持仓的建议权重(%) + 调仓建议
  summary: 一句话总结
"""
import numpy as np

from .verify import load_verify_map
from .config import POOL


def _score_component(s: dict) -> float:
    """信号强度分 (0-1)：评分归一化"""
    return max(0, min(1, s.get("score", 0) / 100.0))


def _verify_component(s: dict) -> float:
    """验证可靠性分 (0-1)"""
    v = s.get("verify", "nodata")
    return {
        "valid": 1.0,
        "weak": 0.5,
        "invalid": 0.2,
        "nodata": 0.3,   # 数据不足 → 保守偏低
    }.get(v, 0.3)


def _fflow_component(s: dict) -> float:
    """资金流强度分 (0-1)：主力5日净流入归一化"""
    fflow5 = s.get("main_net_5d", 0)
    if fflow5 is None:
        return 0.4
    # 归一化到 -1~1（±5000万为极限）
    norm = max(-1, min(1, fflow5 / 5000.0))
    return (norm + 1) / 2.0  # 0-1


def compute_portfolio_weights(scan: dict) -> dict:
    """
    计算组合建议权重。
    scan: scan_all_signals() 的返回。
    返回每只持仓的建议权重 + 调仓方向。
    """
    signals = {s["code"]: s for s in scan["signals"]}
    holdings = scan["holdings"]

    # 计算每只的综合得分
    scores = {}
    for h in holdings:
        code = h["code"]
        s = signals.get(code, {})
        # 三维加权: 验证(0.5) + 信号(0.3) + 资金流(0.2)
        combined = (
            0.5 * _verify_component(s) +
            0.3 * _score_component(s) +
            0.2 * _fflow_component(s)
        )
        scores[code] = {
            "code": code,
            "name": h["name"],
            "score": combined,
            "verify_score": _verify_component(s),
            "signal_score": _score_component(s),
            "fflow_score": _fflow_component(s),
            "current_pct": h["market_value"],
        }

    # 归一化为权重（总和100）
    total = sum(v["score"] for v in scores.values())
    if total <= 0:
        total = 1.0
    for code, v in scores.items():
        v["weight"] = round(v["score"] / total * 100, 1)

    # 调仓建议：对比"当前市值占比"和"建议权重"
    # 修复（第 21 项）：缺行情的持仓市值是 None，不参与总额/占比；显式标记缺失
    total_mv = sum(h["market_value"] for h in holdings
                   if h.get("market_value") is not None)
    missing_codes = [h["code"] for h in holdings if h.get("no_data")]
    for h in holdings:
        code = h["code"]
        if h.get("market_value") is None:
            scores[code]["current_pct"] = None
            scores[code]["diff"] = None
            scores[code]["action"] = "⏸ 行情缺失"
            scores[code]["no_data"] = True
            continue
        current_pct = (h["market_value"] / total_mv * 100) if total_mv else 0
        target = scores[code]["weight"]
        diff = target - current_pct
        if diff > 8:
            action = "➕ 加仓"
        elif diff < -8:
            action = "➖ 减仓"
        elif abs(diff) <= 3:
            action = "✅ 维持"
        else:
            action = "🟡 微调"
        scores[code]["current_pct"] = round(current_pct, 1)
        scores[code]["diff"] = round(diff, 1)
        scores[code]["action"] = action

    # 排序（按建议权重）
    ranked = sorted(scores.values(), key=lambda x: -x["weight"])

    # 相关性惩罚（避免重复持仓：高相关标的同时降权）
    try:
        from .correlation import correlation_penalty
        codes = list(scores.keys())
        ranked_adj = correlation_penalty(ranked, codes)
        if ranked_adj:
            ranked = ranked_adj
    except Exception:
        pass

    # 总结
    top = ranked[0] if ranked else None
    if top:
        summary = (f"建议重点持有 <b>{top['name']}</b>（权重{top.get('weight_adj', top['weight'])}%），"
                   f"验证/信号/资金流综合最强")
    else:
        summary = "暂无持仓"

    return {
        "holdings": ranked,
        "summary": summary,
        "total_market_value": round(total_mv, 2),
        "valuation_complete": (len(missing_codes) == 0),
        "missing_codes": missing_codes,
    }
