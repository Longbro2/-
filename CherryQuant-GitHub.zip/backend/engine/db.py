# -*- coding: utf-8 -*-
"""
CherryQuant Web — SQLite 存储层
行情元数据、持仓、成交、止损峰值、信号历史。
行情 K 线本身存 CSV（分源），这里只存 meta 与账户状态。
"""
import json
import math
import re
import sqlite3
from datetime import datetime
from pathlib import Path

from .config import DB_PATH, LEGACY_DIR, CODE2NAME

SCHEMA = """
CREATE TABLE IF NOT EXISTS etf_meta (
    code TEXT PRIMARY KEY,
    name TEXT,
    source TEXT,              -- eastmoney / akshare / choice / legacy
    last_date TEXT,
    row_count INTEGER,
    updated_at TEXT
);
CREATE TABLE IF NOT EXISTS positions (
    code TEXT PRIMARY KEY,
    name TEXT,
    shares REAL,
    cost_price REAL,
    date TEXT
);
CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    action TEXT,
    code TEXT,
    name TEXT,
    amount REAL,
    price REAL,
    shares REAL
);
CREATE TABLE IF NOT EXISTS peaks (
    code TEXT PRIMARY KEY,
    peak REAL
);
CREATE TABLE IF NOT EXISTS signal_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    code TEXT,
    name TEXT,
    signal TEXT,
    score REAL,
    price REAL
);
CREATE TABLE IF NOT EXISTS app_meta (
    key TEXT PRIMARY KEY,
    value TEXT
);
CREATE TABLE IF NOT EXISTS account_meta (
    key TEXT PRIMARY KEY,
    value TEXT
);
CREATE TABLE IF NOT EXISTS cash_ledger (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,              -- YYYY-MM-DD 或 ISO datetime（口径按 [:10] 归一）
    type TEXT NOT NULL,              -- DEPOSIT/WITHDRAW/FEE/DIVIDEND/REALIZED_PNL/BUY_SETTLE/SELL_SETTLE
    amount REAL NOT NULL,            -- 对现金的影响：正=流入，负=流出
    note TEXT,
    trade_id INTEGER
);
"""

# ============ 资金账本口径（迭代 A） ============
LEDGER_TYPES = frozenset({
    "DEPOSIT", "WITHDRAW", "FEE", "DIVIDEND",
    "REALIZED_PNL", "BUY_SETTLE", "SELL_SETTLE",
})
# 计入现金余额的类型；REALIZED_PNL 只是信息行（现金已体现在 SELL_SETTLE 里），不重复计入
CASH_EFFECT_TYPES = frozenset({
    "DEPOSIT", "WITHDRAW", "FEE", "DIVIDEND", "BUY_SETTLE", "SELL_SETTLE",
})
_ACCOUNT_META_DEFAULTS = {
    "base_cash": "0",
}


def get_conn() -> sqlite3.Connection:
    # timeout: 并发写(多线程刷新 meta / 记账)时最多等 10s，避免直接抛 database is locked
    conn = sqlite3.connect(str(DB_PATH), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn


def init_db():
    conn = get_conn()
    try:
        conn.executescript(SCHEMA)
        _migrate_trades_columns(conn)
        conn.commit()
    finally:
        conn.close()
    # 历史账户（有成交、无账本、无 base_cash）自动建立期初现金基线（只写 account_meta）
    _ensure_legacy_cash_baseline()


def _table_columns(conn, table: str) -> set:
    try:
        return {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    except sqlite3.Error:
        return set()


def _migrate_trades_columns(conn):
    """迭代 A 迁移：trades 只增列（fee/cash_after/realized_pnl），不改历史行。"""
    cols = _table_columns(conn, "trades")
    for col, ddl in (("fee", "REAL"), ("cash_after", "REAL"), ("realized_pnl", "REAL")):
        if col not in cols:
            conn.execute(f"ALTER TABLE trades ADD COLUMN {col} {ddl}")


def _ensure_legacy_cash_baseline() -> bool:
    """历史账户现金基线（迭代 A 迁移，幂等）。

    老库只有 持仓/成交、没有现金来源。这里用全部历史成交的净额（ΣSELL-ΣBUY）作为
    「期初现金基线 base_cash」，只写 account_meta（不修改任何历史成交行），
    使 cash = base_cash + Σ账本 与旧账户的实际可用现金一致。
    历史手续费当时未记录，因此未从基线中扣除（note 里说明）。
    返回是否本次新建了基线。
    """
    conn = get_conn()
    try:
        if conn.execute("SELECT 1 FROM account_meta WHERE key='base_cash'").fetchone():
            return False
        n_ledger = conn.execute("SELECT COUNT(*) c FROM cash_ledger").fetchone()["c"]
        n_trades = conn.execute("SELECT COUNT(*) c FROM trades").fetchone()["c"]
        if n_ledger or not n_trades:
            return False
        net = 0.0
        for r in conn.execute("SELECT action, amount FROM trades").fetchall():
            action = (r["action"] or "").strip().upper()
            amt = float(r["amount"] or 0.0)
            if action == "BUY":
                net -= amt
            elif action == "SELL":
                net += amt
        base = round(max(0.0, net), 2)
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("INSERT OR REPLACE INTO account_meta(key,value) VALUES('base_cash',?)",
                     (f"{base:.2f}",))
        conn.execute(
            "INSERT OR REPLACE INTO account_meta(key,value) VALUES('ledger_baseline_note',?)",
            (f"期初现金基线=历史成交净额(ΣSELL-ΣBUY)={net:.2f}；"
             f"取 base_cash={base:.2f}（历史未记录手续费/入金，可用 /api/account/import-trades 对账）",),
        )
        conn.commit()
        return True
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        conn.close()


# ================== etf_meta ==================

def upsert_meta(code: str, name: str, source: str, last_date: str, row_count: int):
    conn = get_conn()
    conn.execute(
        """INSERT INTO etf_meta(code,name,source,last_date,row_count,updated_at)
           VALUES(?,?,?,?,?,?)
           ON CONFLICT(code) DO UPDATE SET
             name=excluded.name, source=excluded.source, last_date=excluded.last_date,
             row_count=excluded.row_count, updated_at=excluded.updated_at""",
        (code, name, source, last_date, row_count, datetime.now().isoformat(timespec="seconds")),
    )
    conn.commit()
    conn.close()


def get_meta(code: str):
    conn = get_conn()
    row = conn.execute("SELECT * FROM etf_meta WHERE code=?", (code,)).fetchone()
    conn.close()
    return dict(row) if row else None


def list_meta():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM etf_meta ORDER BY code").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ================== positions ==================

def _real_name(code: str, stored: str) -> str:
    """纠正 name：数据库早期版本把 code 误存进了 name 字段。
    这里以 CODE2NAME（官方配置）为权威，存错的代码/未知名一律映射成真名。"""
    # private attribute 无其他来源会抛，先查配置
    mapped = CODE2NAME.get(code)
    if mapped:
        return mapped
    # 不在池内：若存的是纯6位代码则无更优解，用原存值
    if stored and not re.fullmatch(r"\d{6}", stored):
        return stored
    return stored or code


def load_positions() -> dict:
    """返回 {code: {shares, cost, cost_price, date, name}}"""
    conn = get_conn()
    rows = conn.execute("SELECT * FROM positions").fetchall()
    conn.close()
    out = {}
    for r in rows:
        out[r["code"]] = {
            "shares": r["shares"],
            "cost": round(r["shares"] * r["cost_price"], 2),
            "cost_price": r["cost_price"],
            "date": r["date"],
            "name": _real_name(r["code"], r["name"] or r["code"]),
        }
    return out


def save_positions(positions: dict):
    conn = get_conn()
    conn.execute("DELETE FROM positions")
    now = datetime.now().isoformat(timespec="seconds")
    for code, p in positions.items():
        conn.execute(
            "INSERT INTO positions(code,name,shares,cost_price,date) VALUES(?,?,?,?,?)",
            (code, p.get("name", code), p.get("shares", 0), p.get("cost_price", 0), p.get("date", now)),
        )
    conn.commit()
    conn.close()


# ================== trades ==================

def load_trades() -> list:
    conn = get_conn()
    rows = conn.execute("SELECT * FROM trades ORDER BY date").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_trade(date, action, code, amount, price, shares, name=None):
    conn = get_conn()
    conn.execute(
        "INSERT INTO trades(date,action,code,name,amount,price,shares) VALUES(?,?,?,?,?,?,?)",
        (date, action, code, name or code, amount, price, shares),
    )
    conn.commit()
    conn.close()


def delete_all_trades():
    conn = get_conn()
    conn.execute("DELETE FROM trades")
    conn.commit()
    conn.close()


# ================== peaks ==================

def load_peaks() -> dict:
    conn = get_conn()
    rows = conn.execute("SELECT * FROM peaks").fetchall()
    conn.close()
    return {r["code"]: r["peak"] for r in rows}


def save_peak(code: str, peak: float):
    conn = get_conn()
    conn.execute(
        "INSERT INTO peaks(code,peak) VALUES(?,?) ON CONFLICT(code) DO UPDATE SET peak=excluded.peak",
        (code, peak),
    )
    conn.commit()
    conn.close()


def delete_peak(code: str):
    conn = get_conn()
    conn.execute("DELETE FROM peaks WHERE code=?", (code,))
    conn.commit()
    conn.close()


# ================== app_meta ==================

def get_app_meta(key: str, default=None):
    """读取 app_meta 单键（不存在返回 default）。"""
    conn = get_conn()
    try:
        row = conn.execute("SELECT value FROM app_meta WHERE key=?", (key,)).fetchone()
    finally:
        conn.close()
    return row["value"] if row else default


def set_app_meta(key: str, value):
    """写入/覆盖 app_meta 单键（值统一转成字符串存储）。"""
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO app_meta(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)),
        )
        conn.commit()
    finally:
        conn.close()


def delete_app_meta(key: str):
    conn = get_conn()
    try:
        conn.execute("DELETE FROM app_meta WHERE key=?", (key,))
        conn.commit()
    finally:
        conn.close()


# ================== account_meta / cash_ledger（迭代 A 资金账本） ==================

def get_account_meta(key: str, default=None):
    conn = get_conn()
    try:
        row = conn.execute("SELECT value FROM account_meta WHERE key=?", (key,)).fetchone()
    finally:
        conn.close()
    return row["value"] if row else default


def set_account_meta(key: str, value):
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO account_meta(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)),
        )
        conn.commit()
    finally:
        conn.close()


def delete_account_meta(key: str):
    conn = get_conn()
    try:
        conn.execute("DELETE FROM account_meta WHERE key=?", (key,))
        conn.commit()
    finally:
        conn.close()


def get_base_cash() -> float:
    """期初现金基线（历史账户迁移写入；新账户不存在=0）。"""
    raw = get_account_meta("base_cash")
    if raw is None:
        return 0.0
    try:
        return float(raw)
    except (TypeError, ValueError):
        return 0.0


def _ledger_date(date) -> str:
    if not date:
        return datetime.now().isoformat(timespec="seconds")
    return str(date)[:10]


def load_cash_ledger(limit: int = None) -> list:
    """按 id 升序返回账本行（limit 取最后 N 行）。"""
    conn = get_conn()
    try:
        rows = conn.execute("SELECT * FROM cash_ledger ORDER BY id").fetchall()
    finally:
        conn.close()
    out = [dict(r) for r in rows]
    if limit is not None and limit > 0:
        out = out[-int(limit):]
    return out


def ledger_entry_count() -> int:
    conn = get_conn()
    try:
        return conn.execute("SELECT COUNT(*) c FROM cash_ledger").fetchone()["c"]
    finally:
        conn.close()


def ledger_initialized() -> bool:
    """账户是否已建立资金账本（有 base_cash 或已有入金/出金外部现金流）。

    注意：仅有成交产生的 BUY_SETTLE/SELL_SETTLE/FEE 行**不算**初始化——旧账户/旧测试
    只记账不记现金；首次入金/出金时才会补 base_cash（见 _ensure_baseline_before_funding_conn）。
    """
    conn = get_conn()
    try:
        return _account_initialized_conn(conn)
    finally:
        conn.close()


_EXTERNAL_FLOW_TYPES = ("DEPOSIT", "WITHDRAW")


def _account_initialized_conn(conn) -> bool:
    if conn.execute("SELECT 1 FROM account_meta WHERE key='base_cash'").fetchone():
        return True
    return conn.execute(
        "SELECT COUNT(*) c FROM cash_ledger WHERE type IN ('DEPOSIT','WITHDRAW')"
    ).fetchone()["c"] > 0


def external_flow_count() -> int:
    """入金/出金流水笔数（TWR 是否可信的依据：历史账户没有这些流水）。"""
    conn = get_conn()
    try:
        return conn.execute(
            "SELECT COUNT(*) c FROM cash_ledger WHERE type IN ('DEPOSIT','WITHDRAW')"
        ).fetchone()["c"]
    finally:
        conn.close()


def _ensure_baseline_before_funding_conn(conn) -> bool:
    """首次入金/出金前补齐 base_cash（迭代 A 账户初始化，幂等）。

    账户未初始化但已通过 apply_trade 记过成交时，用 base_cash 对冲这些成交账本的净额，
    使“入金前现金=0”（历史成交视为已由期初资金结算）。只写 account_meta，不改历史行。
    """
    if conn.execute("SELECT 1 FROM account_meta WHERE key='base_cash'").fetchone():
        return False
    types = sorted(CASH_EFFECT_TYPES)
    marks = ",".join("?" for _ in types)
    prior = float(conn.execute(
        f"SELECT COALESCE(SUM(amount),0) s FROM cash_ledger WHERE type IN ({marks})",
        tuple(types)).fetchone()["s"] or 0.0)
    base = round(-prior, 2)
    if abs(base) < 1e-9:
        base = 0.0
    conn.execute("INSERT OR REPLACE INTO account_meta(key,value) VALUES('base_cash',?)",
                 (f"{base:.2f}",))
    conn.execute(
        "INSERT OR REPLACE INTO account_meta(key,value) VALUES('ledger_baseline_note',?)",
        (f"账户初始化：已有成交账本净额 {prior:.2f}，以 base_cash={base:.2f} 对冲为 0",))
    return True


def _cash_balance_conn(conn) -> float:
    """事务内现金口径：base_cash + Σcash_effect 账本。"""
    row = conn.execute("SELECT value FROM account_meta WHERE key='base_cash'").fetchone()
    base = float(row["value"]) if row else 0.0
    types = sorted(CASH_EFFECT_TYPES)
    marks = ",".join("?" for _ in types)
    net = conn.execute(
        f"SELECT COALESCE(SUM(amount),0) s FROM cash_ledger WHERE type IN ({marks})",
        tuple(types)).fetchone()["s"]
    return round(base + float(net or 0.0), 6)


def cash_balance() -> float:
    conn = get_conn()
    try:
        return round(_cash_balance_conn(conn), 2)
    finally:
        conn.close()


def total_fees() -> float:
    conn = get_conn()
    try:
        row = conn.execute(
            "SELECT COALESCE(SUM(-amount),0) s FROM cash_ledger WHERE type='FEE'").fetchone()
        return round(float(row["s"] or 0.0), 2)
    finally:
        conn.close()


def _insert_ledger_conn(conn, date, entry_type, amount, note=None, trade_id=None) -> int:
    entry_type = str(entry_type).upper()
    if entry_type not in LEDGER_TYPES:
        raise ValueError(f"未知账本类型: {entry_type}")
    amt = float(amount)
    if not math.isfinite(amt):
        raise ValueError("账本金额必须是有限数字")
    cur = conn.execute(
        "INSERT INTO cash_ledger(date,type,amount,note,trade_id) VALUES(?,?,?,?,?)",
        (_ledger_date(date), entry_type, round(amt, 2), note, trade_id))
    return int(cur.lastrowid)


def add_cash_ledger_entry(date, entry_type, amount, note=None, trade_id=None) -> dict:
    """独立事务写一条账本（入金/出金/分红等非成交类）。

    迭代 A：出金的现金充足性校验在 BEGIN IMMEDIATE 事务内完成（并发出金不会 TOCTOU
    透支）；入金必须为正数。
    """
    entry_type = str(entry_type).upper()
    if entry_type not in LEDGER_TYPES:
        raise ValueError(f"未知账本类型: {entry_type}")
    amt = float(amount)
    if not math.isfinite(amt):
        raise ValueError("账本金额必须是有限数字")
    conn = get_conn()
    conn.isolation_level = None
    try:
        conn.execute("BEGIN IMMEDIATE")
        if entry_type in _EXTERNAL_FLOW_TYPES:
            # 首次入金/出金：补齐期初 base_cash，使入金前现金=0
            _ensure_baseline_before_funding_conn(conn)
        if entry_type == "DEPOSIT" and amt <= 0:
            raise TradeRejected("入金金额必须是有限正数")
        if entry_type == "WITHDRAW":
            cash = _cash_balance_conn(conn)
            if amt >= 0:
                raise TradeRejected("出金金额必须为负的现金影响（内部口径）")
            if cash + amt < -1e-6:
                raise TradeRejected(
                    f"现金不足：当前现金 {cash:.2f}，无法取出 {-amt:.2f}；"
                    "可先卖出持仓或减少出金金额")
        eid = _insert_ledger_conn(conn, date, entry_type, amt, note, trade_id)
        cash = round(_cash_balance_conn(conn), 2)
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return {"id": eid, "date": _ledger_date(date), "type": entry_type,
            "amount": round(amt, 2), "note": note, "trade_id": trade_id,
            "cash_after": cash, "cash_effect": entry_type in CASH_EFFECT_TYPES}


# ================== 记账事务（校验 + 单事务） ==================

class TradeRejected(ValueError):
    """记账业务校验失败；API 层会转换成 400。"""


def _validate_trade_input(action, code, price, shares, amount):
    if not isinstance(action, str) or action.upper() not in ("BUY", "SELL"):
        raise TradeRejected("action 必须是 BUY 或 SELL")
    if not isinstance(code, str) or not code.strip():
        raise TradeRejected("code 不能为空")
    for field, v in (("price", price), ("shares", shares)):
        try:
            fv = float(v)
        except (TypeError, ValueError):
            raise TradeRejected(f"{field} 必须是数字")
        if not math.isfinite(fv) or fv <= 0:
            raise TradeRejected(f"{field} 必须是有限正数")
    if amount not in (None, 0):
        try:
            fa = float(amount)
        except (TypeError, ValueError):
            raise TradeRejected("amount 必须是数字")
        if not math.isfinite(fa) or fa <= 0:
            raise TradeRejected("amount 必须是有限正数")
        # 口径：amount = 成交额 = price * shares（不含费用）；不一致直接拒绝
        expected = float(price) * float(shares)
        if abs(fa - expected) > max(0.02, expected * 1e-4):
            raise TradeRejected(
                f"amount({fa:.2f}) 与 price×shares({expected:.2f}) 不一致；"
                "amount 应为成交额（不含费用）")


# ================== 记账事务（校验 + 单事务 + 资金账本） ==================

def _validate_fee(fee) -> float:
    if fee in (None, ""):
        return 0.0
    try:
        fv = float(fee)
    except (TypeError, ValueError):
        raise TradeRejected("fee 必须是数字")
    if not math.isfinite(fv) or fv < 0:
        raise TradeRejected("fee 必须是有限非负数")
    return fv


def _apply_trade_conn(conn, action, code, price, shares, amount, name, date, fee) -> dict:
    """在调用方已开启的事务内执行一笔记账：持仓/峰值/成交/资金账本 + 现金校验。

    迭代 A：买卖与账本写入同一事务；SELL 记录均价法已实现盈亏；现金不足（仅当账户
    已建立资金账本时）抛 TradeRejected。
    """
    row = conn.execute("SELECT * FROM positions WHERE code=?", (code,)).fetchone()
    realized_pnl = 0.0
    if action == "BUY":
        if row:
            old_shares = float(row["shares"])
            old_cost = float(row["cost_price"])
            new_shares = old_shares + shares
            new_cost = (old_shares * old_cost + shares * price) / new_shares if new_shares else 0.0
            conn.execute(
                "UPDATE positions SET name=?,shares=?,cost_price=?,date=? WHERE code=?",
                (name, new_shares, round(new_cost, 4), date, code),
            )
        else:
            conn.execute(
                "INSERT INTO positions(code,name,shares,cost_price,date) VALUES(?,?,?,?,?)",
                (code, name, shares, price, date),
            )
            # 仅新开仓重置峰值；加仓保持旧峰值（避免盈利仓加仓后移动止盈提前触发）
            conn.execute(
                "INSERT INTO peaks(code,peak) VALUES(?,?) "
                "ON CONFLICT(code) DO UPDATE SET peak=excluded.peak",
                (code, price),
            )
        cash_effect = -(amount + fee)
        ledger_rows = [("BUY_SETTLE", -amount, "买入成交")]
        if fee > 0:
            ledger_rows.append(("FEE", -fee, "买入手续费"))
    else:  # SELL
        if not row:
            raise TradeRejected("当前未持有该标的，不能卖出")
        held = float(row["shares"])
        if shares > held + 1e-9:
            raise TradeRejected(f"卖出份数({shares})超过当前持仓({held})")
        old_cost = float(row["cost_price"])
        realized_pnl = round((price - old_cost) * shares, 2)
        remain = held - shares
        if remain <= 1e-9:
            conn.execute("DELETE FROM positions WHERE code=?", (code,))
            conn.execute("DELETE FROM peaks WHERE code=?", (code,))
        else:
            conn.execute(
                "UPDATE positions SET shares=?,date=? WHERE code=?",
                (remain, date, code),
            )
        cash_effect = amount - fee
        ledger_rows = [("SELL_SETTLE", amount, "卖出成交")]
        if fee > 0:
            ledger_rows.append(("FEE", -fee, "卖出手续费"))

    cash_before = _cash_balance_conn(conn)
    if _account_initialized_conn(conn) and cash_before + cash_effect < -1e-6:
        raise TradeRejected(
            f"现金不足：当前现金 {cash_before:.2f}，本笔需 {-cash_effect:.2f}；"
            "请先入金（POST /api/account/deposit）或导入对账")

    cur = conn.execute(
        "INSERT INTO trades(date,action,code,name,amount,price,shares,fee,cash_after,realized_pnl) "
        "VALUES(?,?,?,?,?,?,?,?,?,?)",
        (date, action, code, name, amount, price, shares, round(fee, 2), None, realized_pnl),
    )
    trade_id = int(cur.lastrowid)
    cash_after = round(cash_before + cash_effect, 2)
    conn.execute("UPDATE trades SET cash_after=? WHERE id=?", (cash_after, trade_id))
    ledger_ids = []
    for ltype, lamt, lnote in ledger_rows:
        ledger_ids.append(_insert_ledger_conn(conn, date, ltype, lamt, lnote, trade_id))
    if realized_pnl:
        # 信息行：现金已包含在 SELL_SETTLE，不重复计入（type 不在 CASH_EFFECT_TYPES）
        ledger_ids.append(_insert_ledger_conn(
            conn, date, "REALIZED_PNL", realized_pnl,
            "卖出已实现盈亏（信息行，不重复计入现金）", trade_id))
    return {"ok": True, "id": trade_id, "date": date, "action": action, "code": code,
            "name": name, "amount": amount, "price": price, "shares": shares,
            "fee": round(fee, 2), "cash_after": cash_after,
            "realized_pnl": realized_pnl, "ledger_ids": ledger_ids}


def apply_trade(action, code, price, shares, amount=None, name=None, date=None, fee=0.0) -> dict:
    """校验 + 在同一个 SQLite 事务内更新持仓/峰值/成交 + 资金账本（迭代 A）。

    - BEGIN IMMEDIATE：先拿写锁再读持仓，并发买/卖不会基于旧快照覆盖；
    - 业务校验：禁止未持有卖出、超额卖出、非法动作/非正数/非法手续费；
    - 现金校验：账户已建立资金账本时，买入/卖出手续费导致现金为负 → 拒绝；
    - 失败整体回滚（持仓、峰值、成交、账本一致）。
    """
    action = (action or "").strip().upper()
    price = float(price)
    shares = float(shares)
    _validate_trade_input(action, code, price, shares, amount)
    fee = _validate_fee(fee)
    date = date or datetime.now().isoformat(timespec="seconds")
    name = name or CODE2NAME.get(code, code)
    amount = round(price * shares, 2)

    conn = get_conn()
    conn.isolation_level = None   # 手动控制事务
    try:
        conn.execute("BEGIN IMMEDIATE")
        result = _apply_trade_conn(conn, action, code, price, shares, amount, name, date, fee)
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return result


def apply_trades_batch(trades: list) -> dict:
    """单事务批量导入成交（对账导入用）；任一失败整体回滚。"""
    if not isinstance(trades, list) or not trades:
        raise TradeRejected("trades 必须是非空数组")
    conn = get_conn()
    conn.isolation_level = None
    applied = []
    try:
        conn.execute("BEGIN IMMEDIATE")
        for t in trades:
            action = (t.get("action") or "").strip().upper()
            code = t.get("code")
            try:
                price = float(t.get("price"))
                shares = float(t.get("shares"))
            except (TypeError, ValueError):
                raise TradeRejected("price/shares 必须是数字")
            amount = round(price * shares, 2)
            _validate_trade_input(action, code, price, shares, None)
            fee = _validate_fee(t.get("fee", 0))
            name = t.get("name") or CODE2NAME.get(code, code)
            date = t.get("date") or datetime.now().isoformat(timespec="seconds")
            applied.append(_apply_trade_conn(conn, action, code, price, shares, amount,
                                             name, date, fee))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return {"applied": applied, "count": len(applied)}


def reset_account():
    """清空持仓、成交、峰值、资金账本与账户锚点（单事务，避免清一半）。"""
    conn = get_conn()
    conn.isolation_level = None
    try:
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("DELETE FROM positions")
        conn.execute("DELETE FROM trades")
        conn.execute("DELETE FROM peaks")
        # 资金账本（迭代 A）：重置账户=归零，base_cash/锚点/账本全部作废
        conn.execute("DELETE FROM cash_ledger")
        conn.execute("DELETE FROM account_meta")
        # 账户锚点属于旧账户预算基准，重置账户必须一起作废，否则新账户沿用旧总资金
        conn.execute("DELETE FROM app_meta WHERE key='account_total_capital'")
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ================== signal_log ==================

def log_signal(date, code, name, signal, score, price):
    conn = get_conn()
    conn.execute(
        "INSERT INTO signal_log(date,code,name,signal,score,price) VALUES(?,?,?,?,?,?)",
        (date, code, name, signal, score, price),
    )
    conn.commit()
    conn.close()


def load_signal_history(days: int = 30) -> list:
    conn = get_conn()
    rows = conn.execute(
        """SELECT date,code,name,signal,score,price FROM signal_log
           WHERE date >= date('now', ?) ORDER BY date DESC""",
        (f"-{days} days",),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ================== 旧项目迁移 ==================

def _import_legacy() -> bool:
    """把旧项目目录的 account.json/trades.json/peaks.json 导入 SQLite（仅空账户首次迁移时调用）。"""
    imported = False

    # account.json → positions
    acc = LEGACY_DIR / "account.json"
    if acc.exists():
        try:
            data = json.loads(acc.read_text(encoding="utf-8"))
            positions = {}
            for code, p in data.get("positions", {}).items():
                positions[code] = {
                    "name": p.get("name", code),
                    "shares": p.get("shares", 0),
                    "cost_price": p.get("cost_price", 0),
                    "date": data.get("date", datetime.now().isoformat()),
                }
            if positions:
                save_positions(positions)
                imported = True
        except Exception as e:
            print(f"  [migrate] account.json 失败: {e}")

    # trades.json → trades
    trades_file = LEGACY_DIR / "trades.json"
    if trades_file.exists():
        try:
            data = json.loads(trades_file.read_text(encoding="utf-8"))
            for t in data.get("trades", []):
                add_trade(
                    date=t.get("date"), action=t.get("action"), code=t.get("code"),
                    amount=t.get("amount", 0), price=t.get("price", 0),
                    shares=t.get("shares", 0), name=t.get("name"),
                )
            imported = True
        except Exception as e:
            print(f"  [migrate] trades.json 失败: {e}")

    # peaks.json → peaks
    peaks_file = LEGACY_DIR / "peaks.json"
    if peaks_file.exists():
        try:
            for code, peak in json.loads(peaks_file.read_text(encoding="utf-8")).items():
                save_peak(code, float(peak))
            imported = True
        except Exception as e:
            print(f"  [migrate] peaks.json 失败: {e}")

    return imported


def migrate_legacy():
    """首次启动时一次性迁移旧项目账户数据。

    旧实现用「positions 表是否为空」判断是否迁移过 → 不幂等：
    用户清仓(positions 被清空)后重启，旧 account.json/trades.json 会被重新导入，
    旧持仓“复活”且成交记录逐次叠加重复。
    现在以 app_meta['legacy_migrated'] 记录「已尝试过迁移」，只导入一次；
    且只在账户完全为空时才执行导入。
    """
    init_db()  # 确保 app_meta 等表存在（老库首次运行新代码时可能还没有）
    conn = get_conn()
    try:
        done = conn.execute("SELECT 1 FROM app_meta WHERE key='legacy_migrated'").fetchone()
        n_pos = conn.execute("SELECT COUNT(*) c FROM positions").fetchone()["c"]
        n_trades = conn.execute("SELECT COUNT(*) c FROM trades").fetchone()["c"]
    finally:
        conn.close()
    if done:
        return False  # 已尝试过迁移（无论当时是否成功导入）

    imported = False
    if n_pos == 0 and n_trades == 0:
        imported = _import_legacy()
    else:
        print("  [migrate] 账户非空，跳过旧数据导入")

    # 无论结果如何都落标记 → 之后清仓/重启不会再“复活”旧数据
    conn = get_conn()
    try:
        conn.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES('legacy_migrated','1')")
        conn.commit()
    finally:
        conn.close()
    return imported
