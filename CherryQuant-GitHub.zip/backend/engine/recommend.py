# -*- coding: utf-8 -*-
"""
CherryQuant Web — 推荐组合引擎
基于历史回测验证的策略："验证有效 + 评分高"的 Top N 轮动。

【当前配置】(V9)
  TOP_N = 5  —— 变体扫描实测最优（Top5+温度+40天调仓，见 variant_scan.py）
  选股: 验证有效优先，再按评分排序
  资金分配: 评分加权（权重=(score-40)^1.5），单只上限40%防过度集中
  仓位: 市场温度择时（>60满仓 / 40-60半仓 / <40空仓），调仓建议每40个交易日

【回测绩效】(2026-09-02 变体A/B扫描最优档实测；验证Top5+温度+每40交易日，含成本)
  6.2年(2020-06起): +66.5% 年化8.6% 夏普0.68 回撤-25.3%
  近5.7年(2021起):  -10.5% 年化-1.9% 夏普-0.03 回撤-41.1%（震荡熊市段，全场最优之一）
  近3.7年(2023起):  +72.1% 年化16.0% 夏普0.97 回撤-23.9%
  结论: 温度择时开/关是该档收益的最大分水岭；同档关闭后全窗口收益普遍腰斩甚至转负。
  ⚠️ 与 disclaimer/backtest_summary 同源于 BT_SNAPSHOT 常量（改一处即可）；
  数据上限 6.2 年（腾讯缓存 1500 根），可复现: python backend/variant_scan.py

【历史对比参考】(曾用 Top3/20日，已被 V9 变体扫描取代)
  变体扫描结论: 验证Top5+温度开+调仓40天 稳健分最高，全面优于旧 Top3+20天
  （旧档全窗口 6.2y 仅 +10.7%，新档 +66.5%）。

输出:
  recommended: 当前推荐持有的 Top N 列表（含alloc_pct资金占比）
  in_rec_holdings: 已持有且在推荐TopN（评分高+资金流入会提示加仓）
  keep_extra_holdings: 验证有效但超出TopN（可保留，不强制卖）
  not_rec_holdings: 验证无效/一般（建议卖出腾资金）
  rec_not_hold: 推荐但未持仓（可买入，含资金门槛判断）
  rotate: 调仓建议列表
  temp_timing: 市场温度择时（仓位建议）
  backtest_summary: 多区间回测绩效
  disclaimer: 风险声明
"""
import numpy as np
import pandas as pd

from .data import _csv_path, _read_csv
from .config import POOL, CODE2NAME


def _cached_last_date(code: str) -> str:
    """主行情缓存最后一根的日期（东财优先），用于告诉页面“验证数据截至哪天”。"""
    for src in ("eastmoney", "tencent"):
        try:
            df = _read_csv(_csv_path(src, code))
            if df is not None and len(df):
                return str(df["date"].iloc[-1])[:10]
        except Exception:
            continue
    return ""


def _primary_df(code: str):
    """取主行情缓存（东财优先，腾讯兜底），避免波动率/验证继续读旧缓存。"""
    df = _read_csv(_csv_path("eastmoney", code))
    if df is None or len(df) < 31:
        df = _read_csv(_csv_path("tencent", code))
    return df


def _rolling_valid(code: str, min_sharpe: float = 0.3) -> str:
    """
    滚动点内有效性（替代静态全历史验证表）：
    用该 ETF 自身缓存K线，近250日年化夏普 > min_sharpe 视为 valid。
    数据不足返回 nodata，无正收益/波动为零返回 weak。
    与回测中的 pit_valid 口径一致，消除"用今天算出的全历史标签选历史标的"的幸存者偏差。
    """
    try:
        # 修复：验证应读“主行情缓存”（东财，和页面信号同源），旧实现固定读
        # tencent 兜底缓存 → 主行情更新到 11-06 时，验证仍用 09-21 的旧数据。
        df = _read_csv(_csv_path("eastmoney", code))
        if df is None or len(df) < 70:
            df = _read_csv(_csv_path("tencent", code))   # 东财缺数据时才用腾讯兜底
        if df is None or len(df) < 70:
            return "nodata"
        closes = pd.Series(df["close"].values, index=pd.to_datetime(df["date"]))
        rets = closes.pct_change().dropna().tail(250)
        if len(rets) < 60:
            return "nodata"
        sd = rets.std()
        if not sd or sd <= 0:
            return "weak"
        return "valid" if (rets.mean() / sd) * np.sqrt(252) > min_sharpe else "weak"
    except Exception:
        return "nodata"


VALID_LABEL = {"valid": "滚动有效", "weak": "滚动一般", "invalid": "滚动无效", "nodata": "数据不足"}


# 历史绩效快照（诚实口径）
# 2026-11-08 修复回测资金守恒（卖出回笼累加/买入手数预留佣金/长历史预算按实际现金）后
# 用 long_history_backtest.py 重跑（em_long 数据上限 2026-10-09）：
#   评分(无资金流) + Top5 + 20日调仓 + 点内有效 + 温度择时 + 止损-10%/-8% + 止盈+15%
#   + T+1开盘成交 + 万3佣+千1滑。
# 可复现: python backend/long_history_backtest.py
BT_SNAPSHOT = {
    # 2020-06 起，6.2 年（含温度择时）
    "total_return": 10.9, "annual_return": 1.6, "sharpe": 0.19, "max_drawdown": -33.2,
    # 近3.7年(2023起)
    "near3y": {"total": 49.3, "annual": 11.2, "sharpe": 0.84, "mdd": -20.2},
    # 近5.7年(2021起，含2021-2022震荡熊市段)
    "near5y": {"total": 25.8, "annual": 4.1, "sharpe": 0.39, "mdd": -28.2},
    # 静态对照（旧口径，2026-09 快照：全历史标签+同日收盘+无成本，偏高；
    # 仅用于展示“旧口径 vs 诚实口径”的偏差量级，勿当作预期收益）
    "static_6y": {"total": 43.4, "sharpe": 0.45, "mdd": -33.9},
    "static_3y": {"total": 83.0, "sharpe": 1.05, "mdd": -16.9},
}


def pnl_str(pnl):
    """盈亏百分比 → 字符串，None→'?'"""
    if pnl is None:
        return "?"
    return f"{pnl:+.1f}%"


# 最优参数（回测网格搜索 + 2026-09-02 变体A/B扫描实测）
# 实测(含成本/点内验证/温度择时)：Top5+温度开+调仓40天 稳健分最高
#   (全窗口6.2y 夏普0.68/回撤-25.3；近3.7y 夏普0.97/回撤-23.9)，
#   全面优于旧 Top3+20天。可复现: python backend/variant_scan.py
TOP_N = 5          # 用户偏好：最多持有5只（变体扫描实测最优）
MIN_VALID = 3      # 验证有效少于3只时退化为纯评分


def _rank_signals(scan: dict) -> list:
    """
    对全池信号排序：验证有效优先，再按评分。
    返回 [{code, name, score, signal, verify, price, main_net_5d, rank}]

    修复（GPT 复核 H）：verify 统一改用 optimize_report_new.json 的点内验证口径
    （verify.load_verify_map），与 /api/signals/advice 完全一致；_rolling_valid
    只作为“近期行情强弱”观察字段（rolling_valid/rolling_label）保留，不决定买入。
    旧实现用滚动夏普自行判定 valid，导致 recommended 页与 advice 页买卖建议不一致。
    """
    from .verify import load_verify_map
    vmap = load_verify_map()
    # verdict → 排序加权（仅影响排序，不代表最终买卖权限）
    verify_bonus_map = {"valid": 1.0, "weak": 0.3, "insufficient": 0.3,
                        "stale": 0.2, "invalid": 0.0, "nodata": 0.2}
    ranked = []
    for s in scan["signals"]:
        code = s["code"]
        vinfo = vmap.get(code) or {}
        v = vinfo.get("verdict") or "nodata"
        label = vinfo.get("label") or VALID_LABEL.get(v, "?")
        rolling = _rolling_valid(code)   # 附注：近期行情强弱（不决定买入）
        # 综合排序分：验证有效加权 + 评分
        bonus = verify_bonus_map.get(v, 0.2)
        sort_score = s["score"] + bonus * 20  # 验证有效最高加20
        # 资金流滞后降权：数据过期 → 扣分，避免用旧数据选入Top3
        fflow_fresh = s.get("fflow_fresh", True)
        if fflow_fresh is False:
            sort_score -= 8  # 资金流滞后，扣8分降权
        ranked.append({
            "code": code,
            "name": s["name"],
            "score": s["score"],
            "sort_score": sort_score,
            "signal": s["signal"],
            "verify": v,
            "verify_label": label,
            "test_sharpe": vinfo.get("test_sharpe"),
            "rolling_valid": rolling,
            "rolling_label": VALID_LABEL.get(rolling, "?"),
            "price": s.get("price"),
            "main_net_5d": s.get("main_net_5d", 0),
            "trend_quality": s.get("trend_quality"),
            "fflow_fresh": s.get("fflow_fresh", True),
            "verify_asof": _cached_last_date(code),
        })
    ranked.sort(key=lambda x: -x["sort_score"])
    for i, r in enumerate(ranked):
        r["rank"] = i + 1
    return ranked


def recommended_portfolio(scan: dict = None) -> dict:
    """
    生成推荐组合。
    scan: scan_all_signals() 结果，可复用。
    """
    from .signals import scan_all_signals
    scan = scan or scan_all_signals()

    ranked = _rank_signals(scan)

    # 统一决策出口（H）：推荐页的“买入/加仓”必须与 /api/signals/advice 同一集合。
    # 直接复用 signals.build_advice（内部走 decision.decide_buy/decide_holding），
    # 不再用本模块独立标准判断，避免同一时刻两个页面给出相反结论。
    from .signals import build_advice
    advice = build_advice(scan)
    advice_buy = {x["code"]: x for x in (advice.get("buy") or [])}
    advice_add = {x["code"]: x for x in (advice.get("add") or [])}

    # 选 Top N：优先验证有效，不足则补充评分高但验证一般的
    valid_list = [r for r in ranked if r["verify"] == "valid"]
    others = [r for r in ranked if r["verify"] != "valid"]

    if len(valid_list) >= MIN_VALID:
        recommended = valid_list[:TOP_N]
        # 若有效不足 TOP_N，用高评分补充
        if len(recommended) < TOP_N:
            recommended += [r for r in others if r["signal"] == "BUY"][:TOP_N - len(recommended)]
    else:
        # 验证有效太少，退化为纯评分 Top N
        recommended = ranked[:TOP_N]

    # 当前持仓对比
    holdings = {h["code"]: h for h in scan["holdings"]}
    rec_codes = {r["code"] for r in recommended}

    # ===== 统一风控入口（修复）：温度/纪律/止损状态统一约束买入与加仓建议 =====
    _mt = scan.get("market", {}) or {}
    _avg = _mt.get("avg_score") or 0
    _temp = float(_mt.get("temp", 50) or 50)
    _temp_source = float(_avg) if _avg else _temp
    _disc = scan.get("discipline", {}) or {}
    buy_allowed = bool(_disc.get("allowed", True)) and _temp_source >= 40
    _holding_status = {h["code"]: h.get("status", "正常") for h in scan.get("holdings", [])}

    in_rec = []      # 持仓且被推荐
    not_rec = []     # 持仓、不在推荐、验证无效（应卖/减）
    keep_extra = []  # 持仓、不在推荐、验证有效（可保留，超出Top3）
    rec_not_hold = []  # 推荐但未持仓（可买入）

    # ===== 评分加权份额分配（V7：资金集中到最强标的）=====
    # 回测验证：评分加权Top3(2021起+85.8%) > 等权Top3(+82.3%)，回撤更小
    # 用 (score-40)^1.5 做权重，分数越高资金占比越大
    # 但设单只上限 40%，防止过度集中（你有色48%暴露过度的教训）
    MAX_ALLOC = 40.0
    scores_arr = np.array([max(r["score"] - 40, 1) for r in recommended])
    weight_arr = scores_arr ** 1.5
    if weight_arr.sum() > 0:
        weight_arr = weight_arr / weight_arr.sum() * 100
    else:
        weight_arr = np.ones(len(recommended)) / len(recommended) * 100

    # ===== 风险平价融合（V15：降低组合风险）=====
    # 风险平价：波动大的少配、波动小的多配，让各标的风险贡献均衡
    # 实测：当前Top3(医疗/通信/黄金) 组合波动从26.1%→23.5%，风险降9.9%
    # 方案：评分加权(选强者) × 风险平价(控风险) 各50%
    try:
        from .data import _read_csv, _csv_path
        import numpy as _np
        vols = []
        for r in recommended:
            df = _primary_df(r["code"])   # 修复：与信号同源，不再读过期腾讯缓存
            if df is not None and len(df) > 30:
                v = df["close"].pct_change().dropna().std() * _np.sqrt(252)
                vols.append(max(v, 1e-6))  # 防除零
            else:
                vols.append(0.3)
        vols = _np.array(vols)
        rp_weights = (1 / vols) / (1 / vols).sum() * 100
        # 融合：评分加权0.5 + 风险平价0.5
        weight_arr = weight_arr * 0.5 + rp_weights * 0.5
    except Exception:
        pass  # 风险平价失败则退回纯评分加权

    # 超过上限的截断，把超额重新分配给其他标的
    # 修复：单次重新分配可能把其他标的推过 MAX_ALLOC（合成场景 40/41/9/7/3），
    # 改为迭代限权：每次只给未超限的标的分配，直到没有标的超限或全部到顶。
    for _ in range(20):
        over = weight_arr > MAX_ALLOC + 1e-9
        if not over.any():
            break
        surplus = (weight_arr[over] - MAX_ALLOC).sum()
        weight_arr[over] = MAX_ALLOC
        under = weight_arr < MAX_ALLOC - 1e-9
        if not under.any():
            break
        weight_arr[under] += surplus / under.sum()
    for i, r in enumerate(recommended):
        r["alloc_pct"] = round(float(weight_arr[i]), 1)  # 建议资金占比

    for r in recommended:
        if r["code"] in holdings:
            h = holdings[r["code"]]
            in_rec.append({**r, "holding": True,
                           "pnl_pct": h.get("pnl_pct"),
                           "shares": h.get("shares"),
                           "current_price": h.get("current_price"),
                           "main_net_5d": r.get("main_net_5d", 0)})
        else:
            rec_not_hold.append({**r, "holding": False})

    for code, h in holdings.items():
        if code not in rec_codes:
            s = next((x for x in ranked if x["code"] == code), {})
            item = {
                "code": code, "name": h.get("name", CODE2NAME.get(code, code)),
                "verify": s.get("verify", "?"), "verify_label": s.get("verify_label", "?"),
                "score": s.get("score"), "signal": s.get("signal"),
                "pnl_pct": h.get("pnl_pct"), "shares": h.get("shares"),
                "current_price": h.get("current_price"),
            }
            if s.get("verify") == "valid":
                keep_extra.append(item)  # 验证有效，可保留
            else:
                not_rec.append(item)     # 验证无效/一般，建议腾资金

    # 调仓建议
    rotate = []
    # 择时适用度：躺平标的减少卖出建议（避免过度交易）
    from .timing_fit import get_timing_fit
    for x in not_rec:
        code = x["code"]
        fit = get_timing_fit(code)
        # 持有但不在推荐组合且验证无效 → 建议卖出
        action = "卖出"
        if fit.get("verdict") == "躺平":
            # 躺平标的：即使不在推荐，也提示"可长期持有"而非强卖
            action = "保留"
            x["timing_verdict"] = "躺平"
            rotate.append({**x, "action": action,
                           "reason": f"该标的历史躺平更优(超额{fit.get('alpha',0):+.1f}%)，可长期持有而非频繁交易"})
        else:
            rotate.append({**x, "action": action,
                           "reason": f"验证{x.get('verify_label','?')}且不在推荐名单，建议{action}腾资金"})
    for x in keep_extra:
        rotate.append({**x, "action": "保留",
                       "reason": f"验证有效但超出推荐集中度，盈利{pnl_str(x.get('pnl_pct'))}可保留或逐步止盈"})
    for x in rec_not_hold:
        if not buy_allowed:
            rotate.append({**x, "action": "观望",
                           "reason": f"市场温度/交易纪律暂停买入（温度{_temp_source:.0f}），"
                                     f"推荐组合标的，等条件恢复再分批买入"})
        elif x["code"] in advice_buy:
            rotate.append({**x, "action": "买入",
                           "reason": f"与统一买卖建议一致（点内验证{x.get('verify_label', '?')}，"
                                     f"评分{x['score']:.0f}），可分批买入"})
        else:
            # 推荐名单只是观察池；不满足统一买入条件（验证/资金流/ML）时不得给出买入
            rotate.append({**x, "action": "观望",
                           "reason": "已进入推荐观察名单，但未满足统一买入条件"
                                     "（验证有效+信号BUY+资金流入），等条件齐备再买"})
    # 已持有且进入推荐Top3 → 加仓同样以 /api/signals/advice 的 add 集合为准
    # 修复：旧实现只看评分+资金流，不看止损状态和温度纪律 → 会出现
    # “已触发止损/空仓纪律下仍建议加仓”的自相矛盾。
    for x in in_rec:
        status = _holding_status.get(x["code"], "正常")
        if status in ("止损触发", "止盈触发"):
            rotate.append({**x, "action": ("卖出" if status == "止损触发" else "止盈"),
                           "reason": f"纪律：{status}，禁止加仓，执行卖出/止盈"})
        elif not buy_allowed:
            rotate.append({**x, "action": "持有",
                           "reason": f"市场温度/交易纪律暂停加仓（温度{_temp_source:.0f}），保持持有"})
        elif x["code"] in advice_add:
            rotate.append({**x, "action": "加仓",
                           "reason": f"与统一买卖建议一致：已持有且在推荐名单，"
                                     f"评分{x.get('score', 0):.0f}+资金流入{x.get('main_net_5d', 0):.0f}万，可加仓"})

    # 份额参考（小资金：每只按可分配资金估算1手）
    # 缺行情持仓 market_value=None（第 21 项）：不能参与 sum，否则整页 500
    _priced_mv = [h.get("market_value") for h in scan["holdings"]
                  if h.get("market_value") is not None]
    small_capital = sum(_priced_mv) < 5000
    # 小资金时，1手超过总资金8%的视为"资金门槛高"，不宜新买入（但可保留在推荐列表观察）
    total_cap = sum(_priced_mv) or 1500
    for x in rec_not_hold:
        if x.get("price"):
            x["lot_cost"] = round(x["price"] * 100, 0)  # 1手成本
            if small_capital and x["lot_cost"] > total_cap * 0.08:
                x["too_expensive"] = True
                x["note"] = f"1手{x['lot_cost']:.0f}元，占资金{total_cap:.0f}元比例高，建议资金到位后再买"
            else:
                x["too_expensive"] = False
                x["note"] = f"1手{x['lot_cost']:.0f}元，可分批买入"

    # 历史回测绩效（2026-09-02 变体扫描最优档实测：验证Top5+温度择时+每40交易日调仓；
    # 含成本、点内验证、无未来函数。数据上限 6.2 年(2020-06 起)。可复现 variant_scan.py）
    n3, n5 = BT_SNAPSHOT["near3y"], BT_SNAPSHOT["near5y"]
    s6, s3 = BT_SNAPSHOT["static_6y"], BT_SNAPSHOT["static_3y"]
    # 修复：说明文字与数字必须来自同一份快照（旧实现把 20 日调仓的 BT_SNAPSHOT
    # 数字和 40 日变体说明混在同一响应里：43.5% vs 66.5%、26.6% vs -10.5%）
    _n3, _n5 = BT_SNAPSHOT["near3y"], BT_SNAPSHOT["near5y"]
    backtest_summary = {
        "period": "2020-06 ~ 2026-10（6.2年，em_long 本地数据上限）",
        "method": "验证Top5(点内验证) + 评分加权 + 市场温度择时，每20个交易日调仓（BT_SNAPSHOT 口径）",
        "source": "2026-11-08 修复资金守恒后重跑 long_history_backtest.py（含佣金万3+滑点千1；T+1开盘成交）",
        "total_return": BT_SNAPSHOT["total_return"],
        "annual_return": BT_SNAPSHOT["annual_return"],
        "sharpe": BT_SNAPSHOT["sharpe"],
        "max_drawdown": BT_SNAPSHOT["max_drawdown"],
        "vs_pool": ("同口径全池等权(含成本) 6.2年 +8.1%；本窗口含温度择时 +10.9%、"
                    "无温度 +17.5% —— 温度择时并非在所有区间都占优，需按区间看"),
        "multi_period": [
            {"period": "近3.7年(2023起)", "total": _n3["total"], "annual": _n3["annual"], "sharpe": _n3["sharpe"], "mdd": _n3["mdd"]},
            {"period": "近5.7年(2021起)", "total": _n5["total"], "annual": _n5["annual"], "sharpe": _n5["sharpe"], "mdd": _n5["mdd"]},
            {"period": "6.2年(2020-06起)", "total": BT_SNAPSHOT["total_return"], "annual": BT_SNAPSHOT["annual_return"],
             "sharpe": BT_SNAPSHOT["sharpe"], "mdd": BT_SNAPSHOT["max_drawdown"]},
        ],
        # 静态对照（全历史标签选标的，有偏；展示偏差量级，勿当预期）
        "static_contrast": [
            {"period": "6.2年", "total": s6["total"], "sharpe": s6["sharpe"], "mdd": s6["mdd"]},
            {"period": "近3.7年", "total": s3["total"], "sharpe": s3["sharpe"], "mdd": s3["mdd"]},
        ],
        "note_key": ("6.2年 %+.1f%%（年化%.1f%%/夏普%.2f/回撤%.1f%%）；近3.7年 %+.1f%%（夏普%.2f/回撤%.1f%%）"
                     % (BT_SNAPSHOT["total_return"], BT_SNAPSHOT["annual_return"],
                        BT_SNAPSHOT["sharpe"], BT_SNAPSHOT["max_drawdown"],
                        _n3["total"], _n3["sharpe"], _n3["mdd"])),
        "note_honest": ("近5.7年（2021起，含2021-2022震荡段）%+.1f%%，回撤%.1f%%；"
                        "关闭温度择时后全窗口收益会明显变差。收益强依赖市场环境，趋势跟随策略不是稳赚，"
                        "历史表现不代表未来。" % (_n5["total"], _n5["mdd"])),
    }

    # ===== 市场温度择时（V5 新增）：熊市降仓/空仓 =====
    # 用全池平均分近似市场温度：>60满仓 / 40-60半仓 / <40空仓
    # 回测验证：2023起满仓-30.5% vs 温度择时+67.3%，回撤-74%→-15%
    market_temp = scan["market"]["temp"]
    avg_score = scan["market"].get("avg_score", market_temp)
    temp_source = avg_score if avg_score else market_temp
    if temp_source > 60:
        position_ratio, temp_action = 1.0, "满仓"
        temp_note = f"市场温度{temp_source:.0f}（偏多），建议满仓操作"
    elif temp_source >= 40:
        position_ratio, temp_action = 0.5, "半仓"
        temp_note = f"市场温度{temp_source:.0f}（中性），建议半仓控制风险"
    else:
        position_ratio, temp_action = 0.0, "空仓"
        temp_note = f"市场温度{temp_source:.0f}（偏空），建议空仓观望或仅保留极小仓位"
    temp_timing = {
        "market_temp": round(temp_source, 1),
        "position_ratio": position_ratio,
        "action": temp_action,
        "note": temp_note,
    }

    # 一句话总结
    rec_names = "、".join(r["name"] for r in recommended[:3])
    parts = [f"推荐集中持有 {len(recommended)} 只：{rec_names}"]
    parts.append(f"仓位：{temp_action}(温度{temp_source:.0f})")
    if not_rec:
        parts.append(f"建议卖出 {len(not_rec)} 只：{', '.join(x['name'] for x in not_rec[:3])}")
    if keep_extra:
        parts.append(f"可保留 {len(keep_extra)} 只：{', '.join(x['name'] for x in keep_extra[:2])}(验证有效)")
    if rec_not_hold and position_ratio > 0:
        parts.append(f"可买入 {len(rec_not_hold)} 只：{', '.join(x['name'] for x in rec_not_hold[:2])}")
    parts.append(f"市场温度 {market_temp}")

    return {
        "generated_at": scan["generated_at"],
        "data_asof": ((scan.get("signals") or [{}])[0].get("date") or ""),
        "verify_asof": next((r.get("verify_asof") for r in ranked if r.get("verify_asof")), ""),
        # 修复（GPT 复核 H）：两套验证口径统一命名/权限，页面不再各说各话
        "action_authority": "最终买卖建议以 /api/signals/advice 为准",
        "verify_source": "optimize_report_new.json（点内验证，统一口径）",
        "verify_metrics_note": ("策略样本外表现=optimize_report_new.json 点内验证（决定是否允许买入）；"
                                "rolling_valid=近250日滚动夏普（仅作“近期行情强弱”观察，不决定买入）"),
        "advice_buy_codes": sorted(advice_buy),
        "advice_add_codes": sorted(advice_add),
        "recommended": recommended,
        "in_rec_holdings": in_rec,
        "not_rec_holdings": not_rec,
        "keep_extra_holdings": keep_extra,
        "rec_not_hold": rec_not_hold,
        "rotate": rotate,
        "backtest_summary": backtest_summary,
        "temp_timing": temp_timing,
        "summary": "；".join(parts),
        "small_capital_mode": small_capital,
        "disclaimer": (
            "推荐组合基于 BT_SNAPSHOT 口径（验证Top5+市场温度择时+每20交易日调仓），"
            f"含佣金滑点后近3.7年{BT_SNAPSHOT['near3y']['total']:+.1f}%、"
            f"年化{BT_SNAPSHOT['near3y']['annual']:.1f}%、夏普{BT_SNAPSHOT['near3y']['sharpe']:.2f}、"
            f"回撤{BT_SNAPSHOT['near3y']['mdd']:.1f}%；"
            f"近5.7年{BT_SNAPSHOT['near5y']['total']:+.1f}%（含2021-2022震荡段），"
            "收益强依赖市场环境，历史不代表未来。"
        ),
    }
