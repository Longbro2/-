# -*- coding: utf-8 -*-
"""
CherryQuant Web — 信号引擎
从旧版 signals.py V5.1 迁移并修复：
  1. 指标用 shift(1) 消除未来函数（保持原样）
  2. _score() 统一评分（修复 MOM5_WEIGHT 死代码 → 改为真实引用）
  3. 止损/止盈动态跟踪（修复 peaks 换仓误触发：买入重置峰值）
  4. 纪律锁：卖出不受限，买入按自然周限次
  5. 新增市场温度（大盘择时）
"""
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

from .config import RISK, POOL, CODE2NAME, SCORE_LT_TERM
from .risk_rules import evaluate_risk
from . import db
from .data import fetch
from .verify import annotate_signals, annotate_holdings

# 评分权重（IC分析：动量5日是噪音，大幅降权 200→30）
MOM5_WEIGHT = 30


# ============ 指标（真·无未来函数） ============

def calc_indicators(df: pd.DataFrame, lag: bool = True) -> pd.DataFrame:
    """
    计算全部指标（基于当日收盘）。
    lag=True: 整体 shift(1)，供实盘 gen_signal 使用（第T日只用T-1日数据，无未来函数）
    lag=False: 原始指标，供回测引擎逐日生成信号（由 Backtest 内部负责滞后）
    """
    df = df.copy()
    c = df["close"]
    df["ma5"] = c.rolling(5).mean()
    df["ma20"] = c.rolling(20).mean()
    df["ma50"] = c.rolling(50).mean()
    delta = c.diff()
    gain = delta.where(delta > 0, 0).rolling(14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(14).mean()
    df["rsi"] = 100 - 100 / (1 + gain / loss)
    ema12 = c.ewm(span=12).mean()
    ema26 = c.ewm(span=26).mean()
    df["macd"] = ema12 - ema26
    df["macd_signal"] = df["macd"].ewm(span=9).mean()
    df["mom_5d"] = (c.pct_change() + 1).rolling(5).apply(np.prod, raw=True) - 1

    # ===== 形态识别（纯向量化，与原循环逻辑完全一致） =====
    c_arr = c.values
    n = len(df)

    # 1. W底: 近40天两个低点相近(<3%), 价格已突破中间反弹高点
    # 原逻辑窗口: seg=c[i-40:i+1], l1=seg[:20].min=c[i-40:i-20].min, l2=seg[20:].min=c[i-20:i+1].min, peak=seg.max
    # 用 numpy 数组切片实现（纯向量化的 rolling 对齐与切片含头不含尾语义有细微差异，易引入bug，故保留循环+切片）
    df["pat_w"] = False
    if n > 60:
        pat_w = np.zeros(n, dtype=bool)
        for i in range(60, n):
            seg = c_arr[i - 40:i + 1]
            l1 = seg[:20].min()
            l2 = seg[20:].min()
            peak = seg.max()
            if abs(l1 / l2 - 1) < 0.03 and c_arr[i] > peak * 0.95:
                pat_w[i] = True
        df["pat_w"] = pat_w

    # 2. 底背离: 近20天价格创新低但 RSI 未创新低
    # 原逻辑: c[i-20:i+1] 最低在最后一位(今天创20日新低)，且今天 RSI > 最低点之前的 RSI 最低
    df["pat_div"] = False
    if n > 40:
        rsi_arr = df["rsi"].values
        # 今天创 20 日新低: c[i] <= c[i-19:i+1].min 且 c[i] < c[i-20:i].min
        c_roll_min = c.rolling(20).min()             # c[i-19:i+1].min
        min_prev = c.rolling(20).min().shift(1)      # c[i-20:i].min
        new_low = (c_arr <= c_roll_min.values) & (c_arr < min_prev.values)
        # 今天 RSI > 前 20 天 RSI 最低（不含今天）
        rsi_prev_min = df["rsi"].rolling(20).min().shift(1)  # rsi[i-20:i].min
        rsi_higher = rsi_arr > rsi_prev_min.values
        valid = ~np.isnan(min_prev.values) & ~np.isnan(rsi_prev_min.values)
        pat_div = np.zeros(n, dtype=bool)
        pat_div[40:] = (new_low[40:] & rsi_higher[40:] & valid[40:])
        df["pat_div"] = pat_div

    # 3. 突破: 近15日振幅<8%, 今天收盘突破15日最高
    # 原逻辑: c[i-15:i] 的振幅<8%（不含今天），且 c[i] > h15
    df["pat_brk"] = False
    if n > 30:
        h15 = c.rolling(15).max().shift(1)           # 前15天最高（不含今天）
        l15 = c.rolling(15).min().shift(1)           # 前15天最低（不含今天）
        h15v, l15v = h15.values, l15.values
        valid = ~np.isnan(h15v) & ~np.isnan(l15v)
        cond_amp = (h15v / l15v - 1) < 0.08
        cond_brk = c_arr > h15v
        pat_brk = np.zeros(n, dtype=bool)
        pat_brk[30:] = (cond_amp[30:] & cond_brk[30:] & valid[30:])
        df["pat_brk"] = pat_brk

    # 4. 金叉质量: 零轴下方金叉=左侧(1), 零轴上方=右侧(2)
    df["macd_quality"] = 0
    if n > 2:
        macd_v = df["macd"].values
        sig_v = df["macd_signal"].values
        cross_up = (macd_v[1:] > sig_v[1:]) & (macd_v[:-1] <= sig_v[:-1])
        idx = np.where(cross_up)[0] + 1
        for i in idx:
            df.loc[df.index[i], "macd_quality"] = 1 if macd_v[i] < 0 else 2

    # 整体后移1天 → 消除未来函数（仅 lag 模式）
    if lag:
        for col in ["ma5", "ma20", "ma50", "rsi", "macd", "macd_signal",
                    "mom_5d", "pat_w", "pat_div", "pat_brk", "macd_quality"]:
            df[col] = df[col].shift(1)
    return df


# ============ 评分引擎（唯一真实来源） ============
# 权重基于 IC/IR 因子分析：
#   技术因子: 均线多头(IC0.036/IR0.58), W底(IC0.055/IR0.49), RSI(IC0.033/IR0.49), MACD多头(IC0.036/IR0.47)
#   资金流因子: 5日主力净流入(IC0.160/IR1.01) ← 最强，但上限降到±15防绑架
#   噪音: 动量5日(IC-0.002), 底背离(IC-0.001) → 已降权/删除
# 哨兵值: 区分"未传资金流"和"传了None(数据缺失)"
_MISSING = object()


def _score(macd_bull: bool, macd_cross: bool, ma_bull: bool, rsi: float, mom5: float,
           pat_w=False, pat_div=False, pat_brk=False, macd_qual=0,
           fflow5=_MISSING, fflow5_pct=_MISSING, sector_momentum=_MISSING,
           trend_quality=_MISSING, lt_r250=_MISSING) -> float:
    """多因子+形态+资金流+板块轮动综合评分。信号生成与回测优化共用。"""
    s = 50.0
    # MACD 方向
    s += 15 if macd_bull else -15
    s += 5 if macd_cross else 0
    # 均线多头（最有效技术因子）
    s += 15 if ma_bull else -15
    # RSI 中性区间加分
    s += 10 if 40 < rsi < 80 else 0
    # 超买保护：RSI>75 扣分，防止评分被资金流/形态顶到满分后仍追高
    if rsi >= 75:
        s -= 6
    # 动量（噪音，微调）
    s += mom5 * MOM5_WEIGHT
    # W底
    s += 15 if pat_w else 0
    # 突破（弱）
    s += 5 if pat_brk else 0
    # 金叉质量
    s += 8 if macd_qual == 2 else 0
    s -= 3 if macd_qual == 1 else 0
    # ===== 资金流因子（最强，IC0.160/IR1.01）=====
    # 注意: 上限已从 ±25 降到 ±15，防止单日异常资金流绑架评分
    if fflow5 is not _MISSING and fflow5 is not None and pd.notna(fflow5):
        # 主力净流入为正 → 加分，为负 → 减分（最高±10）
        s += max(-10, min(10, fflow5 / 300.0))
        # fflow5_pct: 5日主力净流入占比（%），最高±5
        if fflow5_pct is not _MISSING and fflow5_pct is not None and pd.notna(fflow5_pct):
            s += max(-5, min(5, fflow5_pct * 0.4))
    elif fflow5 is None or (fflow5 is not _MISSING and pd.isna(fflow5)):
        # 资金流数据缺失 = 信息劣势，扣分
        s -= 5
    # ===== 板块轮动因子（顺势而为）=====
    # 强势板块加分、弱势板块减分，上限±8
    if sector_momentum is not _MISSING and sector_momentum is not None and pd.notna(sector_momentum):
        s += max(-8, min(8, float(sector_momentum) / 3.0))
    # ===== 趋势质量因子（追强势板块但不追高）=====
    # "强趋势/回调企稳"的板块是趋势跟随的最佳买点 → 加分（上限+5）
    # "超跌反弹"短期有动力但中期趋势未明 → 小加分
    # "下跌趋势" → 明确减分（上限-5）
    if trend_quality is not _MISSING and trend_quality is not None:
        tq_bonus = {
            "强趋势": 5.0,    # 中期强+短期未破 → 顺势做多
            "回调企稳": 4.0,  # 中期强+回调后企稳 → 最佳买点
            "超跌反弹": 1.0,  # 短期反弹，中期待确认
            "震荡": 0.0,
            "下跌趋势": -5.0,  # 中期走弱 → 回避
        }.get(trend_quality, 0.0)
        s += tq_bonus
    # ===== 长期趋势项（可选，SCORE_LT_TERM 默认关）=====
    # 250日动量修正"60日视野"缺陷：长期牛市回调不应被当弱势票、长期熊市反弹不应被追高。
    # A/B 实测：全起点年化中位 +4.3%→+5.9%（温和改善，回撤略升）。
    if lt_r250 is not _MISSING and lt_r250 is not None and pd.notna(lt_r250):
        if lt_r250 > 30:
            s += 4.0
        elif lt_r250 > 10:
            s += 2.0
        elif lt_r250 < -20:
            s -= 4.0
    return float(max(0, min(100, s)))


# ============ 信号生成 ============

def _lt_r250(df: pd.DataFrame, enabled: bool):
    """250日动量（未平移收盘价，与 c_60 趋势保护同口径）；未开启时返回 None。"""
    if not enabled:
        return None
    try:
        if len(df) > 251 and df["close"].iloc[-251] > 0:
            return (df["close"].iloc[-1] / df["close"].iloc[-251] - 1) * 100
    except Exception:
        pass
    return None


def gen_signal(name: str, info: dict, df: pd.DataFrame, sector_mom_map: dict = None) -> dict | None:
    """基于 T-1 日指标生成信号，在 T 日开盘执行。
    sector_mom_map: 可选，{code: 板块动量}，避免重复计算 sector_rotation"""
    if len(df) < 60:
        return None
    # 修复（数据时点统一）：data.py 已把“盘中未收盘 K 线”剔除，缓存最后一根
    # 就是已收盘的 D 日。信号在 D+1 开盘执行（与回测 ScoreStrategy 的
    # “D 日指标 → D+1 开盘成交”一致），这里不能再额外 shift(1)，
    # 否则技术指标会比实际可用信息多落后一个交易日。
    df = calc_indicators(df, lag=False)
    l = df.iloc[-1]
    prev = df.iloc[-2]

    macd_bull = l["macd"] > l["macd_signal"]
    macd_cross = (prev["macd"] <= prev["macd_signal"]) and macd_bull
    ma_bull = l["ma5"] > l["ma20"] > l["ma50"]
    rsi = l["rsi"]
    mom5 = l["mom_5d"] if pd.notna(l["mom_5d"]) else 0

    # 资金流因子（最强因子，IC0.160/IR1.01）
    fflow5 = None
    fflow5_pct = None
    fflow_info = None
    fflow_fresh = True  # 资金流是否新鲜（滞后>1天则降级标注）
    try:
        from .fflow import fetch_fflow, add_fflow_factors, get_fflow_factor, fflow_freshness
        ff_df = fetch_fflow(info["code"], offline=True)
        if len(ff_df) > 0:
            ff_df = add_fflow_factors(ff_df)
            # 指标不再整体滞后：最后一根 = 已收盘的 D 日；资金流用 D 日（D 收盘后
            # 才可得，用于 D+1 开盘执行）→ 信息时点一致，无未来函数。
            asof_date = df["date"].iloc[-1]
            fflow_info = get_fflow_factor(info["code"], ff_df, asof=asof_date)
            fflow5 = fflow_info["main_net_5d"]   # 万元
            fflow5_pct = fflow_info["main_pct_5d"]
            # 新鲜度检查：资金流滞后>1天 → 降级标注（不静默用旧数据）
            try:
                ffs = fflow_freshness(info["code"])
                fflow_fresh = ffs.get("fresh", True)
            except Exception:
                pass
    except Exception:
        pass

    # 资金流滞后 → 降权处理（stale flow 仅保留约30%信息，避免拿过期数据满血推荐）
    if fflow_fresh is False:
        fflow5 = (fflow5 * 0.3) if fflow5 is not None else 0
        fflow5_pct = (fflow5_pct * 0.3) if fflow5_pct is not None else 0

    # 板块动量因子（顺势而为，强势板块加分）
    sector_momentum = None
    trend_quality = None
    if sector_mom_map is not None:
        sector_momentum = sector_mom_map.get(info["code"], {}).get("momentum") if isinstance(sector_mom_map.get(info["code"]), dict) else sector_mom_map.get(info["code"])
        tq = sector_mom_map.get(info["code"], {})
        if isinstance(tq, dict):
            trend_quality = tq.get("trend_quality")
    else:
        try:
            from .rotation import sector_rotation
            rot = sector_rotation()
            for s in rot.get("sectors", []):
                if s["code"] == info["code"]:
                    sector_momentum = s["momentum"]
                    trend_quality = s.get("trend_quality")
                    break
        except Exception:
            pass

    score = _score(
        macd_bull, macd_cross, ma_bull, rsi, mom5,
        bool(l.get("pat_w")), bool(l.get("pat_div")),
        bool(l.get("pat_brk")), int(l.get("macd_quality", 0)),
        fflow5=fflow5, fflow5_pct=fflow5_pct,
        sector_momentum=sector_momentum,
        trend_quality=trend_quality,
        lt_r250=_lt_r250(df, SCORE_LT_TERM),
    )
    buy_th = info.get("buy_th", 50)
    sell_th = info.get("sell_th", 30)
    sig = "BUY" if score >= buy_th else ("HOLD" if score >= sell_th else "SELL")

    # 趋势保护：大趋势上涨时，不轻易 SELL（避免回调误杀，错过大牛股主升浪）
    # 60日动量 > 8% 视为上升趋势，此时 SELL 阈值放宽 sell_th - 15
    try:
        c_60 = df["close"].iloc[-1] / df["close"].iloc[-61] - 1 if len(df) > 61 else 0
        if c_60 > 0.08 and sig == "SELL" and score >= sell_th - 15:
            sig = "HOLD"  # 上升趋势中的回调，不卖
    except Exception:
        pass

    result = {
        "name": name, "code": info["code"], "signal": sig,
        "score": round(score, 1),
        "price": round(float(df["close"].iloc[-1]), 3),
        "macd_bull": bool(macd_bull), "rsi": round(float(rsi), 1),
        "ma_bull": bool(ma_bull), "mom5": round(float(mom5 * 100), 1),
        "buy_th": buy_th, "sell_th": sell_th,
        "fflow_fresh": fflow_fresh,  # 资金流新鲜度（False=数据滞后）
        "date": df["date"].iloc[-1].strftime("%Y-%m-%d"),
    }
    # 附带资金流信息
    if fflow_info:
        result["main_net"] = fflow_info["main_net"]
        result["main_pct"] = fflow_info["main_pct"]
        result["main_net_5d"] = fflow_info["main_net_5d"]
        result["main_pct_5d"] = fflow_info["main_pct_5d"]
        result["main_streak"] = fflow_info["main_streak"]
    return result


# ============ 纪律锁 ============

def check_disc(action="BUY"):
    """卖出永远允许；买入按自然周(周一00:00起)限次。"""
    if action == "SELL":
        return {"allowed": True, "msg": "卖出不受限"}
    trades = db.load_trades()
    now = datetime.now()
    ws = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    # 日期解析加保护：旧项目迁移来的成交日期不保证 ISO 格式，坏格式按
    # “不在本周”处理，避免 /scan、/advice 整页 500
    buy_cnt = 0
    for t in trades:
        if t["action"] != "BUY":
            continue
        try:
            if t.get("date") and datetime.fromisoformat(t["date"]) >= ws:
                buy_cnt += 1
        except (ValueError, TypeError):
            pass
    limit = RISK["weekly_buy_limit"]
    return {"allowed": buy_cnt < limit, "buy_cnt": buy_cnt,
            "msg": "可买入" if buy_cnt < limit else f"本周已买入{buy_cnt}次, 锁"}


# ============ 止损止盈 ============

def stop_loss_check(code: str, pos: dict, current_price: float) -> dict:
    """
    动态止损 + 移动止盈:
      - 峰值回撤 < -8%  → 止损
      - 相对成本亏损 < -10% → 止损
      - 移动止盈：盈利超 +8% 后，从峰值回撤 -8% → 止盈（让利润奔跑）
      - 趋势自适应（V3）：60日动量强时放宽止盈线(-15%)，让利润奔跑，避免卖飞主升浪
    峰值持久化到 DB (peaks 表)。
    """
    # 行情断档守卫：无价格数据(<=0)时绝不参与风控判定——否则会把亏损算成
    # -100% 而误发“止损清仓”（旧实现 current=0 → drawdown=-100 → stop_triggered=True）。
    # 此时峰值只读不更新，等待数据恢复后再正常判定。
    if current_price is None or current_price <= 0:
        try:
            peaks = db.load_peaks()
            old_peak = peaks.get(code, pos.get("cost_price", 0) or 0)
        except Exception:
            old_peak = pos.get("cost_price", 0) or 0
        cost = pos.get("cost_price", 0) or 0
        return {
            "drawdown": 0.0, "pnl_pct": 0.0, "peak": round(float(old_peak), 3),
            "cost_price": round(float(cost), 3), "current_price": 0.0,
            "stop_triggered": False, "take_profit": False,
            "trailing_take": False, "no_data": True,
        }

    cost_price = pos.get("cost_price", 0)
    if not cost_price or cost_price <= 0:
        cost_price = current_price

    peaks = db.load_peaks()
    old_peak = peaks.get(code, cost_price)
    new_peak = max(old_peak, current_price)
    if new_peak != old_peak:
        db.save_peak(code, new_peak)

    # 60日动量（仅盈利且启用趋势自适应时需要）——与回测 evaluate_risk 同源
    r60 = None
    pnl_quick = (current_price / cost_price - 1) * 100 if cost_price > 0 else 0
    if RISK.get("trend_adaptive", True) and pnl_quick > 0:
        try:
            df = fetch(code, offline=True)
            if len(df) > 61 and df["close"].iloc[-61] > 0:
                r60 = (df["close"].iloc[-1] / df["close"].iloc[-61] - 1) * 100
        except Exception:
            pass

    # 统一风控引擎：固定止损/峰值回撤/固定止盈/移动止盈/趋势自适应全部按同一口径
    return evaluate_risk(cost_price, new_peak, current_price, r60=r60, risk=RISK)


def reset_peak_on_buy(code: str, cost_price: float):
    """买入时重置峰值=cost，避免旧峰值导致新仓误触发止损。"""
    db.save_peak(code, float(cost_price))


def clear_peak_on_sell(code: str):
    """清仓时删除峰值。"""
    db.delete_peak(code)


# ============ 市场温度（大盘择时） ============

def market_temperature(signals: list = None) -> dict:
    """
    用全池 ETF 评分均值近似市场温度。
    简单方案: 所有 BUY 信号占比 * 100，>60 偏多，<40 偏空。
    signals 参数可选：若传入已算好的信号列表（scan_all_signals 中），
    则直接复用，避免把全池 gen_signal 重算一遍（性能优化）。
    """
    if signals is None:
        signals = []
        for name, info in POOL.items():
            df = fetch(info["code"], offline=True)
            if len(df) < 60:
                continue
            s = gen_signal(name, info, df)
            if s:
                signals.append(s)
    if not signals:
        return {"temp": 50, "buy": 0, "hold": 0, "sell": 0, "count": 0, "status": "数据不足"}
    buy = sum(1 for s in signals if s["signal"] == "BUY")
    hold = sum(1 for s in signals if s["signal"] == "HOLD")
    sell = sum(1 for s in signals if s["signal"] == "SELL")
    avg_score = float(np.mean([s["score"] for s in signals]))
    temp = round(buy / len(signals) * 100, 1)
    status = "偏多 🔥" if temp >= 60 else ("偏空 ❄️" if temp <= 40 else "中性 ⚖️")
    return {
        "temp": temp, "buy": buy, "hold": hold, "sell": sell,
        "count": len(signals), "avg_score": round(avg_score, 1),
        "status": status,
    }


# ============ 操作建议引擎 ============

def build_advice(scan: dict) -> dict:
    """
    基于 scan 结果生成可执行的交易建议。
    综合: 评分信号 + 持仓状态 + 止损/止盈 + 纪律锁 + 市场温度
    决策逻辑统一由 decision.py 提供（与 instructions/optimizer 口径一致，
    避免"仪表盘说加仓、信号页说持有"的矛盾）。

    返回:
      buy: 建议买入列表（非持仓、验证有效、信号强）
      sell: 建议卖出列表（持仓中，止损/止盈/结构性/信号SELL）
      add:  建议加仓列表（已持仓、验证有效）
      hold: 建议持有列表（已持仓、状态正常）
      watch: 观望列表（评分中低/验证不足）
      summary: 一句话总结
    """
    from .decision import decide_holding, decide_buy, advice_group
    from .verify import load_verify_map

    signals = scan["signals"]
    holdings = scan["holdings"]
    market = scan["market"]
    disc = scan["discipline"]
    ml_signals = scan.get("ml_signals", {})
    vmap = load_verify_map()

    holding_codes = {h["code"]: h for h in holdings}

    buy, add, sell, hold, watch = [], [], [], [], []

    for s in signals:
        code = s["code"]
        pos = holding_codes.get(code)
        verify = vmap.get(code, {}).get("verdict", "nodata")
        ml = ml_signals.get(code, {})

        if pos:
            # 统一决策：持仓动作（与指令/调仓一致）
            action, reason, _ = decide_holding(s, pos, verify, ml)
            group = advice_group(action)
            item = {**s, "action": action, "reason": reason,
                    "pnl_pct": pos.get("pnl_pct"), "drawdown": pos.get("drawdown")}
            if group == "sell":
                sell.append(item)
            elif group == "add":
                add.append(item)
            elif group == "hold":
                hold.append(item)
            else:  # 警惕 → watch
                watch.append(item)
        else:
            # 统一决策：非持仓动作（与指令/调仓一致）
            action, reason, _ = decide_buy(s, verify, ml)
            group = advice_group(action)
            item = {**s, "action": action, "reason": reason}
            if group == "buy":
                buy.append(item)
            else:  # 观望/回避/关注/等待 → watch
                watch.append(item)

    # 纪律锁检查：本周买入受限
    buy_allowed = disc.get("allowed", True)
    if not buy_allowed and buy:
        for b in buy:
            b["blocked"] = True
            b["reason"] += f"（本周已买入{disc.get('buy_cnt', 0)}次，纪律锁生效）"

    # 市场温度过滤
    temp = market.get("temp", 50)
    market_note = market.get("status", "中性")

    # 排序（用统一决策引擎 ORDER；rank 缺失时排后，兼容合成/外部传入的 scan）
    from .decision import ORDER
    _rk = lambda x: x.get("rank", 999)
    buy.sort(key=lambda x: (ORDER.get(x["action"], 9), _rk(x)))
    add.sort(key=lambda x: (ORDER.get(x["action"], 9), _rk(x)))
    sell.sort(key=lambda x: (ORDER.get(x["action"], 9), -(x.get("drawdown", 0) or 0)))
    hold.sort(key=lambda x: (ORDER.get(x["action"], 9), _rk(x)))
    watch.sort(key=lambda x: (ORDER.get(x["action"], 9), _rk(x)))

    # 总结
    parts = []
    if sell:
        parts.append(f"卖出 {len(sell)} 只：{', '.join(s['name'] for s in sell[:3])}"
                     + ("等" if len(sell) > 3 else ""))
    if buy and buy_allowed:
        parts.append(f"建议买入 {len(buy)} 只：{', '.join(b['name'] for b in buy[:3])}"
                     + ("等" if len(buy) > 3 else ""))
    elif buy and not buy_allowed:
        parts.append(f"{len(buy)} 只满足买入条件但本周纪律锁已生效")
    if add:
        parts.append(f"可加仓 {len(add)} 只：{', '.join(a['name'] for a in add[:3])}"
                     + ("等" if len(add) > 3 else ""))
    if not parts:
        parts.append("持仓稳定，无强制操作信号")
    parts.append(f"市场温度 {temp}℃（{market_note}）")

    return {
        "buy": buy, "add": add, "sell": sell, "hold": hold, "watch": watch,
        "summary": "；".join(parts),
        "market_temp": temp,
        "buy_allowed": buy_allowed,
    }


# ============ 每日信号扫描 ============

# 简单 TTL 缓存：5分钟内重复调用直接返回缓存，避免多页面连续请求时重复计算
# （离线行情一天才更新一次，30秒TTL导致前端轮询频繁触发全池重算，已放宽）
# 修复（GPT 复核 G/#23）：版本检查、缓存读取、写入必须共用同一把锁。
# 旧实现“计算完再比较版本 + 写入”不是原子操作：invalidate 恰好插在比较之后、写入
# 之前时，旧计算结果仍会覆盖已清空的缓存（页面拿到失效建议）。
import threading as _threading

_scan_cache = {"ts": 0, "data": None}
_scan_cache_lock = _threading.Lock()
_SCAN_TTL = 300
_scan_cache_version = 0   # 行情/模型/账户变更时 +1；旧计算完成时版本不一致则丢弃


def _scan_cache_version_start() -> int:
    """扫描开始时取版本（与缓存写入共用同一把锁，保证可见性）。"""
    with _scan_cache_lock:
        return _scan_cache_version


def _scan_cache_lookup(use_cache: bool = True):
    """缓存命中则返回结果，否则返回 None（TTL 判断与读取在同一把锁内）。"""
    if not use_cache:
        return None
    import time as _t
    with _scan_cache_lock:
        data, ts = _scan_cache["data"], _scan_cache["ts"]
        if data is not None and _t.time() - ts < _SCAN_TTL:
            return data
    return None


def _scan_cache_store(result, version: int) -> bool:
    """写入缓存（仅当版本仍等于扫描开始时的版本；检查与写入在同一把锁内）。

    返回是否真的写入：False = 本轮计算期间缓存已被失效，旧结果被拒绝。
    """
    global _scan_cache
    import time as _t
    with _scan_cache_lock:
        if version != _scan_cache_version:
            return False
        _scan_cache = {"ts": _t.time(), "data": result}
        return True


def _clear_scan_cache():
    """清除扫描缓存（行情/模型/账户变更后必须调用）；同时递增版本，
    避免正在计算的旧请求完成后又把旧结果写回缓存。"""
    global _scan_cache, _scan_cache_version
    with _scan_cache_lock:
        _scan_cache_version += 1
        _scan_cache = {"ts": 0, "data": None}


# 对外别名：数据刷新/重训/记账后统一调用
def invalidate_scan_cache():
    _clear_scan_cache()


def scan_all_signals(use_cache: bool = True) -> dict:
    """
    扫描全池，返回:
      signals: 按分数排序的信号列表
      holdings: 持仓 + 风控状态
      market: 市场温度
      discipline: 纪律锁
    """
    # 缓存命中：TTL 内直接返回（读取与 TTL 判断在同一把锁内，G/#23）
    cached = _scan_cache_lookup(use_cache)
    if cached is not None:
        return cached
    _version_at_start = _scan_cache_version_start()

    positions = db.load_positions()
    disc = check_disc("BUY")

    # 板块动量只算一次，供所有 gen_signal 复用（避免重复计算 sector_rotation）
    sector_mom_map = {}
    try:
        from .rotation import sector_rotation
        rot = sector_rotation()
        sector_mom_map = {s["code"]: {"momentum": s["momentum"], "trend_quality": s.get("trend_quality")}
                          for s in rot.get("sectors", [])}
    except Exception:
        pass

    signals = []
    for name, info in POOL.items():
        # 页面加载用离线模式：绝不联网重试，快速返回缓存数据
        df = fetch(info["code"], offline=True)
        if len(df) < 60:
            continue
        s = gen_signal(name, info, df, sector_mom_map=sector_mom_map)
        if s is None:
            continue
        s["holding"] = info["code"] in positions
        signals.append(s)

    signals.sort(key=lambda x: x["score"], reverse=True)
    for i, s in enumerate(signals):
        s["rank"] = i + 1

    # 持仓风控
    holdings_report = []
    for code, pos in positions.items():
        name = pos.get("name", CODE2NAME.get(code, code))
        df = fetch(code, offline=True)
        # 修复（第 21 项）：缺行情 ≠ 价格为 0。保留 None 并标记 no_data，
        # 由上层把总额标为不完整，而不是把资产算成归零 / 亏损 -100%。
        has_quote = len(df) > 0
        current = float(df["close"].iloc[-1]) if has_quote else None
        sl = stop_loss_check(code, pos, current)
        sig = next((x for x in signals if x["code"] == code), None)
        status = "正常"
        if sl.get("no_data"):
            status = "数据缺失"
        elif sl["stop_triggered"]:
            status = "止损触发"
        elif sl["take_profit"]:
            status = "止盈触发"
        elif sig and sig["signal"] == "SELL":
            status = "信号SELL"
        market_value = round(pos["shares"] * current, 2) if has_quote else None
        holdings_report.append({
            "code": code, "name": name,
            "shares": pos["shares"], "cost_price": pos["cost_price"],
            "current_price": current, "market_value": market_value,
            "no_data": (not has_quote),
            "cost": pos["cost"],
            "pnl_pct": (None if not has_quote else sl["pnl_pct"]),
            "drawdown": (None if not has_quote else sl["drawdown"]),
            "peak": sl["peak"],
            "risk_thresholds": sl.get("thresholds"),
            "status": status, "signal": sig["signal"] if sig else "?",
            "score": sig["score"] if sig else None,
            # 附带资金流（供持仓表显示）
            "main_net": sig.get("main_net") if sig else None,
            "main_net_5d": sig.get("main_net_5d") if sig else None,
            "main_pct_5d": sig.get("main_pct_5d") if sig else None,
        })

    scan_result = {
        "signals": annotate_signals(signals),
        "holdings": annotate_holdings(holdings_report),
        # 复用已算好的 signals，避免 market_temperature 重扫全池
        "market": market_temperature(signals),
        "discipline": disc,
        "catalysts": get_upcoming_catalysts(),
        "generated_at": datetime.now().isoformat(timespec="seconds"),
    }
    scan_result["data_asof"] = max((x.get("date", "") for x in signals), default="")
    scan_result["advice"] = build_advice(scan_result)
    # 组合优化（基于验证×评分×资金流）
    try:
        from .portfolio import compute_portfolio_weights
        scan_result["portfolio"] = compute_portfolio_weights(scan_result)
    except Exception:
        scan_result["portfolio"] = None
    # 逐只操作指令
    try:
        from .instructions import generate_instructions
        # 加载 ML 信号做双信号融合（提前加载，供 advice + instructions 共用同一份）
        ml_signals = {}
        try:
            from .ml import load_model, predict_proba_all
            model = load_model()
            if model is not None:
                pred = predict_proba_all(model)
                if len(pred) > 0:
                    for _, r in pred.iterrows():
                        sig = "BUY" if r["proba"] > 0.55 else ("SELL" if r["proba"] < 0.45 else "HOLD")
                        ml_signals[r["code"]] = {"proba": float(r["proba"]), "signal": sig}
        except Exception:
            pass
        scan_result["ml_signals"] = ml_signals
        scan_result["instructions"] = generate_instructions(scan_result, ml_signals)
        # 用同一份 ML 信号重算 advice，确保与 instructions 口径一致
        scan_result["advice"] = build_advice(scan_result)
    except Exception:
        scan_result["instructions"] = []
    # 附加择时适用度（区分该择时 vs 该躺平的标的）
    try:
        from .timing_fit import apply_timing_advice
        scan_result = apply_timing_advice(scan_result)
    except Exception:
        pass
    # 存入缓存（版本校验：行情/模型/账户在本轮计算期间变更过 → 丢弃旧结果，不覆盖新缓存）
    # 检查与写入在同一把锁内完成（G/#23），避免 invalidate 插入两者之间时旧结果覆盖新缓存。
    _scan_cache_store(scan_result, _version_at_start)
    return scan_result


# ============ 催化事件 ============

def get_upcoming_catalysts(days: int = None) -> list:
    """
    返回未来 days 天内的催化事件，含关联 ETF 名称。
    days 默认用 config 的 CATALYST_LEAD_DAYS。
    """
    from .config import CATALYST_CALENDAR, CATALYST_LEAD_DAYS, CODE2NAME
    days = days or CATALYST_LEAD_DAYS
    today = datetime.now().date()
    upcoming = []
    for ev in CATALYST_CALENDAR:
        try:
            ev_date = datetime.strptime(ev["date"], "%Y-%m-%d").date()
        except Exception:
            continue
        days_left = (ev_date - today).days
        if 0 <= days_left <= days:
            # 关联 ETF 名称
            names = []
            for code in ev.get("codes", []):
                n = CODE2NAME.get(code, code)
                names.append({"code": code, "name": n})
            upcoming.append({
                "date": ev["date"],
                "end": ev.get("end", ev["date"]),
                "name": ev["name"],
                "codes": names,
                "days_left": days_left,
            })
    upcoming.sort(key=lambda x: x["days_left"])
    return upcoming
