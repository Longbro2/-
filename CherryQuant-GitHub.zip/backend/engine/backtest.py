# -*- coding: utf-8 -*-
"""
CherryQuant Web — 回测引擎
升级点 vs 旧版 cherryquant.py：
  1. 止损/止盈与实盘一致（峰值回撤 -8% / 亏损 -10% / 盈利 +15%）
  2. 优化器加样本外验证（train/test 切分），防过拟合
  3. 与实盘共用 _score() / calc_indicators()，口径统一
"""
import numpy as np
import pandas as pd

from .config import TRADING, RISK, CODE2NAME, SCORE_LT_TERM
from .signals import _score, calc_indicators, _MISSING
from .risk_rules import evaluate_risk
from .data import fetch


# 评分预热长度：线上评分含 250 日长期因子（lt_r250），回测/样本外测试切片必须
# 提供至少 251 根历史才能与完整历史同分；统一取 260（安全余量）。
# 修复（GPT 复核 C/#12/#16）：旧实现只预热 60 根 → 测试切片长期因子缺失，同一天
# 完整历史 45 分 / 测试切片 41 分，导致"线上该买、样本外显示不买"的假象。
SCORE_WARMUP = 260


# ============ 绩效计算 ============

def compute_performance(equity: np.ndarray, dates: pd.Series, benchmark_close: np.ndarray) -> dict:
    n = len(equity)
    if n < 2:
        return {"total_return": 0, "annual_return": 0, "sharpe_ratio": 0,
                "max_drawdown": 0, "benchmark_return": 0, "trades": 0, "win_rate": 0}

    initial = equity[0]
    total_return = (equity[-1] / initial - 1) * 100 if initial > 0 else 0
    benchmark_return = (benchmark_close[-1] / benchmark_close[0] - 1) * 100 if benchmark_close[0] else 0

    days = (pd.Timestamp(dates.iloc[-1]) - pd.Timestamp(dates.iloc[0])).days
    annual_return = ((equity[-1] / initial) ** (365 / days) - 1) * 100 if days > 0 and initial > 0 else 0

    daily_ret = pd.Series(equity).pct_change().dropna()
    sharpe = (daily_ret.mean() / daily_ret.std()) * np.sqrt(252) if daily_ret.std() > 0 else 0

    peak = np.maximum.accumulate(equity)
    drawdown = (equity - peak) / peak * 100
    max_dd = float(drawdown.min()) if len(drawdown) else 0

    return {
        "total_return": round(float(total_return), 2),
        "annual_return": round(float(annual_return), 2),
        "sharpe_ratio": round(float(sharpe), 2),
        "max_drawdown": round(float(max_dd), 2),
        "benchmark_return": round(float(benchmark_return), 2),
    }


def trade_pair_stats(trades: list) -> tuple:
    """
    用 FIFO（先进先出）配对计算胜率，返回 (胜率%, 已平仓配对笔数)。
    按成交时间顺序，把每笔 SELL 与最早的未平仓 BUY 配对，
    正确处理分批买入后一次性卖出、先卖后买等情况。
    未平仓的持仓不参与配对（它们还没有结果，计入胜率会误导）。
    """
    # 按时间排序
    ordered = sorted(trades, key=lambda t: t.get("date", ""))
    buys_queue = []   # 待配对买入的 [(price, shares)]
    wins = 0
    closed_pairs = 0
    for t in ordered:
        price = t["price"]
        shares = t.get("shares", 0)
        if t["action"] == "BUY":
            buys_queue.append([price, shares])
        elif t["action"] == "SELL":
            remaining = shares
            while remaining > 0 and buys_queue:
                buy_price, buy_shares = buys_queue[0]
                if buy_shares <= remaining:
                    # 整笔买入被卖出
                    closed_pairs += 1
                    if price > buy_price:
                        wins += 1
                    remaining -= buy_shares
                    buys_queue.pop(0)
                else:
                    # 部分卖出：这笔买入还留着
                    closed_pairs += 1
                    if price > buy_price:
                        wins += 1
                    buys_queue[0][1] -= remaining
                    remaining = 0
    if closed_pairs == 0:
        return 0.0, 0
    return round(wins / closed_pairs * 100, 1), closed_pairs


def win_rate_from_trades(trades: list) -> float:
    """兼容旧调用：只返回胜率（无平仓对时为 0.0）。"""
    rate, _ = trade_pair_stats(trades)
    return rate


# ============ 策略类 ============

class Strategy:
    def __init__(self, name="Base"):
        self.name = name

    def generate_signals(self, df):
        raise NotImplementedError


class BuyAndHoldStrategy(Strategy):
    def __init__(self):
        super().__init__("买入持有")

    def generate_signals(self, df):
        d = df.copy()
        d["signal"] = 1
        return d


class ScoreStrategy(Strategy):
    """
    与实盘 gen_signal 完全一致的评分策略。
    指标不 shift，signal[i] 基于第 i 日收盘指标，
    由 Backtest 在 i+1 日开盘执行 → 无未来函数。
    use_fflow=True 时叠加资金流因子（需先拉取资金流缓存）。
    """
    def __init__(self, buy_th: int = 45, sell_th: int = 25, use_fflow: bool = True,
                 use_sector: bool = True, use_lt: bool = None, code: str = None):
        """评分因子配置默认与线上 gen_signal 一致（资金流+板块动量+长期动量），
        避免“线上 44 分 BUY、回测 35 分 HOLD”的口径分裂。"""
        self.use_lt = SCORE_LT_TERM if use_lt is None else bool(use_lt)
        self.use_sector = bool(use_sector)
        name = (f"评分({buy_th}/{sell_th})" + ("+资金流" if use_fflow else "")
                + ("+板块" if self.use_sector else "") + ("+长期" if self.use_lt else ""))
        super().__init__(name)
        self.buy_th = buy_th
        self.sell_th = sell_th
        self.use_fflow = use_fflow
        self.code = code          # 资金流因子按代码加载（与线上一致）

    def generate_signals(self, df):
        d = calc_indicators(df, lag=False)
        n = len(d)

        # 若启用资金流，加载并对齐到日期
        fflow_map = {}
        if self.use_fflow:
            try:
                from .fflow import fetch_fflow, add_fflow_factors
                # 通过 df 的第一列判断 code（回测时传入的 df 无 code，需外部设置）
                code = getattr(self, "code", None)
                if code:
                    ff = fetch_fflow(code, offline=True)
                    if len(ff) > 0:
                        ff = add_fflow_factors(ff)
                        ff["date"] = pd.to_datetime(ff["date"])
                        # 单位对齐（关键修复）：实盘 get_fflow_factor 把主力净流入(元)
                        # ÷1e4 换算成万元(见 fflow.py)；回测若直接用原始元，
                        # _score 里 fflow5/300 会提前触顶 ±10 → 资金流因子恒满格，
                        # 与实盘口径差 1 万倍，回测调出的阈值对实盘无代表性
                        ff["main_net_5d"] = (ff["main_net_5d"] / 1e4).round(1)
                        fflow_map = dict(zip(ff["date"], zip(ff["main_net_5d"], ff["main_pct_5d"])))
            except Exception:
                pass

        scores = [np.nan] * n
        c_arr = df["close"].values
        for i in range(60, n):
            row = d.iloc[i]
            macd_b = bool(row["macd"] > row["macd_signal"])
            prev = d.iloc[i - 1]
            macd_cross = bool(prev["macd"] <= prev["macd_signal"]) and macd_b
            ma_b = bool(row["ma5"] > row["ma20"] > row["ma50"])
            r = row["rsi"]
            m5 = row["mom_5d"] if pd.notna(row["mom_5d"]) else 0

            fflow5 = fflow5_pct = None
            if self.use_fflow:
                if fflow_map:
                    key = df["date"].iloc[i]
                    if key in fflow_map:
                        fflow5, fflow5_pct = fflow_map[key]
            else:
                # 未启用资金流 → 传 _MISSING(因子未启用)：旧代码传 None 会走进
                # _score 的"数据缺失扣5分"分支，等于关掉资金流反而天天被扣分，
                # 全回测基准分系统性偏低 5 分，训练出的阈值失真
                fflow5 = fflow5_pct = _MISSING

            # 趋势质量 / 板块动量 / 长期动量（全部只用 i 日及以前的数据，
            # 与线上 rotation.sector_rotation + signals._lt_r250 同公式 → 同分数）
            tq = None
            sector_mom = None
            lt_r = None
            if i >= 60:
                c = c_arr[i]
                r60 = (c / c_arr[i - 60] - 1) * 100 if c_arr[i - 60] > 0 else 0
                r20 = (c / c_arr[i - 20] - 1) * 100 if c_arr[i - 20] > 0 else 0
                r5 = (c / c_arr[i - 5] - 1) * 100 if c_arr[i - 5] > 0 else 0
                # 与线上 rotation 的 momentum 公式一致（r60*0.4 + r20*0.35 + r5*0.25）
                sector_mom = r60 * 0.4 + r20 * 0.35 + r5 * 0.25
                if r60 > 5 and r5 > -2:
                    tq = "强趋势"
                elif r60 > 5 and r20 < 0 and r5 > 0:
                    tq = "回调企稳"
                elif r60 < -10 and r5 > 3:
                    tq = "超跌反弹"
                elif r60 < -5:
                    tq = "下跌趋势"
                else:
                    tq = "震荡"
            if self.use_lt and i >= 250 and c_arr[i - 250] > 0:
                lt_r = (c_arr[i] / c_arr[i - 250] - 1) * 100

            scores[i] = _score(
                macd_b, macd_cross, ma_b, r, m5,
                bool(row.get("pat_w")), bool(row.get("pat_div")),
                bool(row.get("pat_brk")), int(row.get("macd_quality", 0)),
                fflow5=fflow5, fflow5_pct=fflow5_pct,
                sector_momentum=(sector_mom if self.use_sector and sector_mom is not None else _MISSING),
                trend_quality=(tq if self.use_sector and tq is not None else _MISSING),
                lt_r250=(lt_r if lt_r is not None else _MISSING),
            )
        d["score"] = scores
        sig = np.zeros(n, dtype=int)
        sig[np.asarray(scores) >= self.buy_th] = 1
        # 趋势保护：60日动量 > 8% 时，SELL 阈值放宽（避免回调误杀）。
        # 必须逐行用「当日及之前」的动量判定——旧实现用整段回测的
        # df.iloc[-1]/iloc[-61]（回测期末动量）放宽全程卖出线 = 未来函数，
        # 期末上涨的标的会系统性少卖、多扛回调，收益被抬高。
        sell_th = np.full(n, float(self.sell_th))
        if n > 61:
            close_arr = df["close"].to_numpy(dtype=float)
            relax = close_arr[60:] / close_arr[:-60] - 1 > 0.08
            sell_th[60:] = np.where(relax, float(self.sell_th - 15), float(self.sell_th))
        sig[np.asarray(scores) <= sell_th] = -1
        d["signal"] = sig
        return d


# ============ 回测引擎 ============

class Backtest:
    def __init__(self, df: pd.DataFrame, strategy: Strategy,
                 initial_capital: float = None,
                 commission: float = None, slippage: float = None,
                 enable_risk: bool = True,
                 stop_drawdown: float = None, stop_loss: float = None,
                 take_profit: float = None,
                 use_trailing_stop: bool = None,
                 trailing_activate: float = None, trailing_stop: float = None,
                 trade_start: str = None):
        self.df = df.copy()
        self.strategy = strategy
        self.initial_capital = initial_capital or TRADING["initial_capital"]
        self.commission = commission if commission is not None else TRADING["commission"]
        self.slippage = slippage if slippage is not None else TRADING["slippage"]
        self.enable_risk = enable_risk
        # 修复（GPT 复核 D/#19）：账户交易起点。trade_start 之前的行只用于指标/评分
        # 预热，不建仓、不计风控；旧实现预热期照常交易，只把曲线裁掉 → 收益率被
        # start 之前的价格路径污染（start 前先跌 50% 再涨回，B&H 显示 0% 而非 +100%）。
        self.trade_start = str(trade_start)[:10] if trade_start else None
        self.stop_drawdown = stop_drawdown if stop_drawdown is not None else RISK["stop_drawdown"]
        self.stop_loss = stop_loss if stop_loss is not None else RISK["stop_loss"]
        self.take_profit = take_profit if take_profit is not None else RISK["take_profit"]
        # 移动止盈：盈利超 activate 后，从峰值回撤 trailing_stop% 才卖（让利润奔跑）
        self.use_trailing_stop = RISK["use_trailing_stop"] if use_trailing_stop is None else use_trailing_stop
        self.trailing_activate = trailing_activate if trailing_activate is not None else RISK["trailing_activate"]
        self.trailing_stop = trailing_stop if trailing_stop is not None else RISK["trailing_stop"]
        # 趋势自适应止盈（V3）：60日动量强时放宽止盈线
        self.trend_adaptive = RISK.get("trend_adaptive", True)
        self.trend_r60_threshold = RISK.get("trend_r60_threshold", 5.0)
        self.trailing_stop_strong = RISK.get("trailing_stop_strong", -15.0)
        self.trailing_activate_strong = RISK.get("trailing_activate_strong", 12.0)
        self.stop_drawdown_strong = RISK.get("stop_drawdown_strong", -15.0)  # 强趋势峰值回撤止损放宽
        # 统一风控配置（在线 stop_loss_check 与回测共用 evaluate_risk）
        self.risk_cfg = {
            **RISK,
            "stop_drawdown": self.stop_drawdown, "stop_loss": self.stop_loss,
            "take_profit": self.take_profit, "use_trailing_stop": self.use_trailing_stop,
            "trailing_activate": self.trailing_activate, "trailing_stop": self.trailing_stop,
            "trend_adaptive": self.trend_adaptive,
            "trend_r60_threshold": self.trend_r60_threshold,
            "trailing_activate_strong": self.trailing_activate_strong,
            "trailing_stop_strong": self.trailing_stop_strong,
            "stop_drawdown_strong": self.stop_drawdown_strong,
        }

    def run(self) -> dict:
        df = self.strategy.generate_signals(self.df)
        n = len(df)
        if n < 2:
            return {"error": "数据不足"}

        cash = np.full(n, self.initial_capital, dtype=float)
        shares = np.zeros(n, dtype=float)
        position = np.zeros(n, dtype=int)
        equity = np.full(n, self.initial_capital, dtype=float)
        trades = []
        peak = 0.0        # 持仓期间最高价
        cost_price = 0.0  # 持仓成本价

        pending_sell = None   # 昨日收盘风控触发 → 今日开盘价成交（None=无挂单）
        # 账户交易起点索引（trade_start 之前的行只做指标预热，不交易/不风控/不建仓）
        trade_start_idx = None
        if self.trade_start:
            trade_start_idx = next((k for k in range(n)
                                    if str(df["date"].iloc[k])[:10] >= self.trade_start), None)
            if trade_start_idx is None:
                return {"error": f"trade_start({self.trade_start}) 之后无数据"}
        for i in range(1, n):
            # 默认延续前一日
            cash[i] = cash[i - 1]
            shares[i] = shares[i - 1]
            position[i] = position[i - 1]
            if trade_start_idx is not None and i < trade_start_idx:
                # 预热期：不建仓、不计风控，权益保持初始现金
                equity[i] = cash[i]
                continue

            open_p = df["open"].iloc[i]
            close_p = df["close"].iloc[i]

            # ---- 开盘 1：先执行昨日收盘触发的风控卖单（次日开盘成交） ----
            # 旧实现按“触发日收盘价”当日立即成交，而实盘只能在收盘后知道触发、
            # 次日开盘才卖得掉 → 暴跌日次日的跳空低开损失被回测回避，回撤/年化偏乐观。
            # 改为 T+1 开盘价成交；若 T+1 开盘同时有 BUY 信号，也当天不买回（止损后冷静）。
            if pending_sell is not None and position[i - 1] == 1:
                stop_price = open_p * (1 - self.slippage)
                # 修复：卖出回笼必须加到原有现金上（旧实现直接覆盖 → 凭空少钱）
                cash[i] = cash[i - 1] + shares[i - 1] * stop_price * (1 - self.commission)
                shares[i] = 0
                position[i] = 0
                trades.append({"date": str(df["date"].iloc[i]), "action": "SELL",
                               "price": round(stop_price, 4), "shares": shares[i - 1],
                               "reason": pending_sell + "（次日开盘成交）"})
                peak = 0.0
                cost_price = 0.0
                pending_sell = None
                equity[i] = cash[i]
                continue  # 当日不再开新仓、也无持仓供收盘风控

            # ---- 开盘 2：执行 T-1 信号 ----
            signal = df["signal"].iloc[i - 1]
            buy_price = open_p * (1 + self.slippage)
            sell_price = open_p * (1 - self.slippage)

            if signal == 1 and position[i - 1] == 0:
                # 修复：手数必须把佣金算进可用现金，否则 cash 会变成负数
                affordable = cash[i - 1] / (buy_price * (1 + self.commission))
                max_lots = int(affordable // 100 * 100)
                if max_lots > 0 and max_lots * buy_price * (1 + self.commission) > cash[i - 1]:
                    max_lots -= 100  # 浮点/整手边界兜底
                if max_lots > 0:
                    shares[i] = max_lots
                    cost = max_lots * buy_price
                    fee = cost * self.commission
                    cash[i] = cash[i - 1] - cost - fee
                    position[i] = 1
                    peak = buy_price
                    cost_price = buy_price
                    trades.append({"date": str(df["date"].iloc[i]), "action": "BUY",
                                   "price": round(buy_price, 4), "shares": shares[i]})
            elif signal == -1 and position[i - 1] == 1:
                # 修复：卖出回笼累加到原有现金（旧实现覆盖）
                cash[i] = cash[i - 1] + shares[i - 1] * sell_price * (1 - self.commission)
                shares[i] = 0
                position[i] = 0
                trades.append({"date": str(df["date"].iloc[i]), "action": "SELL",
                               "price": round(sell_price, 4), "shares": shares[i - 1]})
                peak = 0.0
                cost_price = 0.0

            # ---- 收盘风控（统一规则引擎 evaluate_risk，与实盘 stop_loss_check 同源） ----
            if position[i] == 1 and self.enable_risk:
                peak = max(peak, close_p)
                r60 = None
                if i >= 60 and df["close"].iloc[i - 60] > 0:
                    r60 = (close_p / df["close"].iloc[i - 60] - 1) * 100
                risk_iv = evaluate_risk(cost_price, peak, close_p, r60=r60,
                                        risk=self.risk_cfg)
                peak = risk_iv["peak"]
                stop_hit = risk_iv["stop_triggered"]
                take_hit = risk_iv["take_profit"]
                if stop_hit or take_hit:
                    reason = ("风控止损" if stop_hit
                              else ("移动止盈" if risk_iv["trailing_take"] else "止盈"))
                    if i == n - 1:
                        # 回测末日没有次日开盘：按当日收盘价清仓（近似）
                        stop_price = close_p * (1 - self.slippage)
                        # 修复（GPT 复核 A/#05）：末日可能“当天刚买入”，此时 cash[i] 已扣
                        # 买入成本，清仓回笼必须累加到 cash[i] 而不是买入前的 cash[i-1]，
                        # 否则会把买入前本金重复计入（复现：1000 → 2200）。
                        cash[i] = cash[i] + shares[i] * stop_price * (1 - self.commission)
                        reason = reason + "（末日清仓）"
                        trades.append({"date": str(df["date"].iloc[i]), "action": "SELL",
                                       "price": round(stop_price, 4), "shares": shares[i],
                                       "reason": reason})
                        shares[i] = 0
                        position[i] = 0
                        peak = 0.0
                        cost_price = 0.0
                    else:
                        pending_sell = reason   # 挂次日开盘卖单

            equity[i] = cash[i] + shares[i] * close_p

        perf = compute_performance(equity, df["date"], df["close"].values)
        perf["trades"] = len(trades)
        perf["win_rate"], perf["closed_pairs"] = trade_pair_stats(trades)
        perf["strategy"] = self.strategy.name
        perf["initial_capital"] = self.initial_capital
        perf["final_equity"] = round(float(equity[-1]), 2)
        perf["trade_list"] = trades
        perf["equity_curve"] = [round(float(x), 2) for x in equity]
        perf["dates"] = df["date"].dt.strftime("%Y-%m-%d").tolist()
        perf["drawdown_curve"] = [round(float(x), 2) for x in
                                  (equity - np.maximum.accumulate(equity)) / np.maximum.accumulate(equity) * 100]
        return perf


# ============ 优化器（样本外验证） ============

def find_best_thresholds(code: str, start: str = None, test_ratio: float = 0.3,
                         enable_risk: bool = True, use_fflow: bool = True) -> dict | None:
    """
    网格搜索最优 buy_th/sell_th，并做样本外验证。

    修复（第 16 项）：测试期评估带 60 根指标预热，但**只在测试区间计收益/成交**；
    测试期交易数为 0 或区间过短时返回 evaluation.insufficient=True，
    供 verify 层区分“评估不足”与“表现差”，不再把无效评估标成无效策略。
    """
    import pandas as _pd

    df = fetch(code)
    if len(df) < 120:
        return None
    if start:
        df = df[df["date"] >= start].reset_index(drop=True)
    if len(df) < 120:
        return None

    split = int(len(df) * (1 - test_ratio))
    train_df = df.iloc[:split].reset_index(drop=True)
    test_df = df.iloc[split:].reset_index(drop=True)
    if len(test_df) < 20:
        return None

    best = {"sharpe": -99, "buy_th": None, "sell_th": None, "train_ret": None}
    for buy_th in range(45, 75, 5):
        for sell_th in range(20, 45, 5):
            if sell_th >= buy_th:
                continue
            try:
                st = ScoreStrategy(buy_th, sell_th, use_fflow=use_fflow, code=code)
                bt = Backtest(train_df, st, enable_risk=enable_risk)
                r = bt.run()
                if r.get("sharpe_ratio", -99) > best["sharpe"]:
                    best = {"sharpe": r["sharpe_ratio"], "buy_th": buy_th,
                            "sell_th": sell_th, "train_ret": r["total_return"]}
            except Exception:
                continue
    if best["buy_th"] is None:
        return None

    # ---- 测试期：训练集尾部 SCORE_WARMUP 根只做指标预热，收益/成交从测试起点算 ----
    # 修复（GPT 复核 C/#12/#16）：预热 60 根不足以计算 250 日长期因子 → 样本外评分
    # 与线上口径不一致（同一天线上 45 分该买、切片 41 分不买）。
    warmup = train_df.tail(SCORE_WARMUP)
    extended = _pd.concat([warmup, test_df]).reset_index(drop=True)
    test_start = str(test_df["date"].iloc[0])[:10]
    st_test = ScoreStrategy(best["buy_th"], best["sell_th"], use_fflow=use_fflow, code=code)
    r_ext = Backtest(extended, st_test, enable_risk=enable_risk,
                     trade_start=test_start).run()
    dates_ext = list(r_ext.get("dates") or [])
    eq_ext = np.asarray(r_ext.get("equity_curve") or [], dtype=float)
    idx0 = next((k for k, d in enumerate(dates_ext) if d >= test_start), None)
    test_bars = len(test_df)
    if idx0 is None or idx0 >= len(eq_ext) - 1:
        test_perf = {"sharpe_ratio": None, "total_return": None}
        test_trades = []
    else:
        base = eq_ext[idx0] if eq_ext[idx0] else st_test_initial(r_ext)
        eq_trim = eq_ext[idx0:] / base * float(r_ext.get("initial_capital") or TRADING["initial_capital"])
        dates_trim = dates_ext[idx0:]
        close_trim = extended["close"].to_numpy(dtype=float)[idx0:]
        perf_trim = compute_performance(eq_trim, _pd.Series(_pd.to_datetime(dates_trim)), close_trim)
        test_perf = {"sharpe_ratio": perf_trim["sharpe_ratio"],
                     "total_return": perf_trim["total_return"]}
        test_trades = [t for t in (r_ext.get("trade_list") or [])
                       if str(t.get("date", ""))[:10] >= test_start]
    insufficient = bool(len(test_trades) == 0 or test_bars < 60)

    st_all = ScoreStrategy(best["buy_th"], best["sell_th"], use_fflow=use_fflow, code=code)
    all_perf = Backtest(df, st_all, enable_risk=enable_risk).run()

    cfg = {"use_fflow": bool(use_fflow),
           "use_sector": bool(getattr(st_all, "use_sector", True)),
           "use_lt": bool(getattr(st_all, "use_lt", SCORE_LT_TERM))}
    return {
        "code": code,
        "name": CODE2NAME.get(code, code),
        "buy_th": best["buy_th"],
        "sell_th": best["sell_th"],
        "test_ratio": test_ratio,
        "score_config": cfg,
        "train": {"sharpe": best["sharpe"], "total_return": best["train_ret"]},
        "test": {"sharpe": test_perf.get("sharpe_ratio"),
                 "total_return": test_perf.get("total_return")},
        "evaluation": {
            "test_bars": test_bars,
            "test_trades": len(test_trades),
            "warmup_bars": len(warmup),
            "insufficient": insufficient,
            "note": ("评估不足：测试期没有成交或区间过短，不能据此判定策略无效"
                     if insufficient else "测试期有有效成交"),
        },
        "all": {"sharpe": all_perf.get("sharpe_ratio"),
                "total_return": all_perf.get("total_return")},
    }


def st_test_initial(perf):
    return float(perf.get("initial_capital") or TRADING["initial_capital"])


# ============ 多策略对比 ============

def strategy_comparison(code: str, start: str = None, enable_risk: bool = True) -> dict:
    """对单只 ETF 跑多个策略对比，返回汇总 + 各自曲线。

    start: 收益统计起点。start 之前最多 SCORE_WARMUP(260) 根只用于指标预热
    （覆盖 250 日长期因子），且账户从 start 当天才开始交易；返回的绩效、曲线、
    成交统计都从 start 起算，曲线以初始本金归一。
    """
    import pandas as _pd

    df = fetch(code)
    if len(df) < 60:
        return {"error": "数据不足"}

    start_str = None
    if start:
        try:
            cutoff = _pd.to_datetime(start)
        except Exception as e:
            return {"error": f"start 参数解析失败: {e}"}
        start_str = cutoff.strftime("%Y-%m-%d")
        pre = df[df["date"] < cutoff]
        keep = df[df["date"] >= cutoff]
        if len(keep) < 60:
            return {"error": "start 之后数据不足 60 根"}
        warm = pre.tail(SCORE_WARMUP)
        n_warmup = len(warm)
        df = _pd.concat([warm, keep]).reset_index(drop=True)
    else:
        n_warmup = 0

    strategies = [
        ScoreStrategy(45, 20, code=code),
        ScoreStrategy(50, 30, code=code),
        ScoreStrategy(70, 20, code=code),
        BuyAndHoldStrategy(),
    ]
    results = []
    curves = {}
    bench_close = None
    bench_dates = None
    for st in strategies:
        bt = Backtest(df, st, enable_risk=enable_risk, trade_start=start_str)
        r = bt.run()
        dates = list(r["dates"])
        eq = np.asarray(r["equity_curve"], dtype=float)
        draw = np.asarray(r["drawdown_curve"], dtype=float)
        trades = list(r.get("trade_list") or [])
        bench_close = df["close"].to_numpy(dtype=float)
        bench_dates = dates

        if start_str:
            idx0 = next((i for i, d in enumerate(dates) if d >= start_str), None)
            if idx0 is None or idx0 >= len(eq) - 1:
                continue
            # 指标预热在 start 之前完成；收益从 start 起算并以初始本金归一
            base = eq[idx0] if eq[idx0] else 1.0
            eq = eq[idx0:] / base * r["initial_capital"]
            dates = dates[idx0:]
            bench_close = bench_close[idx0:]
            draw = (eq - np.maximum.accumulate(eq)) / np.maximum.accumulate(eq) * 100
            trades = [t for t in trades if str(t.get("date", ""))[:10] >= start_str]
            perf = compute_performance(eq, _pd.Series(_pd.to_datetime(dates)), bench_close)
            total_ret = perf["total_return"]
            sharpe = perf["sharpe_ratio"]
            mdd = perf["max_drawdown"]
            bench_ret = perf["benchmark_return"]
            win_rate, _closed = trade_pair_stats(trades)
            trade_cnt = len(trades)
        else:
            total_ret = r["total_return"]
            sharpe = r["sharpe_ratio"]
            mdd = r["max_drawdown"]
            bench_ret = r["benchmark_return"]
            win_rate = r["win_rate"]
            trade_cnt = r["trades"]

        results.append({
            "strategy": st.name, "total_return": total_ret,
            "sharpe": sharpe, "max_drawdown": mdd,
            "trades": trade_cnt, "win_rate": win_rate,
            "benchmark_return": bench_ret,
        })
        curves[st.name] = {"dates": dates,
                           "equity": [round(float(x), 2) for x in eq],
                           "drawdown": [round(float(x), 2) for x in draw]}

    if not results:
        return {"error": "start 之后无可统计区间"}
    results.sort(key=lambda x: x["sharpe"], reverse=True)
    first_dates = curves[list(curves.keys())[0]]["dates"]
    return {
        "code": code, "name": CODE2NAME.get(code, code),
        "results": results, "curves": curves,
        "start": start_str,
        "warmup_bars": n_warmup,
        "benchmark": {"dates": first_dates, "close": [round(float(x), 4) for x in bench_close]},
        "enable_risk": enable_risk,
    }
