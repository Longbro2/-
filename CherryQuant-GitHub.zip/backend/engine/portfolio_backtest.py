# -*- coding: utf-8 -*-
"""
CherryQuant Web — 组合回测引擎
在单标的回测之上，评估"多只 ETF 按系统信号同时持仓"的组合整体表现：
  - 等权分配资金，每只独立按系统信号操作 + 独立风控（与实盘一致的止损/止盈）
  - 组合净值曲线（合并各标的市值 + 现金）
  - 真实对比"买入持有组合"（等权买入持有，无择时）
  - 各 ETF 贡献度 + 相关性提示

与单标的 Backtest 的关系：组合回测 = 把资金等分给每只 ETF，
各自跑与实盘一致的 ScoreStrategy + 风控，再把净值加总。
"""
import numpy as np
import pandas as pd

from .backtest import ScoreStrategy, BuyAndHoldStrategy, Backtest, compute_performance
from .data import fetch
from .config import POOL, CODE2NAME


def portfolio_backtest(codes: list = None, capital: float = None,
                       buy_th: int = 45, sell_th: int = 25,
                       start: str = None, enable_risk: bool = True) -> dict:
    """
    组合回测：等权分配资金，每只独立操作 + 独立风控。
    返回组合净值、绩效、与买入持有对比、各ETF贡献度。
    """
    if codes is None:
        codes = [info["code"] for info in POOL.values()]
    if not codes:
        return {"error": "无标的"}
    capital = capital or 100000.0
    # 修复：等权资金必须在“剔除无数据标的之后”再分配（见下方 df_map 过滤后）。
    # 旧实现先按请求数量分配、再跳过缺数据标的 → 本金与曲线起点对不上
    # （请求 2 只、1 只无数据时，曲线从 5 万开始却宣称本金 10 万）。

    # ---- 0. 拉取数据，统一从「公共起点」截断 ----
    # 目的：各标的数据起点不同（新上市/新缓存），若各跑各的再合并，
    # 公共区间首日时老标的已跑了一段，组合首日净值 ≠ 初始资金，收益基准失真。
    df_map = {}
    earliest_common = None
    for code in codes:
        df = fetch(code, offline=True)
        if len(df) < 100:
            continue
        if start:
            df = df[df["date"] >= start].reset_index(drop=True)
        if len(df) < 100:
            continue
        df_map[code] = df
        s = df["date"].iloc[0]
        if earliest_common is None or s > earliest_common:
            earliest_common = s  # 公共起点 = 最晚的开始日

    if not df_map:
        return {"error": "无有效数据（均不足100条日线）"}
    # 统一截断到公共起点，保证每只都从同一天开始
    for code in list(df_map.keys()):
        df_map[code] = df_map[code][df_map[code]["date"] >= earliest_common].reset_index(drop=True)
        if len(df_map[code]) < 100:
            del df_map[code]
    if not df_map:
        return {"error": "统一起点后数据不足"}

    # ---- 修复：按实际参与回测的标的数量重新等权分配本金 ----
    n_total = len(df_map)
    per_capital = capital / n_total
    capital = per_capital * n_total   # 与分配保持一致（浮点回正）

    # ---- 1. 每只 ETF 分别跑「系统策略」和「买入持有」 ----
    sys_curves = {}   # code -> 系统策略回测结果
    bh_curves = {}    # code -> 买入持有回测结果
    for code, df in df_map.items():
        bt = Backtest(df, ScoreStrategy(buy_th, sell_th, code=code),
                      initial_capital=per_capital, enable_risk=enable_risk)
        sys_curves[code] = bt.run()

        bh = Backtest(df, BuyAndHoldStrategy(),
                      initial_capital=per_capital, enable_risk=False)
        bh_curves[code] = bh.run()

    if not sys_curves:
        return {"error": "无有效数据（均不足100条日线）"}

    # ---- 2. 对齐公共交易日 ----
    common = set(sys_curves[list(sys_curves)[0]]["dates"])
    for c in sys_curves.values():
        common &= set(c["dates"])
    common_dates = sorted(common)
    n_days = len(common_dates)
    if n_days < 2:
        return {"error": "公共交易日不足2天"}
    date_idx = {d: i for i, d in enumerate(common_dates)}

    # ---- 3. 组合净值 = Σ 各标的净值（按公共日期对齐，缺失前值填充） ----
    combo_sys = np.zeros(n_days)
    combo_bh = np.zeros(n_days)
    cnt_sys = np.zeros(n_days)
    cnt_bh = np.zeros(n_days)
    for code, c in sys_curves.items():
        for i, d in enumerate(c["dates"]):
            if d in date_idx:
                j = date_idx[d]
                combo_sys[j] += c["equity_curve"][i]
                cnt_sys[j] += 1
    for code, c in bh_curves.items():
        for i, d in enumerate(c["dates"]):
            if d in date_idx:
                j = date_idx[d]
                combo_bh[j] += c["equity_curve"][i]
                cnt_bh[j] += 1

    # 首日缺失（某只早期未上市）→ 用已上市部分净值；完全空窗日 → 持有现金
    combo_sys = np.where(cnt_sys > 0, combo_sys, np.nan)
    combo_bh = np.where(cnt_bh > 0, combo_bh, np.nan)
    combo_sys = pd.Series(combo_sys).ffill().fillna(capital).values
    combo_bh = pd.Series(combo_bh).ffill().fillna(capital).values

    dates_series = pd.Series(pd.to_datetime(common_dates))

    # ---- 4. 组合绩效（基准 = 真实买入持有组合） ----
    perf = compute_performance(combo_sys, dates_series, combo_bh)
    bh_perf = compute_performance(combo_bh, dates_series, combo_bh)

    # 最大回撤
    peak = np.maximum.accumulate(combo_sys)
    dd = (combo_sys - peak) / peak * 100
    max_dd = float(dd.min()) if n_days else 0.0

    # ---- 5. 各 ETF 贡献度 ----
    contributions = []
    for code, c in sys_curves.items():
        contributions.append({
            "name": c.get("name", CODE2NAME.get(code, code)),
            "code": code,
            "total_return": c["total_return"],
            "sharpe": c["sharpe_ratio"],
            "max_drawdown": c["max_drawdown"],
            "trades": c["trades"],
            "win_rate": c["win_rate"],
            "closed_pairs": c.get("closed_pairs", 0),
            "weight": round(1 / len(sys_curves) * 100, 1),
        })
    contributions.sort(key=lambda x: -x["total_return"])

    # ---- 6. 相关性提示（用已上市标的的收益率矩阵） ----
    corr_info = None
    try:
        from .correlation import correlation_matrix
        corr_info = correlation_matrix(list(sys_curves.keys()))
    except Exception:
        corr_info = None

    return {
        "codes": list(sys_curves.keys()),
        "n_holdings": len(sys_curves),
        "n_days": n_days,
        "buy_th": buy_th,
        "sell_th": sell_th,
        "enable_risk": enable_risk,
        "initial_capital": capital,
        "portfolio_return": round(float(perf["total_return"]), 2),
        "portfolio_annual": round(float(perf["annual_return"]), 2),
        "portfolio_sharpe": round(float(perf["sharpe_ratio"]), 2),
        "portfolio_max_dd": round(float(max_dd), 2),
        "benchmark_return": round(float(bh_perf["total_return"]), 2),
        "benchmark_sharpe": round(float(bh_perf["sharpe_ratio"]), 2),
        "benchmark_max_dd": round(float(bh_perf["max_drawdown"]), 2),
        "alpha": round(float(perf["total_return"] - bh_perf["total_return"]), 2),
        "dates": common_dates,
        "equity_curve": [round(float(x), 2) for x in combo_sys],
        "benchmark_curve": [round(float(x), 2) for x in combo_bh],
        "drawdown_curve": [round(float(x), 2) for x in dd],
        "contributions": contributions,
        "correlation": corr_info,
    }
