# -*- coding: utf-8 -*-
"""
CherryQuant Web — 数据层
- 自动联网拉取（东财直连 → akshare 备选），缓存按来源分目录
- Choice Excel 上传解析
- 数据新鲜度检查
"""
import os
import re
import time
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import requests

from .config import (
    EASTMONEY_DIR, AKSHARE_DIR, TENCENT_DIR, CHOICE_DIR, LEGACY_DIR,
    CODE2NAME, KLINE_LIMIT, SOURCE_ORDER,
    TENCENT_KLINE_URL,
)
from .db import upsert_meta, list_meta

# ============ 工具 ============

def _std_date(s) -> str:
    """任意日期格式 → 'YYYY-MM-DD'"""
    try:
        return pd.Timestamp(s).strftime("%Y-%m-%d")
    except Exception:
        return str(s)


def _empty_df() -> pd.DataFrame:
    return pd.DataFrame(columns=["date", "open", "close", "high", "low", "volume"])


# ============ 各来源缓存路径 ============

def _csv_path(source: str, code: str) -> Path:
    d = {"eastmoney": EASTMONEY_DIR, "akshare": AKSHARE_DIR,
         "tencent": TENCENT_DIR, "choice": CHOICE_DIR}[source]
    return d / f"{code}.csv"


def _read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return _empty_df()
    try:
        df = pd.read_csv(path)
        if "date" not in df.columns or len(df) == 0:
            return _empty_df()
        df["date"] = pd.to_datetime(df["date"])
        return df.sort_values("date").reset_index(drop=True)
    except Exception:
        return _empty_df()


def _write_csv(path: Path, df: pd.DataFrame):
    """原子写盘：先写同目录 *.tmp 再 os.replace，避免并发/半截文件损坏缓存。"""
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
    tmp = path.with_suffix(path.suffix + ".tmp")
    df.to_csv(tmp, index=False)
    os.replace(tmp, path)


def _verify_cross_source(code: str, src: str, df: pd.DataFrame) -> pd.DataFrame:
    """当日收盘价跨源校验。

    背景：eastmoney 偶尔返回盘中快照/异常数据并被缓存，导致收盘价失真
    （2026-08-11 曾污染 20 只池子中的 17 只）。腾讯为当前可信源。
    规则：若 src 非腾讯，且腾讯缓存有同一最后交易日数据，
    但两者收盘价差异 > 0.3%，判定 src 数据异常，改用腾讯数据。
    """
    if src == "tencent" or len(df) == 0:
        return df
    try:
        tdf = _read_csv(_csv_path("tencent", code))
        if len(tdf) == 0:
            return df
        d_src = df["date"].iloc[-1].strftime("%Y-%m-%d")
        d_tc = tdf["date"].iloc[-1].strftime("%Y-%m-%d")
        if d_src != d_tc:
            return df  # 最后交易日不同，不做校验
        c_src = float(df["close"].iloc[-1])
        c_tc = float(tdf["close"].iloc[-1])
        if c_tc <= 0:
            return df
        diff = abs(c_src - c_tc) / c_tc * 100
        if diff > 0.3:
            print(f"  [warn] {code} 跨源校验: {src}收盘{c_src} vs 腾讯{c_tc} 差{diff:.2f}%，改用腾讯数据")
            return tdf
    except Exception:
        pass
    return df


# ============ 交易日近似日历（无节假日历的轻量方案） ============

def _trading_expected_date(now: datetime = None) -> str:
    """今天应能缓存到的“最近交易日”近似：
    - 周一~五 15:10 后（日线已收盘）→ 当天
    - 其余时间（盘前/盘中/周末）→ 回退到最近一个工作日（周末回到周五）
    仅用于新鲜度判断与盘中K线清洗。节假日(工作日休市)误差只会导致
    刷新时多拉一次数据，绝不会把旧数据误判为新鲜。
    """
    now = now or datetime.now()
    d = now.date()
    if now.hour < 15 or (now.hour == 15 and now.minute < 10):
        d = d - timedelta(days=1)
    while d.weekday() >= 5:
        d = d - timedelta(days=1)
    return d.strftime("%Y-%m-%d")


def _strip_incomplete_today(df: pd.DataFrame, now: datetime = None) -> pd.DataFrame:
    """盘中(15:10 前)拉到的日线末行可能是未收盘的实时 K 线：
    写入缓存前剔除，保证全天沿用“已收盘”数据（与信号引擎 T-1 口径一致）。
    收盘后再拉取则保留当日完整 K 线。"""
    now = now or datetime.now()
    if len(df) == 0:
        return df
    if (now.hour < 15 or (now.hour == 15 and now.minute < 10)) \
            and df["date"].iloc[-1].strftime("%Y-%m-%d") == now.strftime("%Y-%m-%d"):
        return df.iloc[:-1].copy()
    return df


# ============ 数据源失败冷却记忆 ============
# 东财/akshare 偶尔被反爬拒绝，若每次联网都白试一遍，会拖慢刷新。
# 记录每个源的失败时间，冷却期内跳过该源（自动恢复：冷却结束后再试一次）。
_SRC_FAIL = {}        # {fetch_fn_name: last_fail_ts}
_SRC_FAIL_MAX = 3     # 连续失败 3 次才进入冷却
_SRC_COOL_SECS = 1800 # 冷却 30 分钟


def _source_cooled(name: str) -> bool:
    """该源是否在冷却期。连续失败超阈值才会被冷却。"""
    ts = _SRC_FAIL.get(name)
    if ts is None:
        return False
    if ts[0] < _SRC_FAIL_MAX:
        return False
    return time.time() - ts[1] < _SRC_COOL_SECS


def _mark_source_fail(name: str):
    cnt, _ = _SRC_FAIL.get(name, (0, 0))
    _SRC_FAIL[name] = (cnt + 1, time.time())


def _mark_source_ok(name: str):
    _SRC_FAIL.pop(name, None)


# ============ 联网拉取 ============

def _fetch_eastmoney(code: str) -> pd.DataFrame:
    """东财 K 线接口直连。secid: 5 开头=沪市(1.)，其余=深市(0.)"""
    secid = f"1.{code}" if code.startswith("5") else f"0.{code}"
    r = requests.get(
        "https://push2his.eastmoney.com/api/qt/stock/kline/get",
        params={
            "secid": secid,
            "fields1": "f1,f2,f3,f4,f5,f6",
            "fields2": "f51,f52,f53,f54,f55,f56,f57",
            "klt": "101", "fqt": "1", "end": "20500101", "lmt": KLINE_LIMIT,
        },
        headers={"User-Agent": "Mozilla/5.0"},
        timeout=10,
    )
    data = r.json().get("data")
    if not data or not data.get("klines"):
        return _empty_df()
    rows = []
    for line in data["klines"]:
        p = line.split(",")
        rows.append({
            "date": p[0], "open": float(p[1]), "close": float(p[2]),
            "high": float(p[3]), "low": float(p[4]), "volume": float(p[5]),
        })
    df = pd.DataFrame(rows)
    return df if len(df) else _empty_df()


def _fetch_akshare(code: str) -> pd.DataFrame:
    """akshare 备选：fund_etf_hist_em 前复权日线"""
    import akshare as ak
    end = datetime.now().strftime("%Y%m%d")
    start = (datetime.now().replace(year=datetime.now().year - 2)).strftime("%Y%m%d")
    tmp = ak.fund_etf_hist_em(symbol=code, period="daily", start_date=start, end_date=end, adjust="qfq")
    if tmp is None or len(tmp) == 0:
        return _empty_df()
    tmp = tmp.rename(columns={
        "日期": "date", "开盘": "open", "收盘": "close",
        "最高": "high", "最低": "low", "成交量": "volume",
    })
    df = tmp[["date", "open", "close", "high", "low", "volume"]]
    return df if len(df) else _empty_df()


def _fetch_tencent(code: str) -> pd.DataFrame:
    """腾讯行情 K 线（东财/akshare 被反爬时的兜底源）。
    code 需转市场前缀: 5/6 开头=sh, 其余=sz。

    腾讯接口偶发返回 {"code":11,"msg":"mysql connect failed"} 或读超时
    （2026-08-26 实测抖动只持续数秒）。此处内置重试：瞬时故障自动重试，
    避免因单次失败退回旧缓存导致漏拉当天数据。
    """
    prefix = "sh" if code.startswith(("5", "6")) else "sz"
    sym = f"{prefix}{code}"
    max_retry = 3
    klines = None  # 防御：响应合法但不含该标的(如 code:11 / 空 data)时，else 分支不会引用未赋值变量
    for attempt in range(max_retry):
        try:
            r = requests.get(
                TENCENT_KLINE_URL,
                params={"param": f"{sym},day,,,{KLINE_LIMIT},qfq"},
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=10,
            )
            r.raise_for_status()
            payload = r.json()
            # 腾讯业务错误（如服务端 mysql 故障），重试
            if isinstance(payload.get("data"), dict) and sym in payload["data"]:
                node = payload["data"][sym]
                klines = node.get("qfqday") or node.get("day") or []
                if klines:
                    break  # 拿到有效数据，跳出
            # data 为空串 / code!=0：视为瞬时故障，重试
        except Exception:
            if attempt == max_retry - 1:
                raise
        time.sleep(0.5 * (attempt + 1))
    else:
        # 全部重试仍拿不到
        if not klines:
            return _empty_df()
    rows = []
    for row in klines:
        # 腾讯格式: [date, open, close, high, low, volume, ...]
        rows.append({
            "date": row[0],
            "open": float(row[1]),
            "close": float(row[2]),
            "high": float(row[3]),
            "low": float(row[4]),
            "volume": float(row[5]) if len(row) > 5 else 0,
        })
    df = pd.DataFrame(rows)
    return df if len(df) else _empty_df()


# ============ 统一入口 ============

def fetch(code: str, force: bool = False, name: str = None, offline: bool = False,
          source_order: tuple = None) -> pd.DataFrame:
    """
    获取某 ETF 日线数据。
    顺序: 已有今日缓存 → 东财直连 → akshare → 腾讯 → Choice 缓存 → 旧缓存。
    force=True 强制联网刷新；offline=True 只读本地缓存，绝不联网。
    返回标准化 DataFrame [date, open, close, high, low, volume]。
    """
    name = name or CODE2NAME.get(code, code)
    expected = _trading_expected_date()   # “最近交易日”近似，替代自然日 today

    # 1. 已有最近交易日数据且不强制 → 直接用（周末/节假日不再反复联网重拉）
    if not force:
        for src in SOURCE_ORDER:
            df = _read_csv(_csv_path(src, code))
            if len(df) > 0 and df["date"].iloc[-1].strftime("%Y-%m-%d") == expected:
                df = _verify_cross_source(code, src, df)
                upsert_meta(code, name, src, df["date"].iloc[-1].strftime("%Y-%m-%d"), len(df))
                return df
        # offline 模式：无今日数据也返回本地最新（不联网）
        if offline:
            for src in SOURCE_ORDER:
                df = _read_csv(_csv_path(src, code))
                if len(df) > 0:
                    df = _verify_cross_source(code, src, df)
                    return df
            legacy = LEGACY_DIR / "cache" / f"{code}.csv"
            if legacy.exists():
                df = _read_csv(legacy)
                if len(df) > 0:
                    return df
            return _empty_df()

    # 2. 联网拉取（跳过冷却中的源）；source_order 可指定尝试顺序（如补拉时以腾讯为主）
    last_error = None
    for fetch_fn in (source_order or (_fetch_eastmoney, _fetch_akshare, _fetch_tencent)):
        src_name = fetch_fn.__name__
        if _source_cooled(src_name):
            continue  # 该源最近连续失败，冷却期内跳过
        try:
            df = fetch_fn(code)
            if len(df) > 0:
                # 统一 date 列为 datetime
                df["date"] = pd.to_datetime(df["date"])
                df = _strip_incomplete_today(df)   # 盘中(15:10前)剔除未收盘的今日K线
            if len(df) > 0:
                src = {_fetch_eastmoney: "eastmoney", _fetch_akshare: "akshare",
                       _fetch_tencent: "tencent"}[fetch_fn]
                path = _csv_path(src, code)
                _write_csv(path, df)
                last_date = df["date"].iloc[-1].strftime("%Y-%m-%d")
                upsert_meta(code, name, src, last_date, len(df))
                _mark_source_ok(src_name)   # 成功 → 清除失败记录
                return df
            _mark_source_fail(src_name)      # 空结果/仅剩盘中未收尾行也算失败
        except Exception as e:
            last_error = e
            _mark_source_fail(src_name)      # 记录失败，用于冷却
            continue

    # 3. 联网失败 → 退回任意本地缓存
    for src in SOURCE_ORDER:
        df = _read_csv(_csv_path(src, code))
        if len(df) > 0:
            df = _verify_cross_source(code, src, df)
            print(f"  [warn] {code} 联网失败({last_error})，使用 {src} 缓存")
            return df

    # 4. 尝试旧项目缓存（一次性兼容，读后复制到新缓存实现自包含）
    legacy = LEGACY_DIR / "cache" / f"{code}.csv"
    if legacy.exists():
        df = _read_csv(legacy)
        if len(df) > 0:
            print(f"  [warn] {code} 使用旧项目缓存（已复制到新缓存）")
            # 复制到 eastmoney 缓存目录，避免下次再依赖旧目录
            _write_csv(_csv_path("eastmoney", code), df)
            last_date = df["date"].iloc[-1].strftime("%Y-%m-%d")
            upsert_meta(code, name, "legacy", last_date, len(df))
            return df
    return _empty_df()


def refresh_all(force: bool = False, codes: list = None, with_fflow: bool = True):
    """
    批量刷新全部池内 ETF 数据，返回结果摘要。
    with_fflow=True 时联动刷新资金流缓存（资金流是最强因子 IC0.160，
    若资金流缓存过期，评分会缺失该因子导致信号失真）。

    可靠性优化(2026-08-26)：第一轮拉取后，以「池内能获取到的最晚交易日」
    为基准做新鲜度校验。腾讯接口偶发抖动会让个别标的退回旧缓存
    （此前 dispatch 只判断 len>0 不校验日期，导致漏拉当天数据被误当成功）。
    对落后于基准的标的，单独用腾讯强制重刷并重试，仍不达标则记入 stale。
    """
    from .config import POOL
    codes = codes or [info["code"] for info in POOL.values()]
    result = {"ok": [], "failed": [], "stale": [], "retried": [],
              "fflow": {"ok": 0, "failed": []}}

    # 第一轮：拉取全部（含资金流）
    got = {}  # code -> last_date
    for code in codes:
        try:
            df = fetch(code, force=force)
            if len(df) == 0:
                result["failed"].append(code)
            else:
                got[code] = df["date"].iloc[-1].strftime("%Y-%m-%d")
                result["ok"].append(code)
        except Exception as e:
            result["failed"].append(f"{code}:{e}")
        if with_fflow:
            try:
                from .fflow import fetch_fflow
                ff = fetch_fflow(code, force=force)
                if len(ff) > 0:
                    result["fflow"]["ok"] += 1
                else:
                    result["fflow"]["failed"].append(code)
            except Exception as e:
                result["fflow"]["failed"].append(f"{code}:{e}")

    # 第二遍：新鲜度校验 + 强制补拉
    if got:
        target = max(got.values())          # 池内能获取到的最晚交易日
        retry_codes = [c for c, d in got.items() if d < target]
        for code in retry_codes:
            # 落后于最新 → 以腾讯为主强制重刷（fetch 内部腾讯已带重试）。
            # 旧实现直接 fetch(force=True) 会再按 东财→akshare→腾讯 顺序尝试，
            # 命中刚失败/在冷却中的源，导致补拉形同虚设。
            try:
                df = fetch(code, force=True,
                           source_order=(_fetch_tencent, _fetch_eastmoney, _fetch_akshare))
                if len(df) == 0:
                    continue
                new_date = df["date"].iloc[-1].strftime("%Y-%m-%d")
                if new_date > got[code]:
                    got[code] = new_date
                    result["retried"].append(code)
            except Exception:
                pass
        # 复检：仍落后最新 → stale
        for code, d in got.items():
            if code in result["ok"] and d < target:
                result["ok"].remove(code)
                result["stale"].append(code)
    return result


# ============ Choice Excel 解析 ============

def parse_choice_excel(file_path: str | Path) -> dict:
    """
    解析 Choice 导出的 K 线 Excel。
    兼容格式：
      A) 6列: 代码,名称,日期,净值,涨跌,涨跌幅%   (列索引 2=日期, 3=净值)
      B) 3列: 日期,基金名称/净值,基准名称        (列索引 0=日期, 1=净值)
      C) OHLCV: 13+列 (列索引 2=日期, 3-6=OHLC, 9=成交量)
    返回 {code, df}
    """
    df_raw = pd.read_excel(file_path, header=None)

    # 尝试从文件名或首行提取代码
    code = None
    fname = Path(file_path).name
    m = re.search(r"(\d{6})", fname)
    if m:
        code = m.group(1)

    dates, closes, opens, highs, lows, vols = [], [], [], [], [], []
    n_cols = df_raw.shape[1]

    if n_cols >= 13:  # 格式 C: OHLCV → 直接返回真实 OHLC
        d = pd.to_datetime(df_raw.iloc[:, 2], errors="coerce")
        o = pd.to_numeric(df_raw.iloc[:, 3], errors="coerce")
        h = pd.to_numeric(df_raw.iloc[:, 4], errors="coerce")
        l = pd.to_numeric(df_raw.iloc[:, 5], errors="coerce")
        c = pd.to_numeric(df_raw.iloc[:, 6], errors="coerce")
        v = pd.to_numeric(df_raw.iloc[:, 9], errors="coerce")
        df = pd.DataFrame({"date": d, "open": o, "high": h, "low": l, "close": c, "volume": v})
        df = df.dropna(subset=["date", "close"]).reset_index(drop=True)
        df["volume"] = df["volume"].fillna(0)
        if code is None:
            for val in df_raw.iloc[:, 0]:
                m2 = re.search(r"(\d{6})", str(val))
                if m2:
                    code = m2.group(1)
                    break
        if code is None:
            code = "000000"
        return {"code": code, "df": df[["date", "open", "close", "high", "low", "volume"]]}
    else:
        # 格式 A / B：逐行扫描有效日期
        for idx, row in df_raw.iterrows():
            date_val = close_val = None
            val2 = row[2] if n_cols > 2 else None
            if pd.notna(val2):
                try:
                    d = pd.to_datetime(val2)
                    if d.year >= 2000:
                        c = row[3] if n_cols > 3 else None
                        if pd.notna(c) and isinstance(c, (int, float)):
                            date_val, close_val = d, float(c)
                except Exception:
                    pass
            if date_val is None:
                val0 = row[0]
                if pd.notna(val0):
                    try:
                        d = pd.to_datetime(val0)
                        if d.year >= 2000:
                            c = row[1] if n_cols > 1 else None
                            if pd.notna(c) and isinstance(c, (int, float)):
                                date_val, close_val = d, float(c)
                    except Exception:
                        pass
            if date_val is not None and close_val is not None:
                dates.append(date_val)
                closes.append(close_val)

    if len(dates) == 0:
        raise ValueError(f"无法从 {fname} 解析出有效行情数据")

    df = pd.DataFrame({
        "date": pd.to_datetime(dates), "close": closes,
    }).dropna().sort_values("date").reset_index(drop=True)
    df["open"] = df["close"].shift(1).fillna(df["close"])
    df["high"] = df[["open", "close"]].max(axis=1) * 1.005
    df["low"] = df[["open", "close"]].min(axis=1) * 0.995
    df["volume"] = 0

    if code is None:
        code = "000000"
    return {"code": code, "df": df[["date", "open", "close", "high", "low", "volume"]]}


def import_choice_file(file_path: str | Path) -> dict:
    """解析并写入 Choice 缓存目录，返回结果摘要。"""
    parsed = parse_choice_excel(file_path)
    code = parsed["code"]
    df = parsed["df"]
    path = _csv_path("choice", code)
    _write_csv(path, df)
    last_date = df["date"].iloc[-1].strftime("%Y-%m-%d")
    name = CODE2NAME.get(code, code)
    upsert_meta(code, name, "choice", last_date, len(df))
    return {"code": code, "name": name, "rows": len(df),
            "start": df["date"].iloc[0].strftime("%Y-%m-%d"),
            "end": last_date, "path": str(path)}


# ============ 新鲜度检查 ============

def freshness_report() -> list:
    """返回所有池内 ETF 的数据状态。"""
    from .config import POOL
    rows = []
    expected = _trading_expected_date()  # 最近交易日(近似)；周末/节假日不再误报“不新鲜”
    for name, info in POOL.items():
        code = info["code"]
        meta = {m["code"]: m for m in list_meta()}.get(code)
        # 选「最新日期」的来源，而不是固定顺序（东财被反爬时会走腾讯，腾讯数据更新）
        best = None  # (last_date, df)
        for src in ("eastmoney", "akshare", "tencent", "choice"):
            df = _read_csv(_csv_path(src, code))
            if len(df) == 0:
                continue
            d = df["date"].iloc[-1].strftime("%Y-%m-%d")
            if best is None or d > best[0]:
                best = (d, df)
        if best is None:
            legacy = LEGACY_DIR / "cache" / f"{code}.csv"
            df = _read_csv(legacy)
            best = (df["date"].iloc[-1].strftime("%Y-%m-%d"), df) if len(df) else (None, df)
        last_date, df = best
        source = meta["source"] if meta else ("legacy" if last_date else "none")
        rows.append({
            "name": name, "code": code, "rows": len(df),
            "last_date": last_date, "source": source,
            "fresh": last_date == expected,
            "buy_th": info["buy_th"], "sell_th": info["sell_th"],
        })
    return rows


# ============ 缓存清理 ============

def remove_cache(code: str):
    """删除某代码所有来源的缓存文件。code 必须是 6 位数字，防路径穿越。"""
    if not re.fullmatch(r"\d{6}", code or ""):
        return []
    removed = []
    for src in ("eastmoney", "akshare", "tencent", "choice"):
        path = _csv_path(src, code)
        if path.exists():
            path.unlink()
            removed.append(str(path))
    return removed


def remove_garbage():
    """清理非法缓存文件（代码非6位数字），如旧的 日期.csv。"""
    removed = []
    for src_dir in (EASTMONEY_DIR, AKSHARE_DIR, TENCENT_DIR, CHOICE_DIR):
        for f in src_dir.glob("*.csv"):
            if not re.fullmatch(r"\d{6}\.csv", f.name):
                f.unlink()
                removed.append(str(f))
        # 原子写盘中断残留的 *.tmp 一并清理
        for f in src_dir.glob("*.csv.tmp"):
            try:
                f.unlink()
                removed.append(str(f))
            except OSError:
                pass
    return removed
