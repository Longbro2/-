# -*- coding: utf-8 -*-
"""
验证状态模块 — 给每只 ETF 打上"样本外验证"标签
数据来源: data/optimize_report_new.json（新权重全池样本外优化）
用途: 信号表展示"验证状态"，操作建议参考长期可靠性
"""
import json
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"
REPORT_FILE = DATA_DIR / "optimize_report_new.json"

# 验证状态缓存
_cache = None


def load_verify_map() -> dict:
    """返回 {code: {test_sharpe, verdict, buy_th, sell_th, label}}"""
    global _cache
    if _cache is not None:
        return _cache
    _cache = {}
    if not REPORT_FILE.exists():
        return _cache
    try:
        rep = json.loads(REPORT_FILE.read_text(encoding="utf-8"))
        for r in rep.get("results", []):
            code = r["code"]
            # 兼容两种结构: 嵌套 r["test"]["sharpe"] 或平铺 r["test_sharpe"]
            if isinstance(r.get("test"), dict):
                test_sharpe = r["test"].get("sharpe", 0)
            else:
                test_sharpe = r.get("test_sharpe", 0)
            if test_sharpe is None:
                test_sharpe = 0
            test_sharpe = float(test_sharpe)
            ev = r.get("evaluation") or {}
            if ev.get("insufficient"):
                # 测试期无成交/区间过短：属于“评估不足”，不能据此判定策略无效
                verdict, label = "insufficient", "⚠ 评估不足"
            elif not r.get("score_config") or "evaluation" not in r:
                # 修复前生成的旧报告：未按新因子/风控/预热口径重评 → 明确标记不可比
                verdict, label = "stale", "⚠ 旧口径待重评"
            elif test_sharpe > 0.5:
                verdict, label = "valid", "✅ 有效"
            elif test_sharpe > 0:
                verdict, label = "weak", "⚠️ 一般"
            else:
                verdict, label = "invalid", "❌ 无效"
            _cache[code] = {
                "test_sharpe": round(test_sharpe, 2),
                "verdict": verdict,
                "label": label,
                "insufficient": bool(ev.get("insufficient")),
                "stale": ("evaluation" not in r or not r.get("score_config")),
                "score_config": r.get("score_config"),
                "evaluation": r.get("evaluation"),
                "buy_th": r.get("buy_th"),
                "sell_th": r.get("sell_th"),
                "train_sharpe": r.get("train", {}).get("sharpe") if isinstance(r.get("train"), dict) else None,
                "total_return": r.get("all", {}).get("total_return") if isinstance(r.get("all"), dict) else r.get("total_return"),
            }
    except Exception as e:
        print(f"  [warn] 验证状态加载失败: {e}")
    return _cache


def get_verify(code: str) -> dict:
    """单只 ETF 的验证状态；无数据则返回 数据不足"""
    v = load_verify_map().get(code)
    if v is None:
        return {"test_sharpe": None, "verdict": "nodata",
                "label": "❓ 数据不足", "buy_th": None, "sell_th": None}
    return v


def verdict_to_badge(v: str) -> str:
    """验证状态 → 前端 badge class"""
    return {"valid": "badge-ok", "weak": "badge-warn", "invalid": "badge-danger",
            "insufficient": "badge-warn", "stale": "badge-neutral",
            "nodata": "badge-neutral"}.get(v, "badge-neutral")


def annotate_signals(signals: list) -> list:
    """给信号列表附加验证状态字段"""
    vmap = load_verify_map()
    for s in signals:
        v = vmap.get(s["code"])
        if v:
            s["verify"] = v["verdict"]
            s["verify_label"] = v["label"]
            s["test_sharpe"] = v["test_sharpe"]
        else:
            s["verify"] = "nodata"
            s["verify_label"] = "❓ 数据不足"
            s["test_sharpe"] = None
    return signals


def annotate_holdings(holdings: list) -> list:
    """给持仓列表附加验证状态字段"""
    vmap = load_verify_map()
    for h in holdings:
        v = vmap.get(h["code"])
        if v:
            h["verify"] = v["verdict"]
            h["verify_label"] = v["label"]
            h["test_sharpe"] = v["test_sharpe"]
        else:
            h["verify"] = "nodata"
            h["verify_label"] = "❓ 数据不足"
            h["test_sharpe"] = None
    return holdings
