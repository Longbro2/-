# -*- coding: utf-8 -*-
"""
CherryQuant Web — 宏观瞭望模块
六块内容：
  1. 隔夜外盘：美股三大指数 + 关键商品（铜/金/油）实时行情
  2. A股主要指数：上证/深成/创业板/科创50/沪深300/中证500
  3. 港股/亚太：恒生指数/恒生科技/国企指数
  4. 风险情绪：VIX恐慌指数 + 美元指数 + 人民币汇率
  5. 美股龙头个股：哪些涨了哪些跌了，映射到 A股板块
  6. 重要事件日历：可配置的宏观/行业事件（框架就绪，数据手动维护）

数据源：腾讯行情接口（qt.gtimg.cn，已验证可用）
事件：config.py 的 MACRO_CALENDAR 配置
"""
import json
import re
import time
from datetime import datetime
from pathlib import Path

import requests

# ============ TTL 结果缓存 ============
# 宏观瞭望数据来自腾讯实时接口，每次请求联网需 2s+。
# 但外盘/指数/情绪都是日频或隔夜数据，日内变化不大。
# 给联网拉取加短时缓存（默认 30 分钟），大幅提速；刷新缓存用 force=True。
_CACHE = {}  # key -> (expire_ts, value)


def _cached(ttl: int = 1800):
    """TTL 结果缓存装饰器。key=函数名。同窗口内命中缓存，否则重算。"""
    def deco(fn):
        def wrapper(*a, force: bool = False, **kw):
            key = fn.__name__
            now = time.time()
            hit = _CACHE.get(key)
            if not force and hit and hit[0] > now:
                return hit[1]
            val = fn(*a, **kw)
            _CACHE[key] = (now + ttl, val)
            return val
        return wrapper
    return deco

# ============ 行情数据源 ============
QT_URL = "https://qt.gtimg.cn/q={}"

# 关注的外盘/商品代码
# usDJI道指 usIXIC纳指 usINX标普 hf_CAD伦敦铜(COMEX铜) hf_XAU国际黄金 hf_CL原油
GLOBAL_WATCH = {
    "usDJI": {"name": "道琼斯", "market": "美股"},
    "usIXIC": {"name": "纳斯达克", "market": "美股"},
    "usINX": {"name": "标普500", "market": "美股"},
    "hf_CAD": {"name": "COMEX铜", "market": "商品"},
    "hf_XAU": {"name": "国际黄金", "market": "商品"},
    "hf_CL": {"name": "WTI原油", "market": "商品"},
}

# A股主要指数（s_ 前缀，腾讯 12 字段格式: [3]=现价 [4]=涨跌额 [5]=涨跌幅%）
CN_INDEX_WATCH = {
    "s_sh000001": {"name": "上证指数"},
    "s_sz399001": {"name": "深证成指"},
    "s_sz399006": {"name": "创业板指"},
    "s_sh000688": {"name": "科创50"},
    "s_sh000300": {"name": "沪深300"},
    "s_sh000905": {"name": "中证500"},
}

# 港股/亚太（71-78字段格式: [3]=现价 [4]=昨收）
ASIA_WATCH = {
    "hkHSI": {"name": "恒生指数", "a_sector": "港股/科技"},
    "hkHSTECH": {"name": "恒生科技", "a_sector": "港股科技/互联网", "a_code": ["513010", "513180"]},
    "hkHSCEI": {"name": "国企指数", "a_sector": "港股/中字头"},
}

# 风险情绪指标（VIX/美元指数）
SENTIMENT_WATCH = {
    "usVIX": {"name": "VIX恐慌指数", "note": "VIX>25市场恐慌，<15过度乐观"},
}
# 美元指数（腾讯代码）
USD_INDEX_CODE = "usDINIW"

# 美股科技/龙头个股跟踪（V11 新增：看哪些涨了哪些跌了）
# code: 腾讯美股代码, name: 简称, a_sector: 对A股对应板块
US_STOCKS = {
    "usNVDA": {"name": "英伟达", "a_sector": "半导体/算力", "a_code": ["159558", "588170", "515880"]},
    "usAAPL": {"name": "苹果", "a_sector": "消费电子", "a_code": []},
    "usMSFT": {"name": "微软", "a_sector": "软件/云计算", "a_code": ["515230", "516510"]},
    "usGOOGL": {"name": "谷歌", "a_sector": "AI/云计算", "a_code": ["159819"]},
    "usMETA": {"name": "Meta", "a_sector": "AI应用/算力", "a_code": []},
    "usTSLA": {"name": "特斯拉", "a_sector": "新能源车", "a_code": ["516160"]},
    "usAMD": {"name": "AMD", "a_sector": "半导体/算力", "a_code": ["159558", "512480"]},
    "usAVGO": {"name": "博通", "a_sector": "半导体/算力", "a_code": ["159558"]},
    "usNFLX": {"name": "奈飞", "a_sector": "传媒/流媒体", "a_code": []},
    "usAMZN": {"name": "亚马逊", "a_sector": "云计算/电商", "a_code": ["516510"]},
    "usSMCI": {"name": "超微电脑", "a_sector": "AI服务器", "a_code": ["159558"]},
    "usMU": {"name": "美光", "a_sector": "存储芯片", "a_code": ["159558", "589130"]},
    "usINTC": {"name": "英特尔", "a_sector": "半导体", "a_code": ["159558"]},
    "usQCOM": {"name": "高通", "a_sector": "半导体", "a_code": ["159558"]},
    "usCRM": {"name": "Salesforce", "a_sector": "软件/云计算", "a_code": ["515230"]},
    "usADBE": {"name": "Adobe", "a_sector": "软件", "a_code": ["515230"]},
}

# 关键商品对应A股板块
COMMODITY_MAP = {
    "hf_CAD": {"sector": "有色金属", "desc": "铜价涨→有色ETF利好，铜价跌→有色承压"},
    "hf_XAU": {"sector": "黄金", "desc": "金价涨→黄金ETF利好"},
    "hf_CL": {"sector": "能源", "desc": "油价涨→石油/能源利好"},
}

# ============ 事件日历（可配置，config.py 维护）============
# 结构: {date, end, name, type(宏观/行业/财报), impact: [{sector, direction(利好/利空), note}]}
MACRO_EVENTS = [
    # 以下是示例，需根据实际新闻更新
    # {
    #     "date": "2026-08-15", "name": "美国精炼铜关税裁决",
    #     "type": "宏观",
    #     "impact": [
    #         {"sector": "有色金属", "direction": "利好", "note": "若加税落地铜价上涨"},
    #         {"sector": "有色金属", "direction": "利空", "note": "若落空库存回流铜价回落"},
    #     ],
    # },
]


def fetch_global_markets() -> list:
    """拉取外盘/商品实时行情"""
    codes = ",".join(GLOBAL_WATCH.keys())
    try:
        r = requests.get(QT_URL.format(codes), timeout=8,
                         headers={"User-Agent": "Mozilla/5.0"})
        r.encoding = "gbk"
    except Exception as e:
        return [{"name": k, "error": str(e)} for k in GLOBAL_WATCH]

    result = []
    for line in r.text.strip().split(";"):
        if "=" not in line or "~" not in line:
            continue
        m = re.match(r'v_(\w+)="(.*)"', line.strip())
        if not m:
            continue
        code = m.group(1)
        parts = m.group(2).split("~")
        if code not in GLOBAL_WATCH or len(parts) < 5:
            continue
        info = GLOBAL_WATCH[code]
        # 腾讯美股格式: [0]~[1]名称~[2]代码~[3]现价~[4]昨收~[5]今开...
        try:
            price = float(parts[3])
            prev_close = float(parts[4])
            change = price - prev_close
            change_pct = change / prev_close * 100 if prev_close else 0
        except (ValueError, IndexError):
            continue

        item = {
            "code": code, "name": info["name"], "market": info["market"],
            "price": round(price, 2), "change": round(change, 2),
            "change_pct": round(change_pct, 2),
        }
        # 商品附加板块影响
        if code in COMMODITY_MAP:
            cm = COMMODITY_MAP[code]
            item["sector"] = cm["sector"]
            item["sector_desc"] = cm["desc"]
            item["sector_impact"] = "利好" if change_pct > 0.5 else ("利空" if change_pct < -0.5 else "中性")
        result.append(item)
    return result


def fetch_cn_indices() -> list:
    """拉取 A股主要指数（s_ 前缀，12字段: [3]=现价 [4]=涨跌额 [5]=涨跌幅%）"""
    codes = ",".join(CN_INDEX_WATCH.keys())
    try:
        r = requests.get(QT_URL.format(codes), timeout=8,
                         headers={"User-Agent": "Mozilla/5.0"})
        r.encoding = "gbk"
    except Exception as e:
        return [{"name": k, "error": str(e)} for k in CN_INDEX_WATCH]

    result = []
    for line in r.text.strip().split(";"):
        if "=" not in line or "~" not in line:
            continue
        m = re.match(r'v_(\w+)="(.*)"', line.strip())
        if not m:
            continue
        code = m.group(1)
        parts = m.group(2).split("~")
        if code not in CN_INDEX_WATCH or len(parts) < 6:
            continue
        try:
            price = float(parts[3])
            change = float(parts[4])
            change_pct = float(parts[5])
        except (ValueError, IndexError):
            continue
        result.append({
            "code": code, "name": CN_INDEX_WATCH[code]["name"],
            "market": "A股指数", "price": round(price, 2),
            "change": round(change, 2), "change_pct": round(change_pct, 2),
        })
    return result


def fetch_asia_markets() -> list:
    """拉取港股/亚太指数（71字段: [3]=现价 [4]=昨收）"""
    codes = ",".join(ASIA_WATCH.keys())
    try:
        r = requests.get(QT_URL.format(codes), timeout=8,
                         headers={"User-Agent": "Mozilla/5.0"})
        r.encoding = "gbk"
    except Exception as e:
        return [{"name": k, "error": str(e)} for k in ASIA_WATCH]

    result = []
    for line in r.text.strip().split(";"):
        if "=" not in line or "~" not in line:
            continue
        m = re.match(r'v_(\w+)="(.*)"', line.strip())
        if not m:
            continue
        code = m.group(1)
        parts = m.group(2).split("~")
        if code not in ASIA_WATCH or len(parts) < 5:
            continue
        info = ASIA_WATCH[code]
        try:
            price = float(parts[3])
            prev_close = float(parts[4])
            change = price - prev_close
            change_pct = change / prev_close * 100 if prev_close else 0
        except (ValueError, IndexError):
            continue
        item = {
            "code": code, "name": info["name"], "market": "港股/亚太",
            "price": round(price, 2), "change": round(change, 2),
            "change_pct": round(change_pct, 2),
            "a_sector": info["a_sector"], "a_code": info.get("a_code", []),
        }
        result.append(item)
    return result


def fetch_sentiment() -> list:
    """拉取风险情绪指标：VIX + 美元指数 + 人民币汇率"""
    codes = ",".join(SENTIMENT_WATCH.keys()) + "," + USD_INDEX_CODE
    try:
        r = requests.get(QT_URL.format(codes), timeout=8,
                         headers={"User-Agent": "Mozilla/5.0"})
        r.encoding = "gbk"
    except Exception as e:
        return [{"name": k, "error": str(e)} for k in SENTIMENT_WATCH] + \
               [{"name": "美元指数", "error": str(e)}]

    result = []
    for line in r.text.strip().split(";"):
        if "=" not in line or "~" not in line:
            continue
        m = re.match(r'v_(\w+)="(.*)"', line.strip())
        if not m:
            continue
        code = m.group(1)
        parts = m.group(2).split("~")
        if code not in SENTIMENT_WATCH and code != USD_INDEX_CODE:
            continue
        if code == USD_INDEX_CODE:
            name = "美元指数"
            note = "美元走强→压制黄金/有色，走弱→利好商品"
        else:
            name = SENTIMENT_WATCH[code]["name"]
            note = SENTIMENT_WATCH[code]["note"]
        if len(parts) < 5:
            continue
        try:
            price = float(parts[3])
            prev_close = float(parts[4])
            change = price - prev_close
            change_pct = change / prev_close * 100 if prev_close else 0
        except (ValueError, IndexError):
            continue
        result.append({
            "code": code, "name": name, "market": "风险情绪",
            "price": round(price, 2), "change": round(change, 2),
            "change_pct": round(change_pct, 2), "note": note,
        })
    return result


def fetch_us_stocks() -> list:
    """拉取美股龙头个股行情，标注对A股板块的影响。
    返回: [{code, name, price, change_pct, a_sector, impact, a_code}]
    """
    codes = ",".join(US_STOCKS.keys())
    try:
        r = requests.get(QT_URL.format(codes), timeout=8,
                         headers={"User-Agent": "Mozilla/5.0"})
        r.encoding = "gbk"
    except Exception as e:
        return [{"name": k, "error": str(e)} for k in US_STOCKS]

    result = []
    for line in r.text.strip().split(";"):
        if "=" not in line or "~" not in line:
            continue
        m = re.match(r'v_(\w+)="(.*)"', line.strip())
        if not m:
            continue
        code = m.group(1)
        parts = m.group(2).split("~")
        if code not in US_STOCKS or len(parts) < 5:
            continue
        info = US_STOCKS[code]
        try:
            price = float(parts[3])
            prev_close = float(parts[4])
            change = price - prev_close
            change_pct = change / prev_close * 100 if prev_close else 0
        except (ValueError, IndexError):
            continue

        # 影响判断：涨>1%利好，跌>1%利空
        if change_pct > 1.0:
            impact = "利好"
        elif change_pct < -1.0:
            impact = "利空"
        else:
            impact = "中性"

        result.append({
            "code": code, "name": info["name"],
            "price": round(price, 2), "change_pct": round(change_pct, 2),
            "a_sector": info["a_sector"],
            "a_code": info["a_code"],
            "impact": impact,
        })
    # 按涨跌幅排序（涨的先，跌的显示清楚）
    result.sort(key=lambda x: -x.get("change_pct", 0))
    return result


def get_upcoming_events(days: int = 30, include_past: int = 7) -> list:
    """
    返回事件：未来 days 天内 + 过去 include_past 天内（已落地的重要事件也展示）
    """
    from .config import MACRO_EVENTS as CONFIG_EVENTS
    events = CONFIG_EVENTS + MACRO_EVENTS
    today = datetime.now().date()
    upcoming = []
    for ev in events:
        try:
            ev_date = datetime.strptime(ev["date"], "%Y-%m-%d").date()
        except Exception:
            continue
        days_left = (ev_date - today).days
        # 未来 events 天内，或过去 include_past 天内的已发生事件
        if -include_past <= days_left <= days:
            item = {**ev, "days_left": days_left}
            if days_left < 0:
                item["status"] = "已发生"
            elif days_left == 0:
                item["status"] = "今日"
            else:
                item["status"] = "临近"
            upcoming.append(item)
    upcoming.sort(key=lambda x: x["days_left"])
    return upcoming


@_cached(ttl=1800)
def analyze_macro() -> dict:
    """
    宏观瞭望综合分析：(30分钟内缓存，避免每次请求重复联网拉5组外盘数据)
      markets: 外盘/商品行情
      cn_indices: A股主要指数
      asia: 港股/亚太指数
      sentiment: 风险情绪（VIX/美元指数）
      us_stocks: 美股龙头个股明细（哪些涨了哪些跌了）
      events: 临近事件
      summary: 一句话总结（利好/利空方向）
    """
    markets = fetch_global_markets()
    cn_indices = fetch_cn_indices()
    asia = fetch_asia_markets()
    sentiment = fetch_sentiment()
    us_stocks = fetch_us_stocks()
    events = get_upcoming_events()

    # 总结：统计外盘涨跌
    us_index = [m for m in markets if m["market"] == "美股"]
    commodities = [m for m in markets if m["market"] == "商品"]

    up = sum(1 for m in us_index if m.get("change_pct", 0) > 0)
    down = sum(1 for m in us_index if m.get("change_pct", 0) < 0)

    parts = []
    if up > down:
        parts.append(f"隔夜美股偏强（{up}涨{down}跌），科技/风险偏好回暖，利好A股科技、成长板块")
    elif down > up:
        parts.append(f"隔夜美股偏弱（{up}涨{down}跌），风险偏好承压，注意A股科技回调")
    else:
        parts.append("隔夜美股涨跌互现，方向不明，A股或震荡")

    # A股指数强弱
    cn_up = sum(1 for m in cn_indices if m.get("change_pct", 0) > 0)
    cn_down = sum(1 for m in cn_indices if m.get("change_pct", 0) < 0)
    if cn_up or cn_down:
        parts.append(f"A股指数{cn_up}涨{cn_down}跌")

    # 港股强弱（恒生科技直接关联持仓）
    hs_tech = next((a for a in asia if a["code"] == "hkHSTECH"), None)
    if hs_tech:
        ht = hs_tech["change_pct"]
        if ht > 0.5:
            parts.append(f"恒生科技+{ht}%走强，利好港股科技（你的恒生科技持仓）")
        elif ht < -0.5:
            parts.append(f"恒生科技{ht}%走弱，注意港股科技持仓波动")
        else:
            parts.append(f"恒生科技{ht}%平盘")

    # VIX 情绪
    vix = next((s for s in sentiment if s["code"] == "usVIX"), None)
    if vix:
        vix_pct = vix["change_pct"]
        if vix["price"] > 25:
            parts.append(f"⚠️ VIX恐慌指数{vix['price']:.1f}（高位），市场避险情绪浓，谨慎加仓")
        elif vix["price"] < 15:
            parts.append(f"VIX恐慌指数{vix['price']:.1f}（低位），市场乐观，注意情绪过热")
        else:
            parts.append(f"VIX恐慌指数{vix['price']:.1f}，市场情绪正常")

    # 美股个股：统计强势/弱势，映射到A股板块
    strong_us = [s for s in us_stocks if s.get("impact") == "利好"]
    weak_us = [s for s in us_stocks if s.get("impact") == "利空"]

    if strong_us:
        strong_sectors = set(s["a_sector"] for s in strong_us)
        parts.append(f"美股领涨：{'/'.join(s['name'] for s in strong_us[:4])} → 利好A股{'/'.join(strong_sectors)}")
    if weak_us:
        weak_sectors = set(s["a_sector"] for s in weak_us)
        parts.append(f"美股领跌：{'/'.join(s['name'] for s in weak_us[:4])} → 注意A股{'/'.join(weak_sectors)}回调")

    # 附加商品影响
    comm_notes = []
    for c in commodities:
        if c.get("sector_impact") == "利好":
            comm_notes.append(f"{c['name']}涨 → 利好{c.get('sector')}")
        elif c.get("sector_impact") == "利空":
            comm_notes.append(f"{c['name']}跌 → 利空{c.get('sector')}")
    if comm_notes:
        parts.append("；".join(comm_notes))

    summary = "；".join(parts)

    return {
        "markets": markets,
        "cn_indices": cn_indices,
        "asia": asia,
        "sentiment": sentiment,
        "us_stocks": us_stocks,
        "events": events,
        "summary": summary,
        "updated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
