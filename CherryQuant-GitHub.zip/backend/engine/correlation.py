# -*- coding: utf-8 -*-
"""
CherryQuant Web — 组合相关性分析
计算持仓/候选 ETF 之间的收益率相关性，识别重复持仓风险。
"""
import numpy as np
import pandas as pd

from .data import fetch
from . import db


def build_return_matrix(codes: list) -> pd.DataFrame:
    """构建多只 ETF 的日收益率矩阵"""
    rets = {}
    for c in codes:
        df = fetch(c, offline=True)
        if len(df) > 30:
            rets[c] = df.set_index("date")["close"].pct_change()
    if not rets:
        return pd.DataFrame()
    return pd.DataFrame(rets).dropna()


def correlation_matrix(codes: list = None) -> dict:
    """计算相关性矩阵，返回 {codes, names, corr_matrix, pairs}"""
    if codes is None:
        positions = db.load_positions()
        codes = list(positions.keys())
    if len(codes) < 2:
        return {"codes": codes, "corr": [], "pairs": [], "warnings": []}

    ret_df = build_return_matrix(codes)
    # 修复（第 22 项）：收益矩阵只有有数据的列；代码列表同步过滤后再算相关/配对
    missing_codes = [c for c in codes if c not in ret_df.columns]
    avail = [c for c in codes if c in ret_df.columns]
    if len(avail) < 2 or len(ret_df) < 20:
        return {"codes": avail, "available_codes": avail, "missing_codes": missing_codes,
                "corr": [], "pairs": [], "warnings": (
                    [f"缺少行情: {', '.join(missing_codes)}"] if missing_codes else [])}
    codes = avail
    ret_df = ret_df[codes]

    corr = ret_df.corr()
    names = {c: c for c in codes}

    # 生成高相关对
    pairs = []
    warnings = []
    for i in range(len(codes)):
        for j in range(i + 1, len(codes)):
            c1, c2 = codes[i], codes[j]
            v = corr.iloc[i, j]
            if abs(v) > 0.8:
                level = "高相关"
                warnings.append(f"{c1} 与 {c2} 相关性{v:.2f}，高度重复，不宜同时重仓")
            elif abs(v) > 0.6:
                level = "中相关"
            else:
                level = "低相关"
            pairs.append({
                "code1": c1, "code2": c2,
                "corr": round(float(v), 2), "level": level,
            })

    pairs.sort(key=lambda x: -abs(x["corr"]))
    return {
        "codes": codes,
        "available_codes": codes,
        "missing_codes": missing_codes,
        "coverage_days": len(ret_df),
        "corr": [[round(float(x), 2) for x in row] for row in corr.values],
        "pairs": pairs,
        "warnings": warnings,
    }


def correlation_penalty(portfolio_weights: list, codes: list) -> list:
    """
    给组合权重加相关性惩罚：与组合内其他标的高相关的，权重下调。
    portfolio_weights: [{code, weight, ...}] 现有组合优化结果
    codes: 组合内所有代码
    返回加了惩罚后的权重。
    """
    if len(codes) < 2:
        return portfolio_weights

    ret_df = build_return_matrix(codes)
    if len(ret_df) < 20:
        return portfolio_weights
    avail = [c for c in codes if c in ret_df.columns]
    if len(avail) < 2:
        return portfolio_weights
    ret_df = ret_df[avail]

    corr = ret_df.corr()
    # 每只标的与其他标的的平均相关度（只用有数据的标的）
    avg_corr = {}
    for c in avail:
        others = [x for x in avail if x != c]
        avg_corr[c] = corr.loc[c, others].abs().mean() if others else 0

    # 惩罚因子：相关度越高，权重降越多
    result = []
    for w in portfolio_weights:
        code = w["code"]
        ac = avg_corr.get(code, 0)
        # 惩罚系数: 1.0 - (相关度-0.3) * 0.4，相关度0.3以下不惩罚
        penalty = max(0.6, 1.0 - max(0, ac - 0.3) * 0.4)
        result.append({**w, "weight_adj": round(w["weight"] * penalty, 1),
                       "avg_corr": round(float(ac), 2)})

    # 重新归一化
    total = sum(x["weight_adj"] for x in result)
    if total > 0:
        for x in result:
            x["weight_adj"] = round(x["weight_adj"] / total * 100, 1)
    return result
