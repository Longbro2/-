# -*- coding: utf-8 -*-
"""
CherryQuant Web — 全局配置
路径、ETF 池、阈值等集中管理。
"""
import os
from pathlib import Path

# ============ 路径 ============
# config.py 位于 backend/engine/ → 父父父级 = quant-web
BASE_DIR = Path(__file__).resolve().parent.parent.parent   # D:\Projects\quant-web
DATA_DIR = BASE_DIR / "data"
CACHE_DIR = DATA_DIR / "cache"
EASTMONEY_DIR = CACHE_DIR / "eastmoney"
AKSHARE_DIR = CACHE_DIR / "akshare"
TENCENT_DIR = CACHE_DIR / "tencent"
CHOICE_DIR = CACHE_DIR / "choice"
UPLOAD_DIR = DATA_DIR / "uploads"
DB_PATH = DATA_DIR / "quant.db"
# 旧项目目录（迁移来源）：默认使用项目内的 _legacy 目录，可用环境变量 CHERRYQUANT_LEGACY_DIR 覆盖
LEGACY_DIR = Path(os.environ.get("CHERRYQUANT_LEGACY_DIR", str(BASE_DIR / "_legacy")))

for _d in [DATA_DIR, CACHE_DIR, EASTMONEY_DIR, AKSHARE_DIR, TENCENT_DIR, CHOICE_DIR, UPLOAD_DIR]:
    _d.mkdir(parents=True, exist_ok=True)

# ============ 数据源优先级 ============
# fetch 时依次尝试: 东财直连 → akshare → 腾讯行情 → Choice 缓存 → 旧缓存
SOURCE_ORDER = ["eastmoney", "akshare", "tencent", "choice"]

# 腾讯接口（作为东财/akshare 被反爬限制时的兜底）
TENCENT_KLINE_URL = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"

# 单次拉取 K 线数量（日线）。lmt 越大覆盖历史越长，但越慢。
# V4 优化：600→1500，覆盖约5年历史（2021-06至今），支持更长回测。
# 注意：腾讯接口上限约3000，1500是稳定值。
KLINE_LIMIT = 1500

# ============ ETF 池 ============
# buy_th/sell_th：2026-09-02 用修复后引擎重跑 refresh_verify_report.py 得到
# （前70%训练网格最优 / 后30%测试验证；引擎已修复：止损次日开盘成交、
# 资金流单位对齐、期末动量泄漏、移动止盈锁定）。数据不足(测试段交易为空)默认 50/20。
POOL = {
    # 原持仓/核心池
    "有色金属":   {"code":"516650","flow_5d":0.0,"flow_rank":3,"buy_th":50,"sell_th":35},
    "半导体设备": {"code":"159558","flow_5d":6.12,"flow_rank":1,"buy_th":45,"sell_th":35},
    "机器人":     {"code":"159530","flow_5d":-0.42,"flow_rank":7,"buy_th":65,"sell_th":35},
    "光伏":       {"code":"159857","flow_5d":0.0,"flow_rank":3,"buy_th":60,"sell_th":35},
    "电力":       {"code":"159611","flow_5d":0.0,"flow_rank":3,"buy_th":60,"sell_th":20},
    "军工":       {"code":"512660","flow_5d":0.0,"flow_rank":3,"buy_th":60,"sell_th":40},
    "医疗ETF":    {"code":"159828","flow_5d":0.0,"flow_rank":3,"buy_th":50,"sell_th":30},
    "消费ETF":    {"code":"560680","flow_5d":0.0,"flow_rank":3,"buy_th":45,"sell_th":20},
    "恒生科技":   {"code":"513010","flow_5d":0.0,"flow_rank":3,"buy_th":70,"sell_th":30},
    "电网设备":   {"code":"560390","flow_5d":0.0,"flow_rank":3,"buy_th":45,"sell_th":20},
    "航空航天":   {"code":"159227","flow_5d":0.0,"flow_rank":3,"buy_th":50,"sell_th":20},
    "科创芯片":   {"code":"589130","flow_5d":0.0,"flow_rank":3,"buy_th":60,"sell_th":20},
    "科创半导体": {"code":"588170","flow_5d":0.0,"flow_rank":3,"buy_th":70,"sell_th":20},
    # 自选新增
    "旅游ETF":    {"code":"562510","flow_5d":0.0,"flow_rank":3,"buy_th":45,"sell_th":20},
    "创新药":     {"code":"516080","flow_5d":0.0,"flow_rank":3,"buy_th":45,"sell_th":30},
    "港股创新":   {"code":"513120","flow_5d":0.0,"flow_rank":3,"buy_th":45,"sell_th":25},
    "医药ETF":    {"code":"512010","flow_5d":0.0,"flow_rank":3,"buy_th":55,"sell_th":20},
    "黄金ETF":    {"code":"518850","flow_5d":0.0,"flow_rank":3,"buy_th":60,"sell_th":20},
    "通信ETF":    {"code":"515880","flow_5d":0.0,"flow_rank":3,"buy_th":45,"sell_th":35},
    "软件ETF":    {"code":"515230","flow_5d":0.0,"flow_rank":3,"buy_th":60,"sell_th":35},
}

# 代码 → 名称 反查
CODE2NAME = {info["code"]: name for name, info in POOL.items()}

# ============ 风控参数 ============
RISK = {
    "stop_drawdown": -8.0,     # 从峰值回撤 8% 止损
    "stop_loss": -10.0,        # 相对成本亏 10% 止损
    "take_profit": 15.0,       # 固定止盈 +15%（保留）
    "trailing_activate": 8.0,  # 移动止盈：盈利超 8% 后激活
    "trailing_stop": -8.0,     # 移动止盈：从峰值回撤 8% 才卖
    "use_trailing_stop": True, # 默认启用移动止盈（让利润奔跑）
    # ===== 趋势自适应止盈（V3 优化）=====
    # 问题：固定 -8% 移动止盈在强趋势里卖飞主升浪（通信/有色/黄金 跑输买入持有 100%+）
    # 方案：60日动量越强，止盈线越宽，让利润奔跑；趋势弱时保持严格纪律
    "trend_adaptive": True,            # 是否启用趋势自适应止盈
    "trend_r60_threshold": 3.0,        # 60日动量>3%即视为强趋势（灵敏度测试最优）
    "trailing_stop_strong": -12.0,     # 强趋势时：从峰值回撤 12% 才卖（让利润奔跑）
    "trailing_activate_strong": 12.0,  # 强趋势时：盈利超 12% 才激活移动止盈
    "stop_drawdown_strong": -12.0,     # 强趋势时：峰值回撤 12% 才止损（容忍正常回调）
    "weekly_buy_limit": 1,     # 每周最多买入次数
}

# 交易参数（回测用）
TRADING = {
    "commission": 0.0003,      # 万三佣金
    "slippage": 0.001,         # 千一滑点
    "initial_capital": 100000,
}

# 评分长期趋势项（250日动量；A/B 实测 2026-09-05：全起点年化中位 +4.3%→+5.9%，
# 13个起点7好6差、回撤略升，属温和改善。已开启）
SCORE_LT_TERM = True

# 催化日历: 可配置的事件列表，用于前端提示"临近催化事件"
# 日期用 YYYY-MM-DD，每年需更新。codes 为受影响 ETF 代码列表。
CATALYST_CALENDAR = [
    {"date": "2026-08-19", "end": "2026-08-23", "name": "世界机器人大会", "codes": ["159530"]},
    {"date": "2026-08-26", "end": "2026-08-26", "name": "英伟达财报", "codes": ["159558"]},
    # 示例（需自行验证日期）:
    # {"date": "2026-09-01", "end": "2026-09-05", "name": "某行业大会", "codes": ["512660"]},
]

# 催化事件提前提示天数（在此天数内的事件在信号页展示）
CATALYST_LEAD_DAYS = 14

# ============ 宏观事件日历（宏观瞭望模块用） ============
# 结构: {date, end, name, type(宏观/行业/财报), impact: [{sector, direction(利好/利空), note}]}
MACRO_EVENTS = [
    # 美国精炼铜关税裁决（悬而未决，随时可能落地）
    {
        "date": "2026-08-31", "name": "美国精炼铜关税裁决",
        "type": "宏观",
        "impact": [
            {"sector": "有色金属", "direction": "利好", "note": "若加征关税落地，铜价可能再涨"},
            {"sector": "有色金属", "direction": "利空", "note": "若政策落空，前期囤铜回流，铜价回落"},
        ],
    },
    {
        "date": "2026-08-10", "name": "宇树科技新股申购",
        "type": "行业",
        "impact": [
            {"sector": "机器人", "direction": "利好", "note": "人形机器人产业链估值重塑"},
        ],
    },
    {
        "date": "2026-08-19", "name": "世界机器人大会",
        "type": "行业",
        "impact": [
            {"sector": "机器人", "direction": "利好", "note": "机器人产业链催化（瑞萨等海外厂商将首展具身智能方案）"},
        ],
    },
    # 已落地的重大政策（8/3-8/5新闻，标注为参考）
    {
        "date": "2026-08-03", "name": "新型电力系统'十五五'规划落地",
        "type": "宏观",
        "impact": [
            {"sector": "电网设备", "direction": "利好", "note": "电网投资5万亿开闸，特高压订单爆发"},
            {"sector": "电力", "direction": "利好", "note": "新型储能、配电网建设加速"},
        ],
    },
    {
        "date": "2026-08-04", "name": "第十二批药品集采'反内卷'",
        "type": "行业",
        "impact": [
            {"sector": "创新药", "direction": "利好", "note": "集采非新药原则，创新药受保护"},
        ],
    },
    # ===== 8/6 每日宏观瞭望新增（新浪7x24快讯整理） =====
    {
        "date": "2026-08-06", "name": "美伊博弈升级·避险金价创阶段新高",
        "type": "宏观",
        "impact": [
            {"sector": "有色金属", "direction": "利好", "note": "伦敦金突破4300美元/盎司，6月来首次；黄金ETF连续16日净流入93亿"},
            {"sector": "恒生科技", "direction": "利空", "note": "避险升温压制风险偏好，港股科技承压"},
        ],
    },
    {
        "date": "2026-08-06", "name": "港股科技板块大幅调整",
        "type": "行业",
        "impact": [
            {"sector": "恒生科技", "direction": "利空", "note": "恒生科技指数盘中跌超2%（4833点），恒指跌约1.9%，AI/半导体个股领跌"},
        ],
    },
    {
        "date": "2026-09-09", "end": "2026-09-13", "name": "服贸会健康卫生服务专题·未来医疗科技展",
        "type": "行业",
        "impact": [
            {"sector": "创新药", "direction": "利好", "note": "北京首钢园设'未来医疗科技产业前沿展区'，创新药/器械催化"},
        ],
    },
    {
        "date": "2026-08-06", "name": "多城研究住房消费提振·扩大消费'十五五'规划推进",
        "type": "宏观",
        "impact": [
            {"sector": "消费", "direction": "利好", "note": "规划7月批复发布，住房消费纳入大宗首位；今日多城谋划提振举措"},
        ],
    },
]
