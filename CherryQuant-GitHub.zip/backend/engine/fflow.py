# -*- coding: utf-8 -*-
"""
CherryQuant Web — 资金流因子模块
数据源: 东方财富资金流接口（push2his，未被反爬，可用）
字段: f51日期 f52主力净流入 f53小单 f54中单 f55大单 f56超大单
      f57主力占比% f58小单占比 f59中单占比 f60大单占比 f61超大单占比
      f62收盘价 f63涨跌幅%
"""
import os
import time
import requests
import pandas as pd
import numpy as np
from datetime import datetime
from pathlib import Path

from .config import DATA_DIR, CODE2NAME
from .data import _trading_expected_date

FFLOW_DIR = DATA_DIR / "cache" / "fflow"
FFLOW_DIR.mkdir(parents=True, exist_ok=True)

FFLOW_URL = "https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get"
FFLOW_FIELDS = "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61,f62,f63"

# 新浪备用源（东财限流/反爬时使用）。腾讯无资金流接口，故不做备选。
# 字段: r0_net=主力净流入(元), r0_ratio=主力占比, trade=收盘, changeratio=涨跌幅
SINA_FFLOW_URL = ("https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/"
                  "MoneyFlow.ssl_qsfx_zjlrqs?page=1&num=120&sort=opendate&asc=0&daima={sym}")


def _sina_symbol(code: str) -> str:
    return ("sh" if code.startswith(("5", "6")) else "sz") + code


def _fetch_fflow_sina(code: str) -> pd.DataFrame:
    """新浪资金流备用源。东财只提供约120天历史，新浪同为约120天。"""
    r = requests.get(
        SINA_FFLOW_URL.format(sym=_sina_symbol(code)),
        headers={"User-Agent": "Mozilla/5.0", "Referer": "https://finance.sina.com.cn/"},
        timeout=15,
    )
    r.raise_for_status()
    rows = r.json()
    if not rows:
        return pd.DataFrame()
    out = []
    for x in rows:
        out.append({
            "date": x["opendate"],
            "main_net": float(x["r0_net"]),
            # 新浪不提供按单子大小的拆分 → 填 0（评分只用 main_net / main_pct）
            "small_net": 0.0, "mid_net": 0.0, "big_net": 0.0, "super_net": 0.0,
            "main_pct": float(x["r0_ratio"]) * 100,
            "small_pct": 0.0, "mid_pct": 0.0, "big_pct": 0.0, "super_pct": 0.0,
            "close": float(x["trade"]),
            "pct_chg": float(x["changeratio"]) * 100,
        })
    df = pd.DataFrame(out)
    df["date"] = pd.to_datetime(df["date"])
    return df.sort_values("date").reset_index(drop=True)


def _secid(code: str) -> str:
    return f"1.{code}" if code.startswith(("5", "6")) else f"0.{code}"


# 资金流接口失败冷却记忆（东财偶尔反爬）
_FFLOW_FAIL = {}       # code -> (连续失败次数, 最后失败时间)
_FFLOW_COOL_SECS = 300 # 冷却5分钟
_FFLOW_MAX_RETRY = 3   # 每次最多重试3次


def _fflow_cooled(code: str) -> bool:
    """该标的是否在资金流冷却期"""
    cnt, ts = _FFLOW_FAIL.get(code, (0, 0))
    if cnt < _FFLOW_MAX_RETRY:
        return False
    return time.time() - ts < _FFLOW_COOL_SECS


def _fflow_mark_fail(code: str):
    cnt, _ = _FFLOW_FAIL.get(code, (0, 0))
    _FFLOW_FAIL[code] = (cnt + 1, time.time())


def _fflow_mark_ok(code: str):
    _FFLOW_FAIL.pop(code, None)


def fflow_freshness(code: str) -> dict:
    """资金流新鲜度状态（供信号层/前端展示）"""
    df = fetch_fflow(code, offline=True)
    k_date = None
    try:
        from .data import fetch
        k = fetch(code, offline=True)
        if len(k):
            k_date = k["date"].iloc[-1].strftime("%Y-%m-%d")
    except Exception:
        pass
    ff_date = df["date"].iloc[-1].strftime("%Y-%m-%d") if len(df) else None
    fresh = (ff_date == k_date) if (ff_date and k_date) else False
    lag_days = 0
    if ff_date and k_date:
        from datetime import date as _date
        lag_days = (_date.fromisoformat(k_date) - _date.fromisoformat(ff_date)).days
    return {
        "code": code,
        "fflow_date": ff_date,
        "kline_date": k_date,
        "fresh": fresh,
        "lag_days": lag_days,
        "status": "新鲜" if fresh else (f"滞后{lag_days}天" if lag_days > 0 else "缺数据"),
    }


def fetch_fflow(code: str, force: bool = False, offline: bool = False) -> pd.DataFrame:
    """
    拉取某 ETF 历史资金流数据。
    返回: [date, main_net, small_net, mid_net, big_net, super_net,
          main_pct, small_pct, mid_pct, big_pct, super_pct, close, pct_chg]
    含自动重试 + 失败冷却（东财反爬时避免反复白试）。
    """
    cache = FFLOW_DIR / f"{code}.csv"
    # 有今日缓存且不强制 → 直接用
    if not force and cache.exists():
        df = pd.read_csv(cache)
        if len(df) > 0:
            df["date"] = pd.to_datetime(df["date"])
        if len(df) > 0 and df['date'].iloc[-1].strftime("%Y-%m-%d") == _trading_expected_date():
            _fflow_mark_ok(code)
            return df
        # offline 模式：无今日数据也返回本地最新（不联网）
        if offline and len(df) > 0:
            return df
    if offline:
        if cache.exists():
            df = pd.read_csv(cache)
            if len(df) > 0:
                df["date"] = pd.to_datetime(df["date"])
            return df if len(df) > 0 else pd.DataFrame()
        return pd.DataFrame()

    # 冷却期内 → 用缓存（不反复白试）
    if _fflow_cooled(code):
        if cache.exists():
            df = pd.read_csv(cache)
            if len(df) > 0:
                df["date"] = pd.to_datetime(df["date"])
            return df if len(df) > 0 else pd.DataFrame()
        return pd.DataFrame()

    # 联网拉取 + 自动重试
    # lmt 曾为 600(≈2.4年)：更早年份的资金流在回测里整段缺失、每天被扣5分，
    # 与实盘口径不一致，造成回测早期系统性偏差。改 1500(≈6年) 对齐 KLINE_LIMIT。
    last_err = None
    for attempt in range(_FFLOW_MAX_RETRY):
        try:
            r = requests.get(
                FFLOW_URL,
                params={"lmt": "1500", "klt": "101", "secid": _secid(code),
                        "fields1": "f1,f2,f3,f7", "fields2": FFLOW_FIELDS},
                headers={"User-Agent": "Mozilla/5.0"}, timeout=10,
            )
            r.raise_for_status()
            data = r.json().get("data")
            if not data or not data.get("klines"):
                # 返回空 → 视为失败
                last_err = "空数据"
                _fflow_mark_fail(code)
                break
            rows = []
            for line in data["klines"]:
                p = line.split(",")
                rows.append({
                    "date": p[0], "main_net": float(p[1]), "small_net": float(p[2]),
                    "mid_net": float(p[3]), "big_net": float(p[4]), "super_net": float(p[5]),
                    "main_pct": float(p[6]), "small_pct": float(p[7]),
                    "mid_pct": float(p[8]), "big_pct": float(p[9]), "super_pct": float(p[10]),
                    "close": float(p[11]), "pct_chg": float(p[12]),
                })
            df = pd.DataFrame(rows)
            df["date"] = pd.to_datetime(df["date"])
            tmp = cache.with_suffix(cache.suffix + ".tmp")  # 原子写盘，防半截缓存
            df.to_csv(tmp, index=False)
            os.replace(tmp, cache)
            _fflow_mark_ok(code)
            return df
        except Exception as e:
            last_err = e
            _fflow_mark_fail(code)
            time.sleep(0.5 * (attempt + 1))  # 退避重试
    # 东财全部失败 → 尝试新浪备用源（腾讯无资金流接口）
    try:
        sdf = _fetch_fflow_sina(code)
        if len(sdf) > 0:
            tmp = cache.with_suffix(cache.suffix + ".tmp")
            sdf.to_csv(tmp, index=False)
            os.replace(tmp, cache)
            _fflow_mark_ok(code)
            print(f"  [info] 资金流 {code} 东财失败({last_err})，已改用新浪源 {len(sdf)} 行")
            return sdf
    except Exception as e2:
        print(f"  [warn] 资金流 {code} 新浪源也失败({e2})")

    # 两个源都失败 → 退回缓存
    if cache.exists():
        df = pd.read_csv(cache)
        if len(df) > 0:
            df["date"] = pd.to_datetime(df["date"])
        print(f"  [warn] 资金流 {code} 联网失败({last_err})，使用缓存")
        return df if len(df) > 0 else pd.DataFrame()
    return pd.DataFrame()


def add_fflow_factors(df: pd.DataFrame) -> pd.DataFrame:
    """
    给资金流数据添加衍生因子：
      main_net_5d: 5日主力净流入累计
      main_pct_5d: 5日主力净流入占比均值
      main_ratio:  主力净流入/成交额(用绝对值近似)
      main_signal: 主力连续净流入天数
    """
    df = df.copy()
    # 主力净流入占比滚动
    df["main_net_5d"] = df["main_net"].rolling(5).sum()
    df["main_pct_5d"] = df["main_pct"].rolling(5).mean()
    # 主力净流入方向: >0 净流入, <0 净流出
    df["main_positive"] = (df["main_net"] > 0).astype(int)
    # 连续净流入天数
    main_dir = np.sign(df["main_net"].fillna(0))
    streak = []
    cnt = 0
    for d in main_dir:
        if d > 0:
            cnt += 1
        elif d < 0:
            cnt = -1
        else:
            cnt = 0
        streak.append(cnt)
    df["main_streak"] = streak
    return df


def get_fflow_factor(code: str, df_fflow: pd.DataFrame, asof: pd.Timestamp = None) -> dict:
    """
    取资金流因子（供评分/展示）。
    asof: 指定取数日期（含）。信号用 T-1 日指标时，应传 T-1 日期，
          避免用到 T 日（未来）资金流 → 消除未来函数。
    若不传 asof，取最后一行。
    """
    if len(df_fflow) == 0:
        return {"date": None, "main_net": 0, "main_pct": 0, "main_net_5d": 0,
                "main_pct_5d": 0, "main_streak": 0}
    if asof is not None:
        # 取 <= asof 的最后一行（资金流与K线日期对齐）
        mask = df_fflow["date"] <= asof
        if mask.sum() == 0:
            return {"date": None, "main_net": 0, "main_pct": 0, "main_net_5d": 0,
                    "main_pct_5d": 0, "main_streak": 0}
        last = df_fflow.loc[mask].iloc[-1]
    else:
        last = df_fflow.iloc[-1]
    return {
        "date": last["date"].strftime("%Y-%m-%d") if hasattr(last["date"], "strftime") else str(last["date"]),
        "main_net": round(float(last["main_net"]) / 1e4, 1),   # 万元
        "main_pct": round(float(last["main_pct"]), 1),
        "main_net_5d": round(float(last.get("main_net_5d", 0)) / 1e4, 1),
        "main_pct_5d": round(float(last.get("main_pct_5d", 0)), 1),
        "main_streak": int(last.get("main_streak", 0)),
    }
