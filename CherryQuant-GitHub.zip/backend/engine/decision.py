# -*- coding: utf-8 -*-
"""
CherryQuant Web — 统一决策引擎
解决"仪表盘 / 每日信号 / 调仓 三处口径不一致"的矛盾。
所有模块（build_advice / instructions / optimizer）共用这里的判定逻辑，
保证同一只标的任何页面结论一致。

判定优先级（对持仓，从高到低）:
  1. 止损触发            → 卖出（纪律，最高优先）
  2. 止盈触发            → 止盈
  3. ML 强看空(<0.35)     → 警惕；若同时验证无效+亏损 → 减仓
  4. 验证无效 + 亏损      → 卖出（结构，腾资金）
  5. 验证有效 + BUY + 资金流入 → 加仓
  6. 信号极强(≥85+资金)   → 加仓
  7. 信号 SELL           → 卖出
  8. 其余                → 持有（验证无效不加仓）

判定优先级（对未持仓，从高到低）:
  1. ML 强看空            → 回避
  2. 验证有效 + BUY + 资金流入 + ML看多 → 买入（双共振）
  3. 验证有效 + BUY + 资金流入         → 买入
  4. ML看多但规则未到     → 关注
  5. 验证有效但信号未到   → 等待
  6. 信号 BUY 但验证无效  → 观望
  7. 其余                → 回避

priority 数值越小越紧急，用于跨模块统一排序。
"""
# 阈值（与 config/fflow 保持一致）
ML_STRONG_SELL = 0.35      # ML 强看空阈值
ML_STRONG_BUY = 0.65       # ML 强看多阈值
STRONG_SCORE = 85          # "信号极强"评分门槛
STRONG_FFLOW = 1000        # "资金大幅流入"门槛(万元)


def decide_holding(s: dict, pos: dict, verify: str, ml: dict | None = None) -> tuple:
    """
    统一持仓动作判定。
    s: 信号 dict {signal, score, main_net_5d, ...}
    pos: 持仓 dict {pnl_pct, status, ...}
    verify: 'valid'/'weak'/'invalid'/'nodata'
    ml: {proba, signal} 或 None
    返回 (action, reason, priority)
    """
    signal = s.get("signal", "?")
    score = s.get("score", 0)
    fflow5 = s.get("main_net_5d", 0)
    status = pos.get("status", "")
    pnl = pos.get("pnl_pct")
    v = verify or "nodata"
    ml_proba = (ml or {}).get("proba")
    ml_sig = (ml or {}).get("signal")

    # ---- 1. 止损/止盈纪律（最高优先，无条件执行） ----
    if status == "止损触发":
        return "卖出", "止损纪律触发，坚决执行", 0
    if status == "止盈触发":
        return "止盈", "止盈纪律触发，可落袋", 1

    # ---- 2. ML 强看空（否决权） ----
    if ml_proba is not None and ml_proba < ML_STRONG_SELL:
        if v == "invalid" and pnl is not None and pnl < 0:
            return "减仓", f"ML强看空(概率{ml_proba:.2f})且验证无效+亏损，降低暴露", 2
        return "警惕", f"ML强看空(概率{ml_proba:.2f})，即使BUY也不宜加仓，关注止损", 3

    # ---- 3. 验证无效 + 亏损 → 结构性卖出（腾资金到有效标的） ----
    if v == "invalid" and pnl is not None and pnl < 0:
        return "卖出", f"验证无效且亏损{pnl:.1f}%，长期可靠性差，腾出资金", 2
    if v == "invalid":
        return "持有", "验证无效，不加仓", 6

    # ---- 4. 验证有效 + BUY + 资金流入 → 加仓 ----
    if v == "valid" and signal == "BUY" and (fflow5 or 0) > 0:
        return "加仓", "验证有效+信号BUY+资金流入", 4

    # ---- 5. 信号极强（评分高+资金大） ----
    if signal == "BUY" and score >= STRONG_SCORE and (fflow5 or 0) > STRONG_FFLOW:
        return "加仓", "评分高(≥85)+资金大幅流入，趋势强", 4

    # ---- 6. ML 看空但规则未转弱 → 提示警惕 ----
    if ml_sig == "SELL" and signal != "SELL":
        return "警惕", "ML看空但规则未转弱，关注跌破止损", 5

    # ---- 7. 信号 SELL ----
    if signal == "SELL":
        return "卖出", "信号转SELL", 2

    # ---- 8. 默认持有 ----
    return "持有", "持仓状态正常", 9


def decide_buy(s: dict, verify: str, ml: dict | None = None) -> tuple:
    """
    统一未持仓（买入候选）动作判定。
    返回 (action, reason, priority)
    """
    signal = s.get("signal", "?")
    score = s.get("score", 0)
    fflow5 = s.get("main_net_5d", 0)
    v = verify or "nodata"
    ml_proba = (ml or {}).get("proba")
    ml_sig = (ml or {}).get("signal")

    # ---- 1. ML 强看空 → 回避 ----
    if ml_proba is not None and ml_proba < ML_STRONG_SELL:
        return "回避", f"ML强看空(概率{ml_proba:.2f})，不建议买入", 11

    # ---- 2. 双信号共振（规则+ML+资金）→ 强烈买入 ----
    if v == "valid" and signal == "BUY" and (fflow5 or 0) > 0 and ml_sig == "BUY":
        return "买入", "双信号共振：规则BUY+ML看多+资金流入", 4

    # ---- 3. 三条件 → 买入 ----
    if v == "valid" and signal == "BUY" and (fflow5 or 0) > 0:
        return "买入", "验证有效+信号BUY+资金流入", 4

    # ---- 4. ML 看多但规则未到 ----
    if ml_sig == "BUY" and signal != "BUY" and v == "valid":
        return "关注", "ML看多但规则信号未到，等回调", 7

    # ---- 5. 验证有效但信号未到 ----
    if v == "valid" and signal != "BUY":
        return "等待", "验证有效但信号未到BUY，等回调", 8

    # ---- 6. 信号 BUY 但验证无效 → 观望 ----
    if signal == "BUY" and v != "valid":
        return "观望", "信号BUY但验证无效，慎追", 10

    # ---- 7. 其余 → 回避 ----
    return "回避", "信号不强或验证无效", 11


def advice_group(action: str) -> str:
    """
    把统一决策的 action 映射到 build_advice 的分组。
    返回: buy / add / sell / hold / watch
    """
    if action in ("卖出", "止盈", "减仓"):
        return "sell"
    if action == "加仓":
        return "add"
    if action in ("买入",):
        return "buy"
    if action in ("持有",):
        return "hold"
    return "watch"  # 警惕 / 关注 / 等待 / 观望 / 回避


# 统一排序权重（越小越紧急），供所有列表排序
ORDER = {
    "卖出": 0, "止盈": 1, "减仓": 2, "加仓": 3, "买入": 4,
    "警惕": 5, "持有": 6, "关注": 7, "等待": 8, "观望": 10, "回避": 11,
}


def sort_key(inst: dict) -> tuple:
    """给指令/建议列表排序用：先按紧急度，再按评分降序。"""
    return (ORDER.get(inst.get("action", 9), 9), -inst.get("score", 0))
