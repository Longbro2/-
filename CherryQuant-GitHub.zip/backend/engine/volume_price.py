# -*- coding: utf-8 -*-
"""
CherryQuant Web — 量价关系分析模块
解决"短期排名选出了标的，但能不能现在买？会不会追高？"

核心方法（量价分析经典）：
  1. 放量上涨 = 健康（真实买盘进场）
  2. 缩量回调 = 健康（洗盘，后续可涨）
  3. 放量下跌 = 危险（主力出货）
  4. 缩量上涨 = 上涨乏力（无接盘）
  5. 高位放量滞涨 = 见顶风险

输出:
  trend: 短期趋势（上升/下降/震荡）
  volume_trend: 量能趋势（放量/缩量/平量）
  price_volume: 量价配合（健康/背离/危险）
  position: 位置（低位/中位/高位）
  health_score: 量价健康度 0-100
  entry_verdict: 进场判断（可买/观望/回避）
  reason: 解释
"""
import numpy as np
import pandas as pd

from .data import fetch
from .signals import calc_indicators


def analyze_price_volume(code: str) -> dict:
    """
    分析单只ETF的量价关系。
    返回进场判断（用于短期排名辅助决策）。
    """
    df = fetch(code, offline=True)
    if len(df) < 80:
        return {"error": "数据不足", "code": code}

    c = df["close"].values
    v = df["volume"].values

    # ---- 1. 短期趋势：MA5 vs MA20 ----
    ma5 = pd.Series(c).rolling(5).mean().values
    ma20 = pd.Series(c).rolling(20).mean().values
    if ma5[-1] > ma20[-1] and ma5[-3] > ma20[-3]:
        trend = "上升"
    elif ma5[-1] < ma20[-1] and ma5[-3] < ma20[-3]:
        trend = "下降"
    else:
        trend = "震荡"

    # ---- 2. 量能趋势：近5日均量 vs 前5日均量 ----
    vol_5 = np.mean(v[-5:])
    vol_prev5 = np.mean(v[-10:-5]) if len(v) >= 10 else vol_5
    vol_ratio = vol_5 / vol_prev5 if vol_prev5 > 0 else 1
    if vol_ratio > 1.3:
        volume_trend = "放量"
    elif vol_ratio < 0.7:
        volume_trend = "缩量"
    else:
        volume_trend = "平量"

    # ---- 3. 最近一天的量价配合 ----
    price_chg = (c[-1] / c[-2] - 1) * 100 if c[-2] > 0 else 0
    today_vol = v[-1]
    avg_vol = np.mean(v[-10:-1]) if len(v) > 10 else np.mean(v[:-1])
    vol_ratio_today = today_vol / avg_vol if avg_vol > 0 else 1

    if price_chg > 0.5 and vol_ratio_today > 1.2:
        pv_today = "放量上涨"       # 健康
    elif price_chg > 0.5 and vol_ratio_today < 0.8:
        pv_today = "缩量上涨"       # 乏力
    elif price_chg < -0.5 and vol_ratio_today > 1.2:
        pv_today = "放量下跌"       # 危险
    elif price_chg < -0.5 and vol_ratio_today < 0.8:
        pv_today = "缩量回调"       # 洗盘
    else:
        pv_today = "量价平稳"

    # ---- 4. 位置判断（近250日分位） ----
    lookback = min(250, len(c))
    low = c[-lookback:].min()
    high = c[-lookback:].max()
    position_pct = (c[-1] - low) / (high - low) * 100 if high > low else 50
    if position_pct < 30:
        position = "低位"
    elif position_pct < 70:
        position = "中位"
    else:
        position = "高位"

    # ---- 5. 量价健康度评分 ----
    score = 50
    # 趋势加分
    score += 10 if trend == "上升" else (-10 if trend == "下降" else 0)
    # 量价配合
    if pv_today == "放量上涨":
        score += 20      # 最佳
    elif pv_today == "缩量回调":
        score += 10      # 洗盘健康
    elif pv_today == "缩量上涨":
        score -= 10      # 乏力
    elif pv_today == "放量下跌":
        score -= 25      # 出货危险
    # 位置
    if position == "低位":
        score += 10      # 低位安全边际
    elif position == "高位":
        score -= 15      # 高位风险
    score = max(0, min(100, score))

    # ---- 6. 进场判断 ----
    if score >= 70:
        verdict, vcolor = "可买", "ok"
    elif score >= 50:
        verdict, vcolor = "观望", "warn"
    else:
        verdict, vcolor = "回避", "danger"

    reason_parts = []
    reason_parts.append(f"短期{trend}趋势")
    reason_parts.append(f"{volume_trend}")
    reason_parts.append(f"{pv_today}")
    reason_parts.append(f"位置{position}({position_pct:.0f}%分位)")
    reason = "，".join(reason_parts)

    return {
        "code": code,
        "trend": trend,
        "volume_trend": volume_trend,
        "pv_today": pv_today,
        "position": position,
        "position_pct": round(position_pct, 1),
        "vol_ratio": round(vol_ratio, 2),
        "health_score": score,
        "entry_verdict": verdict,
        "verdict_class": vcolor,
        "reason": reason,
    }


def analyze_batch(codes: list) -> dict:
    """批量分析多只ETF的量价关系"""
    results = {}
    for code in codes:
        try:
            results[code] = analyze_price_volume(code)
        except Exception as e:
            results[code] = {"error": str(e), "code": code}
    return {"results": results}


if __name__ == "__main__":
    import json
    from engine.config import POOL
    # 测试通信ETF和半导体设备
    for name, info in POOL.items():
        if info["code"] in ("515880", "159558", "159828"):
            r = analyze_price_volume(info["code"])
            print(f"【{name} {info['code']}】")
            print(json.dumps(r, ensure_ascii=False, indent=2))
            print()
