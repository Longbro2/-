# -*- coding: utf-8 -*-
"""
CherryQuant Web — 机器学习选股引擎
路线图第二步：用 sklearn 梯度提升(GradientBoostingClassifier) 替代规则评分。
复用现有因子（动量/RSI/MACD/均线/形态），学习"未来5日是否上涨"。

核心思路:
  1. 从 20 只 ETF 历史数据提取特征 + 标签(未来5日涨跌)
  2. 按时间切分训练/测试（前70%训练，后30%测试，无未来函数）
  3. 训练 GradientBoosting，输出上涨概率
  4. 概率 → 信号（阈值可调）
  5. 与规则评分对比样本外表现
"""
import numpy as np
import pandas as pd
from pathlib import Path

from .signals import calc_indicators
from .data import fetch
from .config import POOL

# 特征列（技术因子 + 资金流因子）
FEATURES = ["mom_5d", "rsi", "macd", "macd_signal", "ma5", "ma20", "ma50",
            "pat_w", "pat_div", "pat_brk", "macd_quality",
            "fflow_main_net_5d", "fflow_main_pct_5d", "fflow_main_net"]
FEATURES_NUM = ["mom_5d", "rsi", "macd", "macd_signal", "ma5", "ma20", "ma50"]

# 预测周期
HORIZON = 5


def build_dataset(horizon: int = HORIZON) -> tuple:
    """
    从所有池内 ETF 构建训练数据集。
    返回 (X, y, dates, codes, label_ends)，X=特征, y=未来horizon是否上涨(0/1)，
    label_ends=每条样本标签真正结束的交易日（用于训练/测试隔离）。
    注意: 用 lag=False 的原始指标（特征在当日已知），标签用未来收益。
    """
    from .fflow import fetch_fflow, add_fflow_factors
    X_list, y_list, date_list, code_list, label_end_list = [], [], [], [], []
    for name, info in POOL.items():
        df = fetch(info["code"], offline=True)
        if len(df) < 120:
            continue
        # 口径对齐（2026-11-08 修复）：实盘信号/ML 推理都用“最后一根已收盘 K 线”
        # 的技术指标（lag=False），训练必须一致。此前的 lag=True 会让特征比实际
        # 可用信息晚一天，且与实盘执行时点（D 收盘后 → D+1 开盘）不符。
        ind = calc_indicators(df, lag=False)
        close = df["close"]
        # 未来 horizon 收益（2026-11-08 修复）：
        # 特征取 T 日收盘后（含 T 日资金流），执行在 T+1 开盘买入、持有 horizon 个交易日后
        # 收盘卖出 → fwd_ret = close[T+1+horizon] / open[T+1] - 1。
        # 旧实现从 T 日开盘起算、却用 T 日整日资金流做特征 = 用了开盘时还不知道的信息。
        fwd_ret = close.shift(-(horizon + 1)) / df["open"].shift(-1) - 1
        # 每条样本的真实“标签结束日”（T+1 开盘买入、持有 horizon 个交易日后收盘卖出）。
        # 修复（GPT 复核 B/#15）：训练/测试隔离必须按“标签真正结束的交易日”判断，
        # 不能再按固定交易日数量切割 —— 不同标的/停牌/缺行情会让固定窗口失真，
        # 紧贴切点的训练样本标签窗口可能伸进测试期 → 样本外指标被未来信息污染。
        label_end = df["date"].shift(-(horizon + 1))
        # 标签: 未来5日涨>0.5% 记为 1，跌<-0.5% 记为 0（剔除横盘模糊区）
        y = pd.Series(np.where(fwd_ret > 0.005, 1, np.where(fwd_ret < -0.005, 0, np.nan)), index=df.index)

        feat = pd.DataFrame({f: pd.to_numeric(ind[f], errors="coerce") for f in FEATURES if f in ind.columns})

        # 资金流因子对齐
        ff = fetch_fflow(info["code"], offline=True)
        if len(ff) > 0:
            ff = add_fflow_factors(ff)
            ff["date"] = pd.to_datetime(ff["date"])
            ff_map = ff.set_index("date")[["main_net_5d", "main_pct_5d", "main_net"]]
            # 用 merge 对齐日期（同一天的资金流在 T 日收盘后已可得，
            # 用于 T+1 开盘买入 → 不存在未来函数）
            df_temp = df[["date"]].copy()
            df_temp["date_key"] = df_temp["date"]
            merged = df_temp.merge(ff_map.reset_index().rename(columns={"date": "date_key"}),
                                   on="date_key", how="left")
            feat["fflow_main_net_5d"] = merged["main_net_5d"].values
            feat["fflow_main_pct_5d"] = merged["main_pct_5d"].values
            feat["fflow_main_net"] = merged["main_net"].values
        else:
            for f in ["fflow_main_net_5d", "fflow_main_pct_5d", "fflow_main_net"]:
                feat[f] = np.nan

        tmp = feat.copy()
        tmp["y"] = y.values
        tmp["date"] = df["date"].values
        tmp["label_end"] = label_end.values
        tmp["code"] = info["code"]
        tmp = tmp.dropna(subset=["y"])

        if len(tmp) < 50:
            continue
        X_list.append(tmp[FEATURES])
        y_list.append(tmp["y"].astype(int))
        date_list.append(tmp["date"])
        code_list.append(tmp["code"])
        label_end_list.append(tmp["label_end"])
    if not X_list:
        return None
    X = pd.concat(X_list, ignore_index=True)
    y = pd.concat(y_list, ignore_index=True)
    dates = pd.concat(date_list, ignore_index=True)
    codes = pd.concat(code_list, ignore_index=True)
    label_ends = pd.concat(label_end_list, ignore_index=True)
    # 过滤 NaN 特征（资金流缺失的行去掉）
    mask = X.notna().all(axis=1)
    X, y, dates, codes = X[mask], y[mask], dates[mask], codes[mask]
    label_ends = label_ends[mask]
    # 关键修复：全局按日期排序后再切分训练/测试。
    # 旧实现按 ETF 块拼接后只按行数单一横切：切点只落在某一只代码内部，
    # 之前的代码整只进训练(含最新行情)、之后整只进测试(含最早行情)，
    # “样本外”混入截面泛化而非纯时序。
    if len(X) > 0:
        order = np.argsort(pd.to_datetime(dates), kind="stable")
        X, y, dates, codes = X.iloc[order], y.iloc[order], dates.iloc[order], codes.iloc[order]
        label_ends = label_ends.iloc[order]
    return X, y, dates, codes, label_ends


def time_split_indices(dates, label_ends, test_ratio: float = 0.3):
    """
    时间切分训练/测试索引（修复 GPT 复核 B/#15）。

    规则：
      - 测试集 = 排序后最后 test_ratio 比例的样本；test_start = min(测试样本 date)；
      - 训练集 = label_end < test_start（严格小于，标签恰好结束在测试首日的样本也剔除）。
    旧实现用“按交易日序号隔 embargo 根”的固定数量法：不同标的停牌/缺行情时，
    同一序号对应的真实标签结束日不同，仍可能有训练标签伸进测试期（未来函数）。
    返回 (train_idx, test_idx, test_start)。
    """
    dts = pd.to_datetime(dates).reset_index(drop=True).dt.normalize()
    le = pd.to_datetime(label_ends).reset_index(drop=True).dt.normalize()
    n = len(dts)
    split = max(1, min(n - 1, int(n * (1 - test_ratio)))) if n > 1 else 0
    test_start = dts.iloc[split]
    test_idx = np.where(dts.values >= np.datetime64(test_start))[0]
    le_vals = le.values
    mask = np.array([(not pd.isna(x)) for x in le_vals], dtype=bool)
    train_idx = np.where(mask & (le_vals < np.datetime64(test_start)))[0]
    return train_idx, test_idx, str(pd.Timestamp(test_start).date())


def train_model(test_ratio: float = 0.3):
    """
    训练 ML 模型，返回 (model, metrics)。
    metrics: 训练/测试集准确率、样本外预测的模拟回测夏普、隔离诊断字段。
    """
    from sklearn.ensemble import GradientBoostingClassifier
    from sklearn.metrics import accuracy_score

    data = build_dataset()
    if data is None:
        return None, {"error": "数据不足"}
    X, y, dates, codes, label_ends = data

    # 时间切分（防未来函数）：测试起点之后才是样本外；训练样本按“真实标签结束日”
    # 严格早于测试首日剔除（修复 GPT 复核 B/#15：不再用固定交易日数量法）。
    train_idx, test_idx, test_start = time_split_indices(dates, label_ends, test_ratio)
    if len(train_idx) == 0 or len(test_idx) == 0:
        return None, {"error": "训练/测试切分后样本为空",
                      "test_start": test_start,
                      "n_train": int(len(train_idx)), "n_test": int(len(test_idx))}
    X_train, y_train = X.iloc[train_idx], y.iloc[train_idx]
    X_test, y_test = X.iloc[test_idx], y.iloc[test_idx]

    # 训练
    model = GradientBoostingClassifier(
        n_estimators=100, max_depth=3, learning_rate=0.1,
        subsample=0.9, random_state=42,
    )
    model.fit(X_train, y_train)

    # 评估
    train_acc = accuracy_score(y_train, model.predict(X_train))
    test_acc = accuracy_score(y_test, model.predict(X_test))
    # 测试集概率
    proba = model.predict_proba(X_test)[:, 1]
    pred = model.predict(X_test)

    # 模拟回测：概率>0.55 看多，<0.45 看空（针对测试集）
    sim_ret = []
    test_dates = dates.iloc[test_idx].reset_index(drop=True)
    test_codes = codes.iloc[test_idx].reset_index(drop=True)
    # 简化：按天聚合平均预测
    df_sim = pd.DataFrame({"date": test_dates, "code": test_codes, "proba": proba, "pred": pred})
    df_sim["date"] = pd.to_datetime(df_sim["date"])

    # 隔离诊断：训练集最大标签结束日必须严格早于测试首日（可复核，不只是代码约定）
    le_train = pd.to_datetime(label_ends.iloc[train_idx]).max()
    le_train_str = str(pd.Timestamp(le_train).date()) if not pd.isna(le_train) else None
    return model, {
        "train_acc": round(float(train_acc), 4),
        "test_acc": round(float(test_acc), 4),
        "n_train": len(X_train), "n_test": len(X_test),
        "test_start": test_start,
        "max_train_label_end": le_train_str,
        "isolation_ok": (le_train_str is not None and le_train_str < test_start),
        "feature_importance": {f: round(float(imp), 4) for f, imp in
                               zip(FEATURES, model.feature_importances_)},
    }


def predict_proba_all(model, code: str = None) -> pd.DataFrame:
    """
    用训练好的模型预测池内 ETF 最新信号。
    返回每只最新一行的上涨概率。
    """
    if model is None:
        return pd.DataFrame()
    from .fflow import fetch_fflow, add_fflow_factors
    rows = []
    for name, info in POOL.items():
        if code and info["code"] != code:
            continue
        df = fetch(info["code"], offline=True)
        if len(df) < 120:
            continue
        # 与训练一致：用最后一根已收盘 K 线的指标（lag=False），
        # 信号在下一交易日开盘执行 → 无未来函数
        ind = calc_indicators(df, lag=False)
        last = ind.iloc[-1]
        feat = {f: last[f] for f in FEATURES if f in ind.columns}

        # 资金流因子对齐（与训练一致）
        ff = fetch_fflow(info["code"], offline=True)
        if len(ff) > 0:
            ff = add_fflow_factors(ff)
            ff["date"] = pd.to_datetime(ff["date"])
            # 取 <= 最新K线日期的资金流（避免未来函数）
            asof = df["date"].iloc[-1]
            ff_recent = ff[ff["date"] <= asof]
            if len(ff_recent) > 0:
                frow = ff_recent.iloc[-1]
                feat["fflow_main_net_5d"] = frow["main_net_5d"]
                feat["fflow_main_pct_5d"] = frow["main_pct_5d"]
                feat["fflow_main_net"] = frow["main_net"]
            else:
                feat["fflow_main_net_5d"] = np.nan
                feat["fflow_main_pct_5d"] = np.nan
                feat["fflow_main_net"] = np.nan
        else:
            feat["fflow_main_net_5d"] = np.nan
            feat["fflow_main_pct_5d"] = np.nan
            feat["fflow_main_net"] = np.nan

        if any(pd.isna(v) for v in feat.values()):
            continue
        X = pd.DataFrame([feat])[FEATURES]
        proba = model.predict_proba(X)[0][1]
        rows.append({"name": name, "code": info["code"], "proba": round(float(proba), 3),
                     "price": float(df["close"].iloc[-1])})
    return pd.DataFrame(rows)


# ============ 模型持久化 ============

def save_model(model):
    import joblib
    path = Path(__file__).resolve().parent.parent.parent / "data" / "ml_model.joblib"
    joblib.dump(model, path)
    return path


# 模型缓存（V10 性能优化）：首次加载后存内存，避免每次请求都 import sklearn + load joblib（约1.5s）
_model_cache = None
_model_cache_loaded = False


def reset_model_cache():
    """清除内存模型缓存。重训保存新模型后必须调用，否则同一进程内仍用旧模型。"""
    global _model_cache, _model_cache_loaded
    _model_cache = None
    _model_cache_loaded = False


def load_model(use_cache: bool = True):
    global _model_cache, _model_cache_loaded
    if use_cache and _model_cache_loaded:
        return _model_cache
    import joblib
    path = Path(__file__).resolve().parent.parent.parent / "data" / "ml_model.joblib"
    if path.exists():
        _model_cache = joblib.load(path)
        _model_cache_loaded = True
        return _model_cache
    _model_cache = None
    _model_cache_loaded = True
    return None
