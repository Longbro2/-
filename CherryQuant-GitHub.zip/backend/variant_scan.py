# -*- coding: utf-8 -*-
"""策略变体 A/B 扫描（离线，诚实口径）
在共享面板上跑 walk-forward 风格回测，对比：
  select: pit=点内验证有效过滤 | all=纯评分不筛
  topn:   3 | 5
  temp:   是否市场温度择时(>60满仓/40-60半仓/<40空仓)
  rebal:  每 20 / 40 个交易日调仓
评估窗口：全窗口(2020-06起) 与 近3.7年(2023起) —— 两个窗口都要好才算稳健。
全部交易含佣金(万3)+滑点(千1)。仅供研究，不自动改实盘参数。
"""
import sys
sys.path.insert(0, 'D:/Projects/quant-web/backend')
import itertools
import numpy as np
import pandas as pd
from engine.data import _read_csv, _csv_path
from engine.config import POOL
from research_common import score_series, pit_valid, buy_lot, sell_proceeds

print('加载数据并预计算分数（20 只，约需 20-40s）...')
all_data, all_scores, closes = {}, {}, {}
for name, info in POOL.items():
    code = info['code']
    df = _read_csv(_csv_path('tencent', code))
    if len(df) < 100:
        continue
    all_data[code] = df
    all_scores[code] = score_series(df)
    closes[code] = pd.Series(df['close'].values,
                             index=pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d'))

all_dates = set()
for s in all_scores.values():
    all_dates.update(s.index.strftime('%Y-%m-%d'))
dates = sorted(all_dates)
close_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
score_panel = pd.DataFrame(index=dates, columns=list(all_data.keys()), dtype=float)
for code, df in all_data.items():
    dstr = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
    close_panel.loc[dstr, code] = df['close'].values
    sc = all_scores[code]
    sc_idx = sc.index.strftime('%Y-%m-%d')
    score_panel.loc[sc_idx, code] = sc.values
print(f'面板就绪: {len(dates)} 天 ({dates[0]} ~ {dates[-1]})')


def run_variant(start, select, topn, temp_on, rebal):
    start_idx = next((i for i, d in enumerate(dates) if d >= start), 0)
    sub_dates = dates[start_idx:]
    n_days = len(sub_dates)
    if n_days < 120:
        return None
    equity = 100000.0
    holdings = {}
    nav = np.zeros(n_days)
    for j, d in enumerate(sub_dates):
        if j % rebal == 0:
            scores_today = score_panel.loc[d]
            close_today = close_panel.loc[d]
            available = {}
            avg = []
            for code in all_data.keys():
                sc = scores_today[code]
                px = close_today[code]
                if not np.isnan(sc) and not np.isnan(px) and px > 0:
                    available[code] = (sc, px)
                    avg.append(sc)
            market_temp = float(np.mean(avg)) if avg else 50.0
            ratio = 1.0
            if temp_on:
                ratio = 1.0 if market_temp > 60 else (0.5 if market_temp >= 40 else 0.0)
            # 先清算
            for code, sh in holdings.items():
                px = close_panel.loc[d, code]
                if not np.isnan(px):
                    equity += sell_proceeds(sh, float(px))
            holdings = {}
            if available and ratio > 0:
                if select == 'pit':
                    cand = [c for c in available if pit_valid(closes[c], d)]
                    selected = sorted(cand, key=lambda c: -available[c][0])[:topn] if len(cand) >= 3 \
                        else sorted(available.keys(), key=lambda c: -available[c][0])[:topn]
                else:
                    selected = sorted(available.keys(), key=lambda c: -available[c][0])[:topn]
                invest = equity * ratio
                if selected and invest > 0:
                    per = invest / len(selected)
                    for code in selected:
                        px = available[code][1]
                        sh, spend = buy_lot(per, float(px))
                        if sh > 0:
                            holdings[code] = sh
                            equity -= spend
        mv = equity
        for code, sh in holdings.items():
            px = close_panel.loc[d, code]
            if not np.isnan(px):
                mv += sh * float(px)
        nav[j] = mv
    nav = pd.Series(nav, index=sub_dates)
    total = (nav.iloc[-1] / nav.iloc[0] - 1) * 100
    years = (pd.Timestamp(sub_dates[-1]) - pd.Timestamp(sub_dates[0])).days / 365
    annual = ((nav.iloc[-1] / nav.iloc[0]) ** (1 / years) - 1) * 100 if years > 0 and nav.iloc[0] > 0 else 0
    r = nav.pct_change().dropna()
    sharpe = (r.mean() / r.std()) * np.sqrt(252) if r.std() > 0 else 0
    mdd = float(((nav / nav.cummax()) - 1).min() * 100)
    return {"total": total, "annual": annual, "sharpe": sharpe, "mdd": mdd, "years": years}


results = []
for select, topn, temp_on, rebal in itertools.product(['pit', 'all'], [3, 5], [False, True], [20, 40]):
    w1 = run_variant('2018-01-01', select, topn, temp_on, rebal)   # 全窗口(数据自2020-06)
    w2 = run_variant('2021-01-01', select, topn, temp_on, rebal)   # 近5.7年(含2021-2022熊市)
    w3 = run_variant('2023-01-01', select, topn, temp_on, rebal)   # 近3.7年
    if not w1 or not w2 or not w3:
        continue
    results.append({
        "variant": f"{'验证' if select=='pit' else '纯评分'} Top{topn} 温度{'开' if temp_on else '关'} 调仓{rebal}天",
        "full": w1, "near5": w2, "near3": w3,
        "score": w3["sharpe"] * 0.6 + w1["sharpe"] * 0.4,   # 兼顾两窗口的稳健分
    })

results.sort(key=lambda x: -x["score"])
print()
hdr = (f"{'变体':<34}{'全窗口总':>10}{'全窗口年化':>10}{'全窗口夏普':>10}{'全窗口回撤':>10}"
       f"{'近5.7总':>9}{'近5.7夏普':>9}{'近3.7总':>9}{'近3.7年化':>10}{'近3.7夏普':>9}{'近3.7回撤':>10}{'稳健分':>8}")
print(hdr)
print('-' * len(hdr))
for r in results:
    w1, w2, w3 = r["full"], r["near5"], r["near3"]
    print(f"{r['variant']:<34}"
          f"{w1['total']:+9.1f}%{w1['annual']:+9.1f}%{w1['sharpe']:10.2f}{w1['mdd']:+9.1f}%"
          f"{w2['total']:+8.1f}%{w2['sharpe']:9.2f}"
          f"{w3['total']:+8.1f}%{w3['annual']:+9.1f}%{w3['sharpe']:9.2f}{w3['mdd']:+9.1f}%{r['score']:8.3f}")
print()
print('说明: 全窗口数据起点 2020-06(腾讯缓存上限); 稳健分=0.6*近3.7夏普+0.4*全窗口夏普')
