# 资金流抓取（新浪备用源）→ data/cache/fflow/<code>.csv
# 东财 fflow 接口限流严重时使用；字段映射：
#   main_net = r0_net(主力净流入,元)  main_pct = r0_ratio*100  close = trade  pct_chg = changeratio*100
#   东财的大小单拆分(小/中/大/超大)新浪不提供 → 填 0（评分只用 main_net / main_pct）
$ErrorActionPreference = 'Continue'
$outDir = 'D:\Projects\quant-web\data\cache\fflow'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$ua = @{ 'User-Agent' = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'; 'Referer' = 'https://finance.sina.com.cn/' }
$codes = @('516650','159558','159530','159857','159611','512660','159828','560680','513010','560390','159227','589130','588170','562510','516080','513120','512010','518850','515880','515230')
$ok = 0
foreach ($code in $codes) {
    $sym = if ($code.StartsWith('5')) { "sh$code" } else { "sz$code" }
    $u = "https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/MoneyFlow.ssl_qsfx_zjlrqs?page=1&num=120&sort=opendate&asc=0&daima=$sym"
    $done = $false
    for ($try = 1; $try -le 3 -and -not $done; $try++) {
        try {
            $r = Invoke-WebRequest -Uri $u -Headers $ua -TimeoutSec 25 -UseBasicParsing
            $rows = $r.Content | ConvertFrom-Json
            if ($rows -and $rows.Count -gt 0) {
                $lines = @('date,main_net,small_net,mid_net,big_net,super_net,main_pct,small_pct,mid_pct,big_pct,super_pct,close,pct_chg')
                foreach ($x in ($rows | Sort-Object opendate)) {
                    $mn = [double]$x.r0_net
                    $mp = [double]$x.r0_ratio * 100
                    $cl = [double]$x.trade
                    $pc = [double]$x.changeratio * 100
                    $lines += ("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}" -f $x.opendate,$mn,0,0,0,0,$mp,0,0,0,0,$cl,$pc)
                }
                $f = Join-Path $outDir "$code.csv"
                [System.IO.File]::WriteAllLines($f, $lines, [System.Text.Encoding]::UTF8)
                "{0} OK rows={1} first={2} last={3}" -f $code, $rows.Count, ($rows | Sort-Object opendate)[0].opendate, ($rows | Sort-Object opendate)[-1].opendate
                $ok++
                $done = $true
            } else { "{0} EMPTY try{1}" -f $code, $try }
        } catch { "{0} ERR try{1}: {2}" -f $code, $try, $_.Exception.Message }
        if (-not $done) { Start-Sleep -Seconds 5 }
    }
    Start-Sleep -Milliseconds 800
}
"=== 完成 $ok / $($codes.Count) ==="
