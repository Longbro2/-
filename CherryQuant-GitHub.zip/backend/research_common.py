# -*- coding: utf-8 -*-
"""研究回测公共件 — 与主引擎保持口径一致（三份独立脚本共用，避免各写一套数字不可比）

对齐点：
1. 趋势质量(tq)分档阈值与 engine.backtest.ScoreStrategy 完全一致（r60>5 等）
2. 评分直接复用 engine.signals._score（含 W底/突破/金叉质量等全部因子）
3. 佣金/滑点取 engine.config.TRADING：买入价×(1+滑点)、卖出价×(1-滑点)、双向收佣金
4. 点内有效性 pit_valid()：只用截至决策日的数据（近一年年化夏普>min_sharpe），
   消除“用 2026 年全历史验证标签筛 2016 年标的”的幸存者偏差
"""
import numpy as np
import pandas as pd

from engine.signals import calc_indicators, _score
from engine.config import TRADING

SLIP_BUY = 1.0 + TRADING["slippage"]
SLIP_SELL = 1.0 - TRADING["slippage"]
COMM = TRADING["commission"]


def score_series(df: pd.DataFrame) -> pd.Series:
    """逐日评分序列（index=日期），口径与 engine.backtest.ScoreStrategy 一致：
    lag=True(只用已收盘数据) + 引擎同款 tq 阈值(r60>5)。"""
    ind = calc_indicators(df, lag=True)
    c_arr = df["close"].values
    n = len(ind)
    scores = np.full(n, np.nan)
    for i in range(60, n):
        row = ind.iloc[i]
        prev = ind.iloc[i - 1]
        macd_b = bool(row["macd"] > row["macd_signal"])
        macd_cross = bool(prev["macd"] <= prev["macd_signal"]) and macd_b
        ma_b = bool(row["ma5"] > row["ma20"] > row["ma50"])
        r = row["rsi"]
        m5 = float(row["mom_5d"]) if pd.notna(row["mom_5d"]) else 0.0
        c = c_arr[i]
        r60 = (c / c_arr[i - 60] - 1) * 100 if c_arr[i - 60] > 0 else 0.0
        r20 = (c / c_arr[i - 20] - 1) * 100 if c_arr[i - 20] > 0 else 0.0
        r5 = (c / c_arr[i - 5] - 1) * 100 if c_arr[i - 5] > 0 else 0.0
        if r60 > 5 and r5 > -2:
            tq = "强趋势"
        elif r60 > 5 and r20 < 0 and r5 > 0:
            tq = "回调企稳"
        elif r60 < -10 and r5 > 3:
            tq = "超跌反弹"
        elif r60 < -5:
            tq = "下跌趋势"
        else:
            tq = "震荡"
        scores[i] = _score(
            macd_b, macd_cross, ma_b, r, m5,
            bool(row.get("pat_w")), bool(row.get("pat_div")),
            bool(row.get("pat_brk")), int(row.get("macd_quality", 0)),
            trend_quality=tq,
        )
    return pd.Series(scores, index=pd.to_datetime(df["date"]))


def pit_valid(closes: pd.Series, asof: str, min_sharpe: float = 0.3) -> bool:
    """点内有效性：只用 asof(含)之前的数据，近一年(250交易日)年化夏普 > 阈值。
    closes: 按 'YYYY-MM-DD' 字符串索引的收盘序列。"""
    w = closes[closes.index <= asof].dropna()
    rets = w.pct_change().dropna().tail(250)
    if len(rets) < 60:
        return False
    sd = rets.std()
    if not sd or sd <= 0:
        return False
    return (rets.mean() / sd) * np.sqrt(252) > min_sharpe


def buy_lot(budget: float, price: float):
    """按预算买入(含滑点/佣金, 100股整手)。返回 (shares, 实际支出含费)。"""
    px = price * SLIP_BUY
    sh = int(budget / px // 100 * 100) if px > 0 else 0
    if sh <= 0:
        return 0, 0.0
    cost = sh * px
    return sh, cost * (1 + COMM)


def sell_proceeds(shares: float, price: float) -> float:
    """卖出所得(含滑点/佣金)。"""
    if shares <= 0 or not price or price <= 0:
        return 0.0
    return shares * price * SLIP_SELL * (1 - COMM)
