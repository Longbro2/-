# -*- coding: utf-8 -*-
"""
资金流因子 IC 检验（诚实口径）
- 数据: data/cache/fflow/*.csv（东财接口仅提供约120天）+ em_long 收盘价
- 因子: 5日主力净流入 main_net_5d（万元）、5日主力占比 main_pct_5d(%)
- 目标: 未来5日收益（T 收盘 → T+5 收盘，与 ML 标签口径一致）
- 输出: 全池截面 IC 均值/ICIR/正IC占比/显著性 + 分标的明细
用法: python backend/fflow_ic_check.py
"""
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from engine.config import POOL, DATA_DIR  # noqa: E402

FFLOW_DIR = DATA_DIR / "cache" / "fflow"
EM_LONG = DATA_DIR / "cache" / "em_long"
HORIZON = 5

rows = []
for name, info in POOL.items():
    code = info["code"]
    fp = os.path.join(FFLOW_DIR, f"{code}.csv")
    kp = os.path.join(EM_LONG, f"{code}.csv")
    if not os.path.exists(fp) or not os.path.exists(kp):
        continue
    ff = pd.read_csv(fp)
    ff["date"] = pd.to_datetime(ff["date"])
    ff["main_net_5d"] = ff["main_net"].rolling(5).sum() / 1e4   # 万元
    ff["main_pct_5d"] = ff["main_pct"].rolling(5).mean()
    k = pd.read_csv(kp)
    k["date"] = pd.to_datetime(k["date"])
    m = k[["date", "close"]].merge(ff[["date", "main_net_5d", "main_pct_5d"]], on="date", how="left")
    m["fwd5"] = m["close"].shift(-HORIZON) / m["close"] - 1
    m = m.dropna(subset=["main_net_5d", "fwd5"])
    if len(m) < 30:
        continue
    ic1 = m["main_net_5d"].corr(m["fwd5"])
    ic2 = m["main_pct_5d"].corr(m["fwd5"])
    rows.append({"code": code, "name": name, "n": len(m), "ic_net5d": ic1, "ic_pct5d": ic2})

df = pd.DataFrame(rows)
print(f"样本窗口: 约120天 (fflow缓存), 未来{HORIZON}日收益, 逐标的时序IC")
print("=" * 78)
print(f"{'代码':<8} {'名称':<8} {'n':>5} {'IC(main_net_5d)':>16} {'IC(main_pct_5d)':>16}")
for _, r in df.iterrows():
    print(f"{r['code']:<8} {r['name']:<8} {r['n']:>5} {r['ic_net5d']:>+16.3f} {r['ic_pct5d']:>+16.3f}")
print("-" * 78)
for col, label in [("ic_net5d", "5日主力净流入(万元)"), ("ic_pct5d", "5日主力占比(%)")]:
    s = df[col]
    print(f"{label}: 均值IC={s.mean():+.3f}  中位IC={s.median():+.3f}  "
          f"正IC占比={100*(s>0).mean():.0f}%  ICIR={s.mean()/s.std():+.2f}  "
          f"t={s.mean()/s.std()*np.sqrt(len(s)):+.2f}")
print("\n注: 东财资金流免费接口仅提供约120天历史, 以上IC仅为约半年的短样本统计;")
print("    系统宣称的 IC0.160/IR1.01 即为同类短窗口统计, 外推长期需谨慎。")
