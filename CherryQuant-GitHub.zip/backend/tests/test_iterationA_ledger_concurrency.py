# -*- coding: utf-8 -*-
"""迭代 A（现金账本）—— 并发时序 + 资金守恒验收测试。

覆盖契约 `D:\\ds\\CherryQuant-迭代A-资金账本-契约与分工.md` §1/§2/§3/§7：
1. 并发入金 10×100：cash==1000、账本恰好 10 行 DEPOSIT、cash_after 链无丢更新；
2. 并发混跑 deposit / BUY / SELL：终态 cash == base_cash + Σcash_effect；
   trades 按 id 排序的 cash_after 链与账本逐笔一致（不出现 NaN/None 混乱）；
3. 并发卖出不超卖 + SELL_SETTLE 账本一致（成功笔数×份数 <= 持仓）；
4. 完整资金守恒（随机序列 deposit→BUY→SELL→withdraw，含 fee>0）：
   cash==base+Σledger、total_equity==cash+market_value（monkeypatch 固定价格）、
   realized_pnl 与均价法手算一致、trades.fee/cash_after/realized_pnl 非空；
5. 缺报价持仓：valuation_complete=False、market_value 只含有价部分、
   missing_quotes 含该代码，且与 `/api/portfolio/positions` 口径一致；
6. 回归引用：engine.ml.build_dataset() 返回 5 元组且 label_ends 长度一致
   （ML 修复测试在 test_regressions_7fix_20261109.py，这里只做回归引用，不重造）。

口径（Lead 确认）：
  - cash = base_cash + Σ cash_effect(amount)，cash_effect 类型 =
    {DEPOSIT, WITHDRAW, FEE, DIVIDEND, BUY_SETTLE, SELL_SETTLE}；REALIZED_PNL 仅信息行不计现金；
  - trades.realized_pnl = (卖出价 - 卖出前持仓均价) * 卖出份数（毛额，不含 fee）；
  - db.apply_trade(action, code, price, shares, amount=None, name=None, date=None, fee=0.0)。
"""
import importlib
import math
import os
import random
import sys
import threading

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# cash 类金额统一保留 2 位，1 分钱容差足够发现丢更新/重复记账
TOL = 0.02
# realized_pnl 与均价法手算的容差：持仓均价落库保留 4 位小数
# （误差 <= 0.00005*份数）、realized 可能再保留 2 位，逐笔 ≤ 0.05 属口径舍入
PNL_TOL = 0.05


# ==================== 通用工具 ====================

def _account():
    from engine import account
    return account


def _db():
    from engine import db
    return db


def _rows(sql, params=()):
    """直接查测试临时库（绕过被测代码，独立核对）。"""
    db = _db()
    conn = db.get_conn()
    try:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]
    finally:
        conn.close()


def _scalar(sql, params=()):
    db = _db()
    conn = db.get_conn()
    try:
        return conn.execute(sql, params).fetchone()[0]
    finally:
        conn.close()


def _cash_effect_types():
    return set(_account().CASH_EFFECT_TYPES)


def _cash_effect_sum():
    """独立 SQL 汇总 cash_effect 类账本额（不含 REALIZED_PNL 信息行）。"""
    types = _cash_effect_types()
    total = 0.0
    for r in _rows("SELECT type, amount FROM cash_ledger ORDER BY id"):
        assert r["type"] in set(_account().LEDGER_TYPES), f"未知账本类型: {r['type']}"
        if r["type"] in types:
            total += float(r["amount"] or 0.0)
    return total


def _ledger_entries(limit=10000):
    return _account().list_ledger(limit=limit)["entries"]


def _apply_trade(action, code, price, shares, fee=0.0, date=None):
    db = _db()
    kwargs = dict(action=action, code=code, price=price, shares=shares, fee=float(fee))
    if date is not None:
        kwargs["date"] = date
    return db.apply_trade(**kwargs)


def _run_threads(workers, timeout=180):
    """同时起跑全部 worker；返回异常列表（空 = 全部成功）。"""
    errors = []
    start = threading.Event()
    lock = threading.Lock()

    def wrap(fn):
        def run():
            start.wait(timeout=60)
            try:
                fn()
            except BaseException as e:      # noqa: BLE001 - 收集线程内异常回主线程断言
                with lock:
                    errors.append(f"{type(e).__name__}: {e}")
        return run

    threads = [threading.Thread(target=wrap(w), daemon=True) for w in workers]
    for t in threads:
        t.start()
    start.set()
    for t in threads:
        t.join(timeout=timeout)
    alive = [t.name for t in threads if t.is_alive()]
    assert not alive, f"并发线程在 {timeout}s 内未结束（疑似死锁/写锁等待）: {alive}"
    return errors


def _assert_no_nan(trade):
    """trades 行不允许 NaN/None 混乱：数值字段若有值必须有限。"""
    for field in ("fee", "cash_after", "realized_pnl", "amount", "price", "shares"):
        v = trade.get(field)
        if v is None:
            continue
        assert math.isfinite(float(v)), f"trades.{field} 非有限数: {v!r} (trade={trade})"


# ==================== 行情 monkeypatch（固定价格） ====================

def _make_quote_df(price, n=300):
    import pandas as pd

    idx = pd.bdate_range(end="2026-11-10", periods=n)
    close = pd.Series([float(price)] * n)
    return pd.DataFrame({
        "date": idx,
        "open": close.values,
        "high": close.values * 1.01,
        "low": close.values * 0.99,
        "close": close.values,
        "volume": [1000000] * n,
    })


def _patch_quotes(monkeypatch, price_map):
    """固定行情价格：price_map 中缺失的 code 返回空 DataFrame（=缺报价/no_data）。

    - engine.account.fetch ← account.get_positions_valuation/get_account_equity 的取价（Lead 确认）；
    - engine.signals.fetch ← api.portfolio_api.positions() 的取价（用于口径一致性核对）。
    """
    import pandas as pd

    def fake_fetch(code, offline=True, **kwargs):
        px = price_map.get(code)
        if px is None:
            return pd.DataFrame()
        return _make_quote_df(px)

    patched = []
    for modname in ("engine.account", "engine.signals", "engine.data"):
        try:
            mod = importlib.import_module(modname)
        except Exception:
            continue
        if hasattr(mod, "fetch"):
            monkeypatch.setattr(mod, "fetch", fake_fetch)
            patched.append(modname)
    assert "engine.account" in patched, f"account 取价函数不是模块级 fetch，无法固定行情: {patched}"
    assert "engine.signals" in patched, f"signals.fetch 不可 patch，无法核对 positions 口径: {patched}"


# ==================== 1. 并发入金 ====================

def test_concurrent_deposits_no_lost_update():
    """10 线程 × 100 元并发入金：cash==1000、账本恰好 10 行、cash_after 链一致。"""
    account = _account()
    base = float(account.get_base_cash() or 0.0)
    n, amount = 10, 100.0

    def work():
        account.deposit(amount, date="2026-11-10", note="concurrent-deposit")

    errors = _run_threads([work] * n)
    assert not errors, f"并发入金抛出异常: {errors}"

    eq = account.get_account_equity(with_twr=False)
    assert eq["ledger_initialized"] is True, f"并发入金后账户应已初始化: {eq}"
    expect_cash = base + n * amount
    assert abs(float(eq["cash"]) - expect_cash) < TOL, \
        f"cash={eq['cash']} 期望={expect_cash}（丢更新）"

    entries = _ledger_entries()
    deposits = [e for e in entries if e["type"] == "DEPOSIT"]
    assert len(deposits) == n, f"DEPOSIT 账本行数={len(deposits)} 期望={n}（账本丢行）"
    assert len(entries) == n, f"账本总行数={len(entries)} 期望={n}（不应有其它类型）"

    # cash_after 链：按 id 升序逐行累加必须与每行 cash_after 一致
    running = base
    for e in sorted(entries, key=lambda x: int(x["id"])):
        amount_v = float(e["amount"])
        if e["type"] in _cash_effect_types():
            running += amount_v
        assert abs(float(e["cash_after"]) - running) < TOL, \
            f"账本 id={e['id']} cash_after={e['cash_after']} 期望={running}"
    assert abs(running - float(eq["cash"])) < TOL, \
        f"账本累计={running} 与 cash={eq['cash']} 不一致"


# ==================== 2. 并发混合 deposit / BUY / SELL ====================

def test_concurrent_mixed_deposit_buy_sell_ledger_chain():
    """多线程同时 deposit/BUY/SELL（先持有）：终态 cash==base+Σcash_effect，cash_after 链一致。"""
    account = _account()
    account.deposit(50000.0, date="2026-10-01", note="init")
    # 先持有 2000 份，供并发卖出使用
    _apply_trade("BUY", "159828", 1.0, 2000, fee=1.0, date="2026-10-01")
    base = float(account.get_base_cash() or 0.0)

    def do_deposit():
        account.deposit(100.0, date="2026-10-02", note="mix-deposit")

    def do_buy():
        _apply_trade("BUY", "159828", 1.0, 10, fee=0.01, date="2026-10-02")

    def do_sell():
        _apply_trade("SELL", "159828", 1.1, 10, fee=0.01, date="2026-10-02")

    workers = ([do_deposit] * 5) + ([do_buy] * 5) + ([do_sell] * 2)
    errors = _run_threads(workers)
    assert not errors, f"并发混合操作抛出异常: {errors}"

    # 终态现金 == base_cash + Σ cash_effect（独立 SQL 汇总）
    effects = _cash_effect_sum()
    cash = float(account.cash_balance())
    eq = account.get_account_equity(with_twr=False)
    assert abs(cash - (base + effects)) < TOL, \
        f"cash_balance={cash} != base({base})+Σcash_effect({effects})={base + effects}"
    assert abs(float(eq["cash"]) - cash) < TOL, \
        f"equity.cash={eq['cash']} 与 cash_balance={cash} 不一致"

    # 初始 1 笔 + 并发 5 买 + 2 卖 = 恰好 8 笔（少了=丢成交，多了=重复）
    trades = _rows("SELECT * FROM trades ORDER BY id")
    assert len(trades) == 8, f"成交行数={len(trades)} 期望=8"
    ledger = _rows("SELECT * FROM cash_ledger ORDER BY id")
    types = _cash_effect_types()
    by_trade = {}
    for e in ledger:
        if e["trade_id"] is not None and e["type"] in types:
            by_trade.setdefault(int(e["trade_id"]), []).append(e)
    for t in trades:
        _assert_no_nan(t)
        # 账户在并发前已初始化 → 每笔都必须是已入账状态，不允许 NULL 混乱
        assert t["fee"] is not None, f"trade id={t['id']} fee 为 NULL"
        assert t["cash_after"] is not None, f"trade id={t['id']} cash_after 为 NULL"
        assert t["realized_pnl"] is not None, f"trade id={t['id']} realized_pnl 为 NULL"
        rows_t = by_trade.get(int(t["id"]))
        assert rows_t, f"trade id={t['id']}({t['action']}) 没有对应 cash_effect 账本行"
        max_id = max(int(e["id"]) for e in rows_t)
        expected = base + sum(
            float(e["amount"]) for e in ledger
            if e["type"] in types and int(e["id"]) <= max_id)
        assert abs(float(t["cash_after"]) - expected) < TOL, \
            (f"trade id={t['id']}({t['action']}) cash_after={t['cash_after']} "
             f"期望={expected}（链断裂）")


# ==================== 3. 并发卖出不超卖 ====================

def test_concurrent_sells_never_oversell_and_ledger_consistent():
    """多线程卖同一持仓：不超卖、成功笔数×份数<=持仓、SELL_SETTLE 账本一致。"""
    account = _account()
    db = _db()
    account.deposit(20000.0, date="2026-10-01", note="init")
    _apply_trade("BUY", "560680", 1.0, 500, fee=0.5, date="2026-10-01")
    base = float(account.get_base_cash() or 0.0)

    per_sell = 200.0
    success, rejected = [], []
    lock = threading.Lock()

    def sell_loop():
        for _ in range(2):
            try:
                r = _apply_trade("SELL", "560680", 1.2, per_sell, fee=0.2, date="2026-10-02")
                with lock:
                    success.append(r)
            except db.TradeRejected:
                with lock:
                    rejected.append(1)

    errors = _run_threads([sell_loop] * 4)
    assert not errors, f"并发卖出出现非 TradeRejected 异常: {errors}"

    pos = db.load_positions()
    remain = float(pos.get("560680", {}).get("shares", 0.0))
    assert remain >= -1e-9, f"持仓出现负数: {remain}"
    assert len(success) * per_sell <= 500 + 1e-9, \
        f"成功卖出 {len(success)}×{per_sell} 超过持仓 500（超卖）"
    assert abs(remain - (500 - len(success) * per_sell)) < TOL, \
        f"剩余持仓={remain} 与成功笔数推导不符（成功 {len(success)} 笔）"
    # 500 份、每次 200 份 → 恰好能成功 2 笔（剩 100 不足 200）
    assert len(success) == 2, f"成功卖出笔数={len(success)} 期望=2，rejected={len(rejected)}"

    sell_trades = _rows("SELECT * FROM trades WHERE action='SELL' ORDER BY id")
    assert len(sell_trades) == len(success), \
        f"SELL 成交行={len(sell_trades)} 与成功笔数={len(success)} 不一致"
    for t in sell_trades:
        _assert_no_nan(t)
        assert t["cash_after"] is not None, f"SELL trade id={t['id']} cash_after 为 NULL"

    cash = float(account.cash_balance())
    effects = _cash_effect_sum()
    assert abs(cash - (base + effects)) < TOL, \
        f"cash={cash} != base({base})+Σcash_effect({effects})"

    sell_settle = [e for e in _ledger_entries() if e["type"] == "SELL_SETTLE"]
    assert len(sell_settle) == len(success), \
        f"SELL_SETTLE 账本行={len(sell_settle)} 与成功卖出笔数={len(success)} 不一致"
    assert abs(sum(float(e["amount"]) for e in sell_settle) - len(success) * 1.2 * per_sell) < TOL


# ==================== 3b. 并发出金不透支（TOCTOU 回归） ====================

def test_concurrent_withdraws_never_overdraw():
    """并发出金：现金校验必须在写事务内（TOCTOU 回归）。

    Lead 修复前：withdraw 先 db.cash_balance() 校验、再另起事务写账本，
    两线程同时取 800（现金仅 1000）会双成功 → cash=-600。
    修复后：BEGIN IMMEDIATE 内校验 → 只 1 笔成功、cash==200、WITHDRAW 仅 1 行。
    """
    account = _account()
    db = _db()
    account.deposit(1000.0, date="2026-10-01", note="init")
    barrier = threading.Barrier(2, timeout=30)
    success, rejected, fatal = [], [], []
    lock = threading.Lock()

    def withdraw_800():
        try:
            barrier.wait()
        except threading.BrokenBarrierError:
            return
        try:
            r = account.withdraw(800.0, date="2026-10-01", note="concurrent-withdraw")
            with lock:
                success.append(r)
        except db.TradeRejected as e:
            with lock:
                rejected.append(str(e))
        except BaseException as e:      # noqa: BLE001
            with lock:
                fatal.append(f"{type(e).__name__}: {e}")

    errors = _run_threads([withdraw_800] * 2)
    assert not errors, f"并发出金线程异常: {errors}"
    assert not fatal, f"并发出金出现非 TradeRejected 异常: {fatal}"
    assert len(success) == 1, f"并发出金成功笔数={len(success)} 期望=1（两笔都成功=透支/TOCTOU）"
    assert len(rejected) == 1, f"并发出金被拒笔数={len(rejected)} 期望=1"

    cash = float(account.cash_balance())
    assert abs(cash - 200.0) < TOL, f"并发出金后 cash={cash} 期望=200（不得为负/不得多扣）"
    assert cash >= -TOL, f"并发出金后现金为负: {cash}"

    entries = _ledger_entries()
    withdraws = [e for e in entries if e["type"] == "WITHDRAW"]
    assert len(withdraws) == 1, f"WITHDRAW 账本行数={len(withdraws)} 期望=1（被拒的那笔不得落账）"
    assert abs(float(withdraws[0]["amount"]) + 800.0) < TOL, withdraws[0]
    # 账本 cash_after 链仍一致
    running = float(account.get_base_cash() or 0.0)
    for e in sorted(entries, key=lambda x: int(x["id"])):
        if e["type"] in _cash_effect_types():
            running += float(e["amount"])
        assert abs(float(e["cash_after"]) - running) < TOL, \
            f"账本 id={e['id']} cash_after={e['cash_after']} 期望={running}"


# ==================== 4. 完整资金守恒（随机序列） ====================

def test_random_sequence_full_conservation(monkeypatch):
    """随机 deposit→BUY→SELL→withdraw（含 fee>0）后资金守恒、均价法 realized_pnl 正确。"""
    account = _account()
    db = _db()
    prices = {"159828": 1.5, "560680": 0.8, "512880": 1.1}
    _patch_quotes(monkeypatch, prices)

    base = float(account.get_base_cash() or 0.0)
    assert base == 0.0, f"全新账户 base_cash 应为 0，实际 {base}"

    rng = random.Random(20261110)
    # 参考模型（独立手算，与实现互相对照）
    positions = {}            # code -> {"shares", "avg_cost"(未舍入)}
    cash = 0.0
    fees_total = 0.0
    realized_expected = 0.0

    def expected_mv():
        return round(sum(p["shares"] * prices[c] for c, p in positions.items()), 6)

    def expected_unrealized():
        return round(sum((prices[c] - p["avg_cost"]) * p["shares"]
                         for c, p in positions.items()), 6)

    def check_after_trade(prev_cash, action, price, shares, fee, realized):
        """逐笔核对刚写入的 trades 行 cash_after/fee/realized_pnl。"""
        t = _rows("SELECT * FROM trades ORDER BY id DESC LIMIT 1")[0]
        expected_cash = prev_cash + (-price * shares - fee if action == "BUY"
                                     else price * shares - fee)
        assert abs(float(t["cash_after"]) - expected_cash) < TOL, \
            f"trade id={t['id']} cash_after={t['cash_after']} 期望={expected_cash}"
        assert abs(float(t["fee"]) - fee) < 1e-9, f"trade id={t['id']} fee={t['fee']} 期望={fee}"
        assert abs(float(t["realized_pnl"]) - realized) <= PNL_TOL, \
            f"trade id={t['id']} realized_pnl={t['realized_pnl']} 均价法手算={realized}"
        _assert_no_nan(t)
        return expected_cash

    op_seq = 0
    counts = {"deposit": 0, "withdraw": 0, "buy": 0, "sell": 0}

    def next_date():
        nonlocal op_seq
        op_seq += 1
        return f"2026-09-{op_seq % 28 + 1:02d}"

    # 初始入金保证可交易
    account.deposit(30000.0, date=next_date(), note="init")
    cash += 30000.0
    counts["deposit"] += 1

    codes = list(prices)
    attempts = 0
    while op_seq < 45 and attempts < 500:
        attempts += 1
        op = rng.choice(["deposit", "withdraw", "buy", "sell", "buy", "sell"])
        date = next_date()
        if op == "deposit":
            amt = round(rng.uniform(100, 3000), 2)
            r = account.deposit(amt, date=date, note="rand-deposit")
            cash += amt
            counts["deposit"] += 1
            assert abs(float(r["cash"]) - cash) < TOL, \
                f"deposit 返回 cash={r['cash']} 期望={cash}"
            assert abs(float(r["total_equity"]) - (cash + expected_mv())) < TOL, \
                f"deposit 返回 total_equity={r['total_equity']} 期望={cash + expected_mv()}"
        elif op == "withdraw":
            amt = round(rng.uniform(100, 2000), 2)
            if amt > cash - 100:
                continue
            r = account.withdraw(amt, date=date, note="rand-withdraw")
            cash -= amt
            counts["withdraw"] += 1
            assert abs(float(r["cash"]) - cash) < TOL
        elif op == "buy":
            code = rng.choice(codes)
            shares = float(rng.choice([100, 200, 300, 500]))
            price = prices[code]
            fee = round(rng.uniform(0, 3), 2) if rng.random() < 0.8 else 0.0
            if price * shares + fee > cash - 1:
                continue
            prev = cash
            cash -= price * shares + fee
            fees_total += fee
            old = positions.get(code)
            if old:
                new_shares = old["shares"] + shares
                old["avg_cost"] = (old["shares"] * old["avg_cost"] + shares * price) / new_shares
                old["shares"] = new_shares
            else:
                positions[code] = {"shares": shares, "avg_cost": price}
            _apply_trade("BUY", code, price, shares, fee=fee, date=date)
            cash = check_after_trade(prev, "BUY", price, shares, fee, 0.0)
            counts["buy"] += 1
        else:  # sell
            held = [c for c, p in positions.items() if p["shares"] > 0]
            if not held:
                continue
            code = rng.choice(held)
            price = prices[code]
            qty = float(rng.choice([100, 200, 300]))
            qty = min(qty, positions[code]["shares"])
            fee = round(rng.uniform(0, 3), 2) if rng.random() < 0.8 else 0.0
            prev = cash
            realized = (price - positions[code]["avg_cost"]) * qty   # 毛额，不含 fee
            realized_expected += realized
            cash += price * qty - fee
            fees_total += fee
            positions[code]["shares"] -= qty
            if positions[code]["shares"] <= 1e-9:
                positions.pop(code)
            _apply_trade("SELL", code, price, qty, fee=fee, date=date)
            cash = check_after_trade(prev, "SELL", price, qty, fee, realized)
            counts["sell"] += 1

    for k, v in counts.items():
        assert v > 0, f"随机序列未覆盖到 {k} 操作（计数={counts}）"

    eq = account.get_account_equity(with_twr=False)
    ledger_sum = _cash_effect_sum()

    # (a) cash == base_cash + Σcash_effect == 手算现金
    assert abs(float(eq["base_cash"]) - base) < TOL
    assert abs(float(eq["cash"]) - (base + ledger_sum)) < TOL, \
        f"equity.cash={eq['cash']} != base+Σledger={base + ledger_sum}"
    assert abs(float(eq["cash"]) - cash) < TOL, f"equity.cash={eq['cash']} != 手算现金={cash}"

    # (b) total_equity == cash + market_value（固定价格）
    assert abs(float(eq["market_value"]) - expected_mv()) < TOL, \
        f"market_value={eq['market_value']} 期望={expected_mv()}"
    assert abs(float(eq["total_equity"]) - (float(eq["cash"]) + float(eq["market_value"]))) < TOL, \
        f"total_equity={eq['total_equity']} != cash+mv={float(eq['cash']) + float(eq['market_value'])}"
    assert abs(float(eq["total_equity"]) - (cash + expected_mv())) < TOL

    # (c) realized_pnl 与均价法手算一致（毛额，不含 fee）
    realized_api = float(eq["realized_pnl"])
    assert abs(realized_api - realized_expected) <= PNL_TOL * max(1, counts["sell"]), \
        f"equity.realized_pnl={realized_api} 均价法手算={realized_expected}"
    assert abs(float(account.compute_realized_pnl()) - realized_api) < TOL, \
        "compute_realized_pnl() 与 equity.realized_pnl 不一致"

    # (d) 手续费与未实现盈亏
    assert abs(float(eq["total_fees"]) - fees_total) < TOL, \
        f"total_fees={eq['total_fees']} 期望={fees_total}"
    assert abs(float(eq["unrealized_pnl"]) - expected_unrealized()) <= 0.2, \
        f"unrealized_pnl={eq['unrealized_pnl']} 期望≈{expected_unrealized()}"

    # (e) 每笔的 fee/cash_after/realized_pnl 非空，账本行齐
    trades = _rows("SELECT * FROM trades ORDER BY id")
    assert len(trades) == counts["buy"] + counts["sell"], \
        f"成交行数={len(trades)} 期望={counts['buy'] + counts['sell']}"
    assert all(t["fee"] is not None for t in trades), "存在 trades.fee 为 NULL"
    assert all(t["cash_after"] is not None for t in trades), "存在 trades.cash_after 为 NULL"
    assert all(t["realized_pnl"] is not None for t in trades), "存在 trades.realized_pnl 为 NULL"
    entries = _ledger_entries()
    type_count = {}
    for e in entries:
        type_count[e["type"]] = type_count.get(e["type"], 0) + 1
    assert type_count.get("DEPOSIT", 0) == counts["deposit"], type_count
    assert type_count.get("WITHDRAW", 0) == counts["withdraw"], type_count
    assert type_count.get("BUY_SETTLE", 0) == counts["buy"], type_count
    assert type_count.get("SELL_SETTLE", 0) == counts["sell"], type_count
    fee_rows = type_count.get("FEE", 0)
    assert fee_rows == sum(1 for t in trades if float(t["fee"]) > 0), type_count
    # REALIZED_PNL 若存在只是信息行，不得计入现金
    assert abs(_cash_effect_sum() - (cash - base)) < TOL

    # (f) 非法入金/出金被拒（账户已初始化）
    cash_before = float(account.cash_balance())
    with pytest.raises(db.TradeRejected):
        account.withdraw(cash_before + 1000, date="2026-10-30")
    with pytest.raises(db.TradeRejected):
        account.deposit(0, date="2026-10-30")
    with pytest.raises(db.TradeRejected):
        account.deposit(float("nan"), date="2026-10-30")
    assert abs(float(account.cash_balance()) - cash_before) < TOL, "非法操作后现金被改动"


# ==================== 5. 缺报价估值（与 positions API 口径一致） ====================

def test_missing_quote_valuation_matches_positions_api(monkeypatch):
    """缺报价持仓：valuation_complete=False、market_value 只含有价部分，与 positions API 一致。"""
    account = _account()
    _patch_quotes(monkeypatch, {"159828": 1.5})       # 999999 无报价
    account.deposit(10000.0, date="2026-10-01", note="init")
    _apply_trade("BUY", "159828", 1.0, 1000, fee=2.0, date="2026-10-01")
    _apply_trade("BUY", "999999", 2.0, 300, fee=0.0, date="2026-10-01")

    val = account.get_positions_valuation()
    missing_codes = {m["code"] for m in val["missing_quotes"]}
    assert val["valuation_complete"] is False, f"缺报价时 valuation_complete 应为 False: {val}"
    assert "999999" in missing_codes, f"missing_quotes 未含 999999: {val['missing_quotes']}"
    assert abs(float(val["market_value"]) - 1000 * 1.5) < TOL, \
        f"market_value={val['market_value']} 应只含有价部分 1500"

    row = next(p for p in val["positions"] if p["code"] == "999999")
    assert row["no_data"] is True, f"缺报价持仓 no_data 应为 True: {row}"
    assert row["current_price"] is None, f"缺报价 current_price 应为 None（与 positions API 口径一致）: {row}"
    assert row["market_value"] is None, f"缺报价 market_value 应为 None（不参与总额）: {row}"

    eq = account.get_account_equity(with_twr=False)
    assert eq["valuation_complete"] is False
    assert "999999" in {m["code"] for m in eq["missing_quotes"]}
    assert abs(float(eq["total_equity"]) -
               (float(eq["cash"]) + float(eq["market_value"]))) < TOL, \
        f"total_equity={eq['total_equity']} != cash+mv（缺报价不应把 0 当价格）"
    assert abs(float(eq["market_value"]) - float(val["market_value"])) < TOL

    # 与 /api/portfolio/positions 口径一致
    from api import portfolio_api
    pos_api = portfolio_api.positions()
    assert pos_api["valuation_complete"] is False
    api_missing = {m["code"] for m in pos_api["missing_quotes"]}
    assert api_missing == missing_codes, \
        f"positions API missing={api_missing} 与 account 估值 missing={missing_codes} 不一致"
    assert abs(float(pos_api["total_market_value"]) - float(eq["market_value"])) < TOL, \
        (f"positions API total_market_value={pos_api['total_market_value']} "
         f"与 equity.market_value={eq['market_value']} 不一致")
    api_row = next(p for p in pos_api["positions"] if p["code"] == "999999")
    assert api_row["no_data"] is True and api_row["market_value"] is None
    # 有报价持仓逐只市值一致
    val_map = {p["code"]: p for p in val["positions"]}
    for p in pos_api["positions"]:
        if p["no_data"]:
            continue
        assert abs(float(val_map[p["code"]]["market_value"]) - float(p["market_value"])) < TOL, \
            f"{p['code']} 市值口径不一致: {val_map[p['code']]} vs {p}"


# ==================== 6. 回归引用：ML build_dataset 5 元组 ====================

def test_ml_build_dataset_returns_5tuple_with_aligned_label_ends():
    """回归引用（不重造 ML 修复测试）：build_dataset 返回 5 元组，label_ends 与样本等长。"""
    from engine import ml

    data = ml.build_dataset()
    assert data is not None, "行情缓存缺失，build_dataset 返回 None（回归引用失败）"
    assert isinstance(data, tuple) and len(data) == 5, \
        f"build_dataset 应返回 5 元组 (X,y,dates,codes,label_ends)，实际 len={len(data) if isinstance(data, tuple) else type(data)}"
    X, y, dates, codes, label_ends = data
    n = len(X)
    assert n > 0, "build_dataset 样本数为 0"
    for name, series in (("y", y), ("dates", dates), ("codes", codes), ("label_ends", label_ends)):
        assert len(series) == n, f"{name} 长度={len(series)} != 样本数={n}（label_ends 必须与样本对齐）"
