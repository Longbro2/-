# -*- coding: utf-8 -*-
"""第三轮 24 项任务：第 01-04 项（记账正确性）回归测试

01 成交字段不错列（具名参数/逐列核对）
02 记账输入业务校验（动作/价格/份数/超卖/amount 一致性）
03 单事务：成交插入失败时持仓/峰值一起回滚
04 并发记账：不丢更新、不超卖
"""
import sys
import os
import threading

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ============ 01 成交字段 ============

def test_trade_columns_and_amount_semantics():
    from engine import db
    db.apply_trade("BUY", "159828", 1.5, 100.0)
    t = db.load_trades()[-1]
    assert t["name"] == "医疗ETF"
    assert t["price"] == 1.5
    assert t["shares"] == 100.0
    assert t["amount"] == 150.0          # amount = price × shares（不含费用）
    assert abs(t["amount"] - t["price"] * t["shares"]) < 0.01


# ============ 02 业务校验 ============

@pytest.mark.parametrize("kwargs", [
    dict(action="INVALID", code="159828", price=1.5, shares=100),
    dict(action="BUY", code="159828", price=0, shares=100),
    dict(action="BUY", code="159828", price=-1, shares=100),
    dict(action="BUY", code="159828", price=float("nan"), shares=100),
    dict(action="BUY", code="159828", price=1.5, shares=0),
    dict(action="BUY", code="159828", price=1.5, shares=-50),
    dict(action="BUY", code="159828", price=1.5, shares=float("inf")),
    dict(action="BUY", code="", price=1.5, shares=100),
])
def test_invalid_trades_rejected_and_state_unchanged(kwargs):
    from engine import db
    with pytest.raises(db.TradeRejected):
        db.apply_trade(**kwargs)
    assert db.load_positions() == {}
    assert db.load_trades() == []
    assert db.load_peaks() == {}


def test_amount_must_equal_price_times_shares():
    from engine import db
    with pytest.raises(db.TradeRejected):
        db.apply_trade("BUY", "159828", 1.5, 100, amount=999.0)
    assert db.load_positions() == {}


def test_oversell_and_sell_without_position_rejected():
    from engine import db
    with pytest.raises(db.TradeRejected):
        db.apply_trade("SELL", "159828", 1.5, 100)          # 未持有
    db.apply_trade("BUY", "159828", 1.5, 100)
    with pytest.raises(db.TradeRejected):
        db.apply_trade("SELL", "159828", 1.5, 1000)         # 超额卖出
    pos = db.load_positions()
    assert pos["159828"]["shares"] == 100.0                  # 状态未变
    assert len(db.load_trades()) == 1                        # 只有买入


def test_full_sell_clears_position_and_peak():
    from engine import db
    db.apply_trade("BUY", "159828", 1.5, 100)
    assert db.load_peaks().get("159828") == 1.5
    db.apply_trade("SELL", "159828", 1.6, 100)
    assert "159828" not in db.load_positions()
    assert "159828" not in db.load_peaks()
    trades = db.load_trades()
    assert len(trades) == 2 and trades[-1]["action"] == "SELL"


# ============ 03 事务：失败整体回滚 ============

def _wrap_conn(real_conn, fail_on):
    class Wrap:
        def __init__(self, c):
            self._c = c

        def execute(self, sql, params=()):
            if fail_on in sql:
                raise RuntimeError("injected failure: " + fail_on)
            return self._c.execute(sql, params)

        def __getattr__(self, name):
            return getattr(self._c, name)

    return Wrap(real_conn)


def test_atomic_rollback_when_trade_insert_fails(monkeypatch):
    from engine import db
    real_get = db.get_conn
    monkeypatch.setattr(db, "get_conn", lambda: _wrap_conn(real_get(), "INSERT INTO trades"))
    with pytest.raises(RuntimeError):
        db.apply_trade("BUY", "159828", 1.5, 100)
    monkeypatch.setattr(db, "get_conn", real_get)
    assert db.load_positions() == {}
    assert db.load_peaks() == {}
    assert db.load_trades() == []


def test_atomic_rollback_when_position_update_fails(monkeypatch):
    from engine import db
    db.apply_trade("BUY", "560680", 0.7, 200)
    real_get = db.get_conn
    monkeypatch.setattr(db, "get_conn", lambda: _wrap_conn(real_get(), "UPDATE positions"))
    with pytest.raises(RuntimeError):
        db.apply_trade("BUY", "560680", 0.8, 100)
    monkeypatch.setattr(db, "get_conn", real_get)
    pos = db.load_positions()
    assert pos["560680"]["shares"] == 200.0                 # 持仓未变
    assert len(db.load_trades()) == 1                        # 成交未新增


# ============ 04 并发：不丢更新、不超卖 ============

def test_concurrent_buys_different_codes_no_lost_update():
    from engine import db

    def buy(code, price):
        for _ in range(5):
            db.apply_trade("BUY", code, price, 100)

    ts = [threading.Thread(target=buy, args=("159828", 1.5)),
          threading.Thread(target=buy, args=("560680", 0.7))]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    pos = db.load_positions()
    assert pos["159828"]["shares"] == 500
    assert pos["560680"]["shares"] == 500
    assert len(db.load_trades()) == 10


def test_concurrent_buys_same_code_no_lost_update():
    from engine import db

    def buy():
        for _ in range(20):
            db.apply_trade("BUY", "159828", 1.5, 100)

    ts = [threading.Thread(target=buy) for _ in range(3)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    assert db.load_positions()["159828"]["shares"] == 6000
    assert len(db.load_trades()) == 60


def test_concurrent_sells_never_oversell():
    from engine import db
    db.apply_trade("BUY", "159828", 1.5, 500)

    def sell(n):
        for _ in range(n):
            try:
                db.apply_trade("SELL", "159828", 1.6, 300)
            except db.TradeRejected:
                return

    ts = [threading.Thread(target=sell, args=(2,)) for _ in range(2)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    pos = db.load_positions()
    shares = pos.get("159828", {}).get("shares", 0)
    assert 0 <= shares <= 200, shares        # 500 最多卖出 1 次 300（剩 200）
    sells = [t for t in db.load_trades() if t["action"] == "SELL"]
    assert len(sells) == 1
