# -*- coding: utf-8 -*-
"""迭代 A 前端测试：用 Node 实际执行 frontend/index.html 的内联 JS（最小 DOM/API 桩）。

覆盖：账户资金卡片（未初始化/入金后现金·总权益·TWR·已实现盈亏/缺报价“估值不完整”/
现金为负）、资金账本表格（含运行余额 cash_after）、入金/出金按钮及失败 alert(detail)。
同时回归旧的 index_missing_quote_check.js（缺报价不出现 -100 假亏损）。

只跑本文件：
    cd backend && python -m pytest tests/test_iterationA_frontend.py -q
"""
import shutil
import subprocess
from pathlib import Path

import pytest

FRONTEND_DIR = Path(__file__).resolve().parent / "frontend"


def _run_node(script_name: str) -> subprocess.CompletedProcess:
    """node 可用则执行前端桩测试脚本；不可用则 skip。"""
    node = shutil.which("node")
    if not node:
        pytest.skip("node 不可用，跳过前端 JS 执行测试")
    script = FRONTEND_DIR / script_name
    assert script.exists(), script
    proc = subprocess.run(
        [node, str(script)],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=180, cwd=str(script.parent),
    )
    assert proc.returncode == 0, (
        f"{script_name} 执行失败 (exit {proc.returncode})\n"
        f"stdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
    )
    return proc


def test_iterationA_account_page_real_js():
    """迭代 A：实际执行首页 JS，验证账户资金卡片/资金账本/入金出金（A~F 场景）。"""
    proc = _run_node("iterationA_account_check.js")
    assert "OK" in (proc.stdout or ""), proc.stdout


def test_existing_missing_quote_page_still_passes():
    """回归：迭代 A 改动后，旧首页缺报价桩测试仍必须通过。"""
    proc = _run_node("index_missing_quote_check.js")
    assert "OK" in (proc.stdout or ""), proc.stdout
