# -*- coding: utf-8 -*-
"""GPT 复核 7 项残留问题（A-H）的回归测试（2026-11-09 交接文档）。

覆盖：
  A. #05 末日买入又清仓，现金重复计入本金（P0）
  B. #15 ML 隔离按每条样本真实标签结束日，不按固定交易日数（P0）
  C. #12/16 长期因子（250日）预热 260，完整历史 vs 测试切片同分（P0）
  D. #19 compare/optimize 预热期不建仓（trade_start），收益从 start 起算（P0）
  E. #08 再平衡默认路径用账户总资金锚点，不重复减仓；缺行情标 no_data（P1）
  F. #21 首页/再平衡缺报价实际渲染：不出现 -100%，显示“—/行情缺失/不完整”（P1）
  G. #23 扫描缓存版本检查+写入同一把锁；并发旧结果不得覆盖新缓存（P1）
  H. 推荐页统一用 optimize_report_new.json 验证口径；rotate 买入集合 ⊆ advice.buy（P1）

全部使用 conftest 的临时数据库；行情用真实只读缓存或合成数据，不写真实 quant.db。
"""
import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ==================== 通用工具 ====================

class FixedSignalStrategy:
    """最小策略：直接给出 signal 列（1买/-1卖/0不动）。"""

    def __init__(self, sig):
        self.sig = sig
        self.name = "fixed"

    def generate_signals(self, df):
        d = df.copy()
        d["signal"] = self.sig[:len(d)]
        return d


def _flat_df(days=8, price=1.0):
    dates = pd.date_range("2026-01-05", periods=days, freq="B")
    return pd.DataFrame({
        "date": dates,
        "open": price, "high": price, "low": price, "close": price,
        "volume": 100000,
    })


# ==================== A #05 末日清仓现金 ====================

def test_backtest_lastday_buy_then_clear_no_duplicate_capital():
    """合成 8 根 K 线：第 7 根收盘才出买入信号 → 末日开盘 1.0 买入、收盘 1.2
    触发止盈末日清仓。旧实现 cash[i]=cash[i-1]+回笼 会把买入前本金重复加回
    （1000→2200），新实现末日权益必须是 1200。"""
    from engine.backtest import Backtest

    dates = pd.date_range("2026-01-05", periods=8, freq="B")
    close = np.array([1.0] * 7 + [1.2])
    df = pd.DataFrame({
        "date": dates,
        "open": np.array([1.0] * 8),          # 末日开盘价 1.0
        "high": np.maximum(close, 1.0),
        "low": np.minimum(close, 1.0),
        "close": close,                        # 末日收盘 1.2 → +20% 触发止盈
        "volume": 100000,
    })
    sig = [0, 0, 0, 0, 0, 0, 1, 0]            # 第 7 根（倒数第二根）收盘出 BUY
    bt = Backtest(df, FixedSignalStrategy(sig), initial_capital=1000.0,
                  commission=0.0, slippage=0.0, enable_risk=True)
    r = bt.run()
    sells = [t for t in r["trade_list"] if t["action"] == "SELL"]
    # 末日清仓必须发生，且权益 = 1000 份 × 1.2 = 1200（不是 2200）
    assert sells and "末日清仓" in sells[-1]["reason"], r["trade_list"]
    assert r["final_equity"] == pytest.approx(1200.0, abs=0.01), r["equity_curve"]
    assert r["equity_curve"][-1] == pytest.approx(1200.0, abs=0.01)
    assert max(r["equity_curve"]) <= 1200.01, "现金被重复计入（>1200）"


# ==================== B #15 ML 标签结束日隔离 ====================

def _synthetic_market(monkeypatch):
    """合成 2 只有行情的标的 + 1 只缺行情标的，并替换 ML 数据源。"""
    import engine.ml as ml
    import engine.fflow as ff_mod

    n1, n2 = 140, 135
    all_dates = pd.date_range("2026-01-05", periods=n1, freq="B")

    def make_df(n, base, slope):
        dates = all_dates[:n]
        close = pd.Series(np.linspace(base, base * (1 + slope), n))
        return pd.DataFrame({
            "date": dates,
            "open": close.values, "high": close.values * 1.01,
            "low": close.values * 0.99, "close": close.values,
            "volume": np.full(n, 100000),
        })

    frames = {"C1": make_df(n1, 1.0, 0.2), "C2": make_df(n2, 2.0, 0.3)}

    def fake_fetch(code, offline=True):
        return frames.get(code, pd.DataFrame())

    def fake_fflow(code, offline=True):
        df = frames.get(code)
        if df is None:
            return pd.DataFrame()
        return pd.DataFrame({
            "date": df["date"].values,
            "main_net_5d": np.full(len(df), 100.0),
            "main_pct_5d": np.full(len(df), 1.0),
            "main_net": np.full(len(df), 10.0),
        })

    monkeypatch.setattr(ml, "POOL", {
        "A": {"code": "C1"}, "B": {"code": "C2"}, "MISSING": {"code": "C3"},
    })
    monkeypatch.setattr(ml, "fetch", fake_fetch)
    monkeypatch.setattr(ff_mod, "fetch_fflow", fake_fflow)
    monkeypatch.setattr(ff_mod, "add_fflow_factors", lambda ff: ff)
    return frames


def test_ml_build_dataset_label_end_real_dates(monkeypatch):
    """build_dataset 每行保存真实标签结束日（第 6 个交易日）：缺行情标的被跳过。"""
    import engine.ml as ml

    frames = _synthetic_market(monkeypatch)
    data = ml.build_dataset()
    assert data is not None
    X, y, dates, codes, label_ends = data      # 返回值必须带 label_ends
    assert len(X) == len(y) == len(dates) == len(codes) == len(label_ends) > 0
    assert set(codes.unique()) == {"C1", "C2"}, "缺行情标的 C3 应被跳过"

    # 每行 label_end = 该标的行情里 date 之后第 HORIZON+1(=6) 个交易日
    for code, df in frames.items():
        dts = list(pd.to_datetime(df["date"]))
        expect = {dts[i]: dts[i + ml.HORIZON + 1]
                  for i in range(len(dts) - ml.HORIZON - 1)}
        sub = pd.DataFrame({"date": pd.to_datetime(dates.values),
                            "label_end": pd.to_datetime(label_ends.values),
                            "code": codes.values})
        sub = sub[sub["code"] == code]
        assert len(sub) > 0
        for _, row in sub.iterrows():
            exp = expect.get(row["date"])
            assert exp is not None, (code, row["date"])
            assert row["label_end"] == exp, (code, row["date"], row["label_end"], exp)


def test_ml_time_split_label_end_strictly_before_test_start():
    """训练样本 label_end 必须严格 < 测试首日：恰好等于测试首日 / 跨到后一天都剔除。"""
    import engine.ml as ml

    dates = pd.Series(pd.date_range("2026-01-05", periods=10, freq="B"))
    test_start = dates.iloc[7]
    d = list(dates)
    label_ends = pd.Series([
        d[0], d[1], d[2], d[3],
        test_start - pd.Timedelta(days=1),        # 测试首日前一个自然日 → 保留
        test_start,                                # 恰好等于测试首日 → 剔除
        test_start + pd.Timedelta(days=1),         # 跨到测试首日后一天 → 剔除
        test_start + pd.Timedelta(days=2),
        test_start + pd.Timedelta(days=3),
        test_start + pd.Timedelta(days=4),
    ])
    train_idx, test_idx, got_test_start = ml.time_split_indices(dates, label_ends, test_ratio=0.3)
    assert got_test_start == str(test_start.date())
    tr = set(int(i) for i in train_idx)
    assert 3 in tr, "标签在测试首日前的样本应保留"
    assert 4 in tr
    assert 5 not in tr, "标签恰好结束在测试首日的样本必须剔除"
    assert 6 not in tr, "标签跨到测试首日之后的样本必须剔除"
    assert set(int(i) for i in test_idx) == {7, 8, 9}
    le = pd.to_datetime(label_ends)
    for i in tr:
        assert le.iloc[i] < test_start, (i, le.iloc[i], test_start)


def test_ml_real_dataset_train_isolation():
    """真实数据集训练后复核：全部训练标签结束日 < 测试首日。"""
    import engine.ml as ml

    model, metrics = ml.train_model()
    assert model is not None, metrics
    assert metrics["isolation_ok"] is True, metrics
    assert metrics["max_train_label_end"] < metrics["test_start"], metrics
    assert metrics["n_train"] > 0 and metrics["n_test"] > 0, metrics


# ==================== C #12/16 长期因子预热 260 ====================

def test_score_warmup_constant_covers_lt_factor():
    from engine.backtest import SCORE_WARMUP

    assert SCORE_WARMUP >= 251, SCORE_WARMUP  # 250 日因子至少需要 251 根


def test_score_full_history_equals_260_warmup_slice():
    """同一日期：完整历史评分 vs “260 根预热后的测试切片”评分一致（差<0.6）。"""
    from engine.backtest import ScoreStrategy
    from engine.data import fetch

    df = fetch("159828", offline=True)
    assert len(df) > 700, len(df)
    start = 620          # 被比较的那一天在完整序列中的下标
    full = ScoreStrategy(45, 20, code="159828").generate_signals(df)
    full_score = float(full["score"].iloc[start])
    assert not np.isnan(full_score)

    slice_df = df.iloc[start - 260:start + 1].reset_index(drop=True)
    sl = ScoreStrategy(45, 20, code="159828").generate_signals(slice_df)
    slice_score = float(sl["score"].iloc[-1])
    assert not np.isnan(slice_score)
    # 旧实现只预热 60 根 → 250 日因子缺失，同一天分数会差出 5 分以上
    assert abs(full_score - slice_score) < 0.6, (full_score, slice_score, start)

    # 门槛 45：两者必须同买/同观望
    assert (full_score >= 45) == (slice_score >= 45), (full_score, slice_score)

    # 60 根预热的旧切片应确有偏差（证明测试本身有区分力，不依赖行情恰好一致）
    old_slice = df.iloc[start - 60:start + 1].reset_index(drop=True)
    old = ScoreStrategy(45, 20, code="159828").generate_signals(old_slice)
    old_score = float(old["score"].iloc[-1])
    assert not np.isnan(old_score)
    assert abs(old_score - full_score) >= 0.6 or (old_score >= 45) != (full_score >= 45), \
        f"60 根预热与完整历史无差异（{old_score} vs {full_score}），测试失去区分力"


def test_compare_warmup_bars_reports_260():
    """compare 接口预热根数如实返回 260（不再 60），曲线仍从 start 起。"""
    from engine.backtest import strategy_comparison

    r = strategy_comparison("159828", start="2023-01-01")
    assert "error" not in r, r
    assert r["warmup_bars"] == 260, r["warmup_bars"]
    first = r["curves"][list(r["curves"].keys())[0]]["dates"][0]
    assert first >= "2023-01-01", first


# ==================== D #19 回测账户从 trade_start 开始 ====================

def test_backtest_trade_start_no_warmup_position():
    """start 前 100→50、start 后 50→100：B&H 收益 ≈ +100%（旧实现按预热期建仓≈0%）。"""
    from engine.backtest import Backtest, BuyAndHoldStrategy

    n = 41
    dates = pd.date_range("2026-01-05", periods=n, freq="B")
    close = np.empty(n)
    for i in range(n):
        close[i] = 1.0 - 0.025 * i if i <= 20 else 0.5 + 0.025 * (i - 20)
    df = pd.DataFrame({
        "date": dates, "open": close, "high": close, "low": close,
        "close": close, "volume": 100000,
    })
    start = str(dates[20].date())
    r = Backtest(df, BuyAndHoldStrategy(), initial_capital=1000.0,
                 commission=0.0, slippage=0.0, enable_risk=False,
                 trade_start=start).run()
    assert "error" not in r, r
    # 从 start 当天开盘 0.5 买入 2000 份 → 期末 1.0 → 100%
    assert r["total_return"] == pytest.approx(100.0, abs=1.0), r["total_return"]
    assert r["final_equity"] == pytest.approx(2000.0, abs=1.0), r["final_equity"]
    assert r["trade_list"], "start 之后应有成交"
    assert all(t["date"][:10] >= start for t in r["trade_list"]), r["trade_list"]

    # 旧行为（不传 trade_start）会继承预热期建仓，收益被前置下跌污染
    old = Backtest(df, BuyAndHoldStrategy(), initial_capital=1000.0,
                   commission=0.0, slippage=0.0, enable_risk=False).run()
    assert old["total_return"] < 50.0, old["total_return"]


# ==================== E #08 再平衡总资金锚点 / 缺行情 ====================

def _fake_rebalance_scan(temp=50.0, weights=None):
    weights = weights or [{"code": "C1", "weight": 100.0}]
    return {
        "generated_at": "2026-11-09T00:00:00",
        "holdings": [],
        "portfolio": {"holdings": weights},
        "market": {"temp": temp, "avg_score": temp},
    }


def _patch_rebalance_env(monkeypatch):
    import engine.rebalance as rb
    import engine.signals as sig_mod

    fake_df = _flat_df(5, 1.0)
    state = {"scan": _fake_rebalance_scan()}

    def fake_fetch(code, offline=True):
        if code == "C2":       # 缺行情标的
            return pd.DataFrame()
        return fake_df

    monkeypatch.setattr(rb, "fetch", fake_fetch)
    monkeypatch.setattr(sig_mod, "scan_all_signals", lambda use_cache=True: state["scan"])
    monkeypatch.setattr(rb, "scan_all_signals", lambda use_cache=True: state["scan"], raising=False)
    return rb, state


def test_rebalance_default_path_no_repeat_reduction(monkeypatch):
    """默认接口（不传 total_capital）：第一次卖 500；模拟成交后再调默认接口 → 持有。"""
    from engine import db

    rb, state = _patch_rebalance_env(monkeypatch)
    db.apply_trade("BUY", "C1", price=1.0, shares=1000.0)

    r1 = rb.rebalance_plan()                     # 默认路径（API 无参调用）
    assert "error" not in r1, r1
    p1 = r1["plans"][0]
    assert p1["action"] == "卖出" and p1["sell_shares"] == 500, p1
    assert r1["total_equity"] == pytest.approx(1000.0), r1["total_equity"]
    assert r1["anchor_initialized"] is True
    assert "初始化" in r1["capital_source"], r1["capital_source"]

    # 模拟成交：卖出 500 份
    db.apply_trade("SELL", "C1", price=1.0, shares=500.0)

    r2 = rb.rebalance_plan()                     # 再次默认调用：50% 温度下目标仍 500
    p2 = r2["plans"][0]
    assert p2["action"] == "持有", f"半仓执行后默认接口仍在减仓: {p2}"
    assert p2["sell_shares"] == 0
    assert r2["total_equity"] == pytest.approx(1000.0), r2["total_equity"]
    # 锚点来自数据库，重启/刷新后仍有效
    assert db.get_app_meta("account_total_capital") is not None


def test_rebalance_missing_quote_marked_no_data(monkeypatch):
    """缺行情持仓：不报错、plans 标 no_data，目标市值按锚点照算（1000×40%×半仓=200）。"""
    from engine import db

    rb, state = _patch_rebalance_env(monkeypatch)
    state["scan"] = _fake_rebalance_scan(
        weights=[{"code": "C1", "weight": 60.0}, {"code": "C2", "weight": 40.0}])
    db.apply_trade("BUY", "C1", price=1.0, shares=500.0)
    db.apply_trade("BUY", "C2", price=1.0, shares=300.0)
    db.set_app_meta("account_total_capital", "1000")

    r = rb.rebalance_plan()                      # 默认路径
    assert "error" not in r, r
    assert r["valuation_complete"] is False
    assert [m["code"] for m in r["missing_quotes"]] == ["C2"]
    c2 = next(p for p in r["plans"] if p["code"] == "C2")
    assert c2["no_data"] is True, c2
    assert c2["price"] is None and c2["cur_mv"] is None and c2["cur_pct"] is None, c2
    assert c2["target_mv"] == pytest.approx(200.0, abs=0.01), c2   # 1000 × 40% × 0.5
    assert c2["action"] == "行情缺失", c2
    # 有行情的 C1 计算不受影响
    c1 = next(p for p in r["plans"] if p["code"] == "C1")
    assert c1["no_data"] is False and c1["cur_mv"] == pytest.approx(500.0)
    # 总额只统计有报价部分
    assert r["total_market_value"] == pytest.approx(500.0)


def test_reset_account_clears_capital_anchor(monkeypatch):
    from engine import db

    _patch_rebalance_env(monkeypatch)
    db.set_app_meta("account_total_capital", "1234")
    db.reset_account()
    assert db.get_app_meta("account_total_capital") is None


# ==================== F #21 首页缺报价实际渲染 ====================

def test_frontend_index_missing_quote_real_js():
    """实际执行 frontend/index.html 的内联 JS（Node + 最小 DOM 桩）：
    成本 100、缺报价 → 不出现 -100%；显示“—/行情缺失/不完整”。"""
    node = shutil.which("node")
    if not node:
        pytest.skip("node 不可用，跳过首页 JS 执行测试")
    script = Path(__file__).resolve().parent / "frontend" / "index_missing_quote_check.js"
    assert script.exists(), script
    proc = subprocess.run([node, str(script)], capture_output=True, text=True,
                          encoding="utf-8", errors="replace", timeout=120)
    assert proc.returncode == 0, (proc.stdout or "") + (proc.stderr or "")


# ==================== G #23 扫描缓存同锁 / 并发时序 ====================

def test_scan_cache_version_guard_rejects_stale_write():
    """版本检查与写入同一把锁：失效后旧版本结果必须被拒绝，缓存保持为空。"""
    import engine.signals as sm

    sm.invalidate_scan_cache()
    try:
        old_version = sm._scan_cache_version_start()
        sm.invalidate_scan_cache()               # 计算期间被失效
        assert sm._scan_cache_store({"stale": True}, old_version) is False
        assert sm._scan_cache["data"] is None, "旧版本结果覆盖了已失效的缓存"
        # 新版本可正常写入并被读取
        assert sm._scan_cache_store({"fresh": True}, sm._scan_cache_version_start()) is True
        assert sm.scan_all_signals(use_cache=True) == {"fresh": True}
    finally:
        sm.invalidate_scan_cache()


def test_scan_cache_concurrent_stale_scan_cannot_overwrite(monkeypatch):
    """线程 A 取版本后暂停；期间失效并完成线程 B 的新扫描；A 恢复后不得覆盖 B。"""
    import engine.signals as sm

    sm.invalidate_scan_cache()
    orig_build_advice = sm.build_advice
    entered = threading.Event()
    release = threading.Event()
    blocked_once = {"a": False}

    def wrapper(scan):
        if threading.current_thread().name == "scannerA" and not blocked_once["a"]:
            blocked_once["a"] = True
            entered.set()
            assert release.wait(60), "线程 A 未被放行"
        return orig_build_advice(scan)

    monkeypatch.setattr(sm, "build_advice", wrapper)
    results = {}

    def run_a():
        results["a"] = sm.scan_all_signals(use_cache=False)

    ta = threading.Thread(target=run_a, name="scannerA")
    ta.start()
    try:
        assert entered.wait(90), "线程 A 未进入扫描"
        sm.invalidate_scan_cache()                    # 版本 0 → 1
        results["b"] = sm.scan_all_signals(use_cache=False)   # 新版本扫描（主线程）
        cached_b = sm._scan_cache["data"]
        assert cached_b is results["b"], "新版本扫描未写入缓存"
        release.set()                                 # 放行旧扫描
        ta.join(120)
        assert not ta.is_alive()
        assert sm._scan_cache["data"] is cached_b, "旧版本扫描结果覆盖了新缓存"
        assert sm._scan_cache["data"] is not results["a"]
        assert sm.scan_all_signals(use_cache=True) is cached_b, "缓存读取不是新结果"
    finally:
        release.set()
        monkeypatch.undo()
        sm.invalidate_scan_cache()


# ==================== H 统一验证口径 ====================

def _missing_quote_scan():
    """含缺行情持仓（market_value/pnl_pct=None）的 scan：推荐/优化器不得 500。"""
    scan = _h_scan()
    scan["holdings"] = [{
        "code": "C9", "name": "缺行情标的", "shares": 300, "cost_price": 1.0,
        "current_price": None, "market_value": None, "no_data": True,
        "pnl_pct": None, "drawdown": None, "status": "数据缺失", "signal": "?",
        "score": None,
    }]
    return scan


def test_recommend_and_optimizer_tolerate_missing_quote_holding(monkeypatch):
    """第 21 项/F 回归：缺报价持仓的 market_value=None 不能参与 sum（否则页面 500）。"""
    import engine.optimizer as opt
    import engine.recommend as rec
    import engine.verify as ver

    monkeypatch.setattr(ver, "load_verify_map",
                        lambda: {"C1": {"verdict": "valid", "label": "✅ 有效", "test_sharpe": 1.1}})
    monkeypatch.setattr(rec, "_rolling_valid", lambda code, min_sharpe=0.3: "valid")
    monkeypatch.setattr(opt, "load_verify_map",
                        lambda: {"C1": {"verdict": "valid", "label": "✅ 有效"}})
    scan = _missing_quote_scan()

    r = rec.recommended_portfolio(scan=scan)          # 旧实现这里 TypeError → 页面 500
    assert isinstance(r, dict) and "recommended" in r, r
    assert r["small_capital_mode"] in (True, False)

    o = opt.optimize_rebalance(scan=scan)             # 旧实现这里 TypeError → 页面 500
    assert isinstance(o, dict) and "trade_plan" in o, list(o)[:6]
    assert isinstance(o.get("total_market_value"), (int, float))


def _h_scan():
    return {
        "generated_at": "2026-11-09T00:00:00",
        "signals": [
            {"code": "C1", "name": "有效标的", "signal": "BUY", "score": 90.0,
             "price": 1.0, "main_net_5d": 5000.0, "main_net": 100.0,
             "main_pct": 5.0, "main_pct_5d": 5.0, "main_streak": 1},
            {"code": "C2", "name": "无效标的", "signal": "BUY", "score": 88.0,
             "price": 1.0, "main_net_5d": 5000.0, "main_net": 100.0,
             "main_pct": 5.0, "main_pct_5d": 5.0, "main_streak": 1},
            {"code": "C3", "name": "一般标的", "signal": "BUY", "score": 80.0,
             "price": 1.0, "main_net_5d": 3000.0, "main_net": 50.0,
             "main_pct": 3.0, "main_pct_5d": 3.0, "main_streak": 1},
        ],
        "holdings": [],
        "market": {"temp": 70.0, "avg_score": 70.0},
        "discipline": {"allowed": True},
        "ml_signals": {},
    }


def test_recommend_uses_unified_verify_report(monkeypatch):
    """recommended 的 verify 必须来自 optimize_report_new.json 口径（不是滚动夏普）。"""
    import engine.recommend as rec
    import engine.verify as ver

    vmap = {
        "C1": {"verdict": "valid", "label": "✅ 有效", "test_sharpe": 1.1},
        "C2": {"verdict": "invalid", "label": "❌ 无效", "test_sharpe": -0.8},
        "C3": {"verdict": "weak", "label": "⚠️ 一般", "test_sharpe": 0.2},
    }
    monkeypatch.setattr(ver, "load_verify_map", lambda: vmap)
    # 即使滚动夏普把所有标的都算成 valid，也不得影响统一验证结论
    monkeypatch.setattr(rec, "_rolling_valid", lambda code, min_sharpe=0.3: "valid")

    r = rec.recommended_portfolio(scan=_h_scan())
    by_code = {x["code"]: x for x in r["recommended"]}
    assert by_code["C1"]["verify"] == "valid"
    assert by_code["C2"]["verify"] == "invalid", "recommended 仍在用滚动夏普判定"
    assert by_code["C2"]["verify_label"] == "❌ 无效"
    # rolling 只作附注字段保留
    assert by_code["C1"]["rolling_valid"] == "valid"
    # 统一口径字段
    assert "advice" in (r["action_authority"] or "")
    assert "optimize_report_new.json" in r["verify_source"]


def test_recommend_buy_set_subset_of_advice_buy(monkeypatch):
    """recommended.rotate 中的“买入”集合必须 ⊆ /api/signals/advice 的 buy 集合。"""
    import engine.recommend as rec
    import engine.signals as sm
    import engine.verify as ver

    vmap = {
        "C1": {"verdict": "valid", "label": "✅ 有效", "test_sharpe": 1.1},
        "C2": {"verdict": "invalid", "label": "❌ 无效", "test_sharpe": -0.8},
        "C3": {"verdict": "weak", "label": "⚠️ 一般", "test_sharpe": 0.2},
    }
    monkeypatch.setattr(ver, "load_verify_map", lambda: vmap)
    monkeypatch.setattr(rec, "_rolling_valid", lambda code, min_sharpe=0.3: "valid")

    scan = _h_scan()
    advice = sm.build_advice(scan)
    r = rec.recommended_portfolio(scan=scan)
    advice_buy = {x["code"] for x in advice["buy"]}
    rotate_buy = {x["code"] for x in r["rotate"] if x["action"] == "买入"}
    assert rotate_buy <= advice_buy, (rotate_buy, advice_buy)
    # 有效标的应出现在买入建议里（同门槛下两页一致）
    assert "C1" in rotate_buy and "C1" in advice_buy
    # 验证无效的 C2 即使进了推荐观察名单，也只能观望
    for x in r["rotate"]:
        if x["code"] == "C2":
            assert x["action"] == "观望", x
    # 响应显式给出两接口的买入集合，便于页面/测试核对一致
    assert set(r["advice_buy_codes"]) == advice_buy
