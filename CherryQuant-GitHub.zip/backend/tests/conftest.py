# -*- coding: utf-8 -*-
"""
CherryQuant 测试隔离：
默认把 engine.db 指到 pytest 临时目录，避免测试写入仓库内的真实 quant.db
（旧实现 test_core 的 stop_loss_check/reset_peak_on_buy 会在真库里写 peaks 等）。
行情 K 线仍读仓库 data/cache（只读），与本机/CI 行为一致。
"""
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


@pytest.fixture(autouse=True)
def isolated_db(tmp_path):
    from engine import db
    orig = db.DB_PATH
    db.DB_PATH = tmp_path / "test_quant.db"   # sqlite3.connect 接受 Path
    db.init_db()
    yield
    db.DB_PATH = orig
