# -*- coding: utf-8 -*-
"""
CherryQuant Web — 新增模块单元测试
覆盖: 量价分析、择时适用度、短期排名、风险平价
运行: python -m pytest backend/tests/ -q
"""
import sys
import os
import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ============ 量价分析 ============

def test_volume_price_basic():
    """量价分析：正常标的应返回完整字段"""
    from engine.volume_price import analyze_price_volume
    r = analyze_price_volume("516650")  # 有色
    if "error" in r:
        pytest.skip("数据不足")
    assert "health_score" in r
    assert "entry_verdict" in r
    assert "trend" in r
    assert "position" in r
    # 健康度 0-100
    assert 0 <= r["health_score"] <= 100
    # 进场判断合法
    assert r["entry_verdict"] in ("可买", "观望", "回避")


def test_volume_price_all_pool():
    """量价分析：全池每只都应能跑（不崩溃）"""
    from engine.volume_price import analyze_price_volume
    from engine.config import POOL
    for name, info in POOL.items():
        r = analyze_price_volume(info["code"])
        # 不抛异常即可
        assert "code" in r


# ============ 择时适用度 ============

def test_timing_fit_lookup():
    """择时适用度：每只标的都有判定"""
    from engine.timing_fit import get_timing_fit
    from engine.config import POOL
    for name, info in POOL.items():
        fit = get_timing_fit(info["code"])
        assert fit["verdict"] in ("择时", "躺平", "中性")
        assert "alpha" in fit
        assert "reason" in fit


def test_should_timing():
    """should_timing：躺平标的不该用择时"""
    from engine.timing_fit import should_timing
    # 有色是躺平
    assert should_timing("516650") is False
    # 医疗ETF是择时
    assert should_timing("159828") is True


def test_apply_timing_advice():
    """apply_timing_advice：给信号附加择时判定"""
    from engine.timing_fit import apply_timing_advice
    scan = {"signals": [
        {"code": "516650", "signal": "SELL"},
        {"code": "159828", "signal": "BUY"},
    ]}
    result = apply_timing_advice(scan)
    for s in result["signals"]:
        assert "timing_verdict" in s
        assert "timing_alpha" in s


# ============ 短期排名 ============

def test_ranking_structure():
    """短期排名：返回结构完整"""
    from engine.ranking import short_term_ranking
    r = short_term_ranking()
    assert "ranked" in r
    assert "summary" in r
    assert len(r["ranked"]) > 0
    # 排序正确：综合分降序
    combos = [x["combo"] for x in r["ranked"]]
    assert combos == sorted(combos, reverse=True)


def test_ranking_top_buys():
    """短期排名：top_buys 都是验证有效"""
    from engine.ranking import short_term_ranking
    r = short_term_ranking()
    for b in r["top_buys"]:
        assert b["verify"] == "valid"


# ============ 风险平价 ============

def test_risk_parity_weights():
    """风险平价：波动大的标的重配少"""
    # 用推荐组合验证 alloc_pct 合理性
    from engine.recommend import recommended_portfolio
    r = recommended_portfolio()
    recs = r["recommended"]
    assert len(recs) > 0
    for x in recs:
        assert "alloc_pct" in x
        # 资金占比合理 0-100
        assert 0 < x["alloc_pct"] <= 100


def test_recommend_summary():
    """推荐组合：summary 非空"""
    from engine.recommend import recommended_portfolio
    r = recommended_portfolio()
    assert r["summary"]
    assert len(r["recommended"]) >= 1


# ============ 评分边界 ============

def test_score_bounds():
    """评分：始终在 0-100 之间"""
    from engine.signals import _score
    # 极端多头
    s1 = _score(True, True, True, 70, 0.1, True, False, True, 2)
    assert 0 <= s1 <= 100
    # 极端空头
    s2 = _score(False, False, False, 20, -0.1, False, True, False, 1)
    assert 0 <= s2 <= 100
