# -*- coding: utf-8 -*-
"""迭代 A（现金账本）API 层验收测试 —— 契约 §2/§4。

测试策略：直接调用 `api.account_api` 里的处理函数与 `engine.account` 函数，
不依赖 httpx/TestClient（避免网络层与版本差异）；conftest.py 已把 engine.db
指到 pytest 临时库，不会触碰仓库真实库。

覆盖：
1. 入金 1000：equity.total_equity=1000、twr=0、cash=1000、账本有 DEPOSIT 行；
2. 出金 300 成功 / 超额出金 → HTTPException 400（detail 含“现金不足”，不写库）；
3. amount 非法（0/负数/NaN/±Inf）→ 400（入金与出金）；
4. equity 响应字段齐全（契约 §2 全部字段）且 total_equity = cash + market_value；
5. ledger 返回 base_cash/cash/entries，entries.cash_after 余额链自洽、limit 生效；
6. import-trades：preview 不写库 → confirm 写库（现金变化=Σ现金影响）→ 同批再
   confirm 全部 skipped_duplicates 且不重复写；重复行 preview 不再计入 to_import；
7. import-trades 非法行（action/price/shares 非法）→ 400；
8. 路由表面（5 个端点、方法正确）+ main.py 已挂载 /api/account。
"""
import math
import os
import sys
from pathlib import Path

import pytest
from fastapi import HTTPException

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# 契约 §2 get_account_equity 必须包含的全部字段
EQUITY_FIELDS = {
    "base_cash", "cash", "market_value", "total_equity", "realized_pnl",
    "unrealized_pnl", "total_fees", "twr", "twr_start", "twr_end", "twr_days",
    "twr_valuation_complete", "valuation_complete", "missing_quotes",
    "cash_source", "ledger_initialized", "asof", "note",
}
# 契约 §1/§2 账本行字段
ENTRY_FIELDS = {"id", "date", "type", "amount", "note", "trade_id", "cash_after"}
# 契约 §4 preview 响应字段（不多不少）
PREVIEW_FIELDS = {
    "preview", "total", "to_import", "skipped_duplicates", "duplicates",
    "cash_impact", "cash_after", "equity_after", "diff", "note",
}
# 契约 §4 confirm 响应字段（不多不少）
CONFIRM_FIELDS = {"ok", "imported", "skipped_duplicates", "cash", "total_equity"}


def api():
    from api import account_api
    return account_api


def acct():
    from engine import account
    return account


def dbf():
    from engine import db
    return db


# ============ 1. 入金 ============

def test_deposit_updates_equity_cash_ledger_and_twr_zero():
    a = api()
    res = a.deposit(a.CashIn(amount=1000, date="2026-11-10", note="初始入金"))

    # 契约 §4：{"ok":true,"entry":{...},"equity":{...}}
    assert res["ok"] is True
    assert set(res) == {"ok", "entry", "equity"}
    entry = res["entry"]
    assert ENTRY_FIELDS <= set(entry)
    assert entry["type"] == "DEPOSIT"
    assert entry["amount"] == pytest.approx(1000.0)
    assert entry["cash_after"] == pytest.approx(1000.0)
    assert entry["note"] == "初始入金"

    eq = res["equity"]
    assert eq["cash"] == pytest.approx(1000.0)
    assert eq["total_equity"] == pytest.approx(1000.0)
    assert eq["ledger_initialized"] is True

    # GET /equity：契约 §2 全字段 + TWR 口径（只有入金、无买卖 → TWR==0）
    full = a.equity()
    assert EQUITY_FIELDS <= set(full)
    assert full["cash"] == pytest.approx(1000.0)
    assert full["base_cash"] == pytest.approx(0.0)
    assert full["market_value"] == pytest.approx(0.0)
    assert full["total_equity"] == pytest.approx(1000.0)
    assert full["twr"] == 0, f"只有入金无买卖，TWR 必须为 0，实际 {full['twr']!r}"

    # 账本：DEPOSIT 行，余额链
    led = a.ledger()
    assert led["cash"] == pytest.approx(1000.0)
    assert led["base_cash"] == pytest.approx(0.0)
    deposits = [e for e in led["entries"] if e["type"] == "DEPOSIT"]
    assert len(deposits) == 1
    assert deposits[0]["amount"] == pytest.approx(1000.0)
    assert deposits[0]["cash_after"] == pytest.approx(1000.0)

    # engine 口径一致
    assert acct().cash_balance() == pytest.approx(1000.0)
    assert acct().ledger_initialized() is True


# ============ 2. 出金 / 超额出金 ============

def test_withdraw_ok_then_insufficient_cash_400_without_write():
    a = api()
    a.deposit(a.CashIn(amount=1000, date="2026-11-10"))

    res = a.withdraw(a.CashIn(amount=300, date="2026-11-11", note="取出部分"))
    assert res["ok"] is True
    assert res["entry"]["type"] == "WITHDRAW"
    assert res["entry"]["amount"] == pytest.approx(-300.0)   # 负=现金流出
    assert res["equity"]["cash"] == pytest.approx(700.0)
    assert a.equity()["cash"] == pytest.approx(700.0)

    # 超额出金 → 400，detail 明确“现金不足”，且不写库
    with pytest.raises(HTTPException) as ei:
        a.withdraw(a.CashIn(amount=10000))
    assert ei.value.status_code == 400
    assert "现金不足" in str(ei.value.detail)

    assert a.equity()["cash"] == pytest.approx(700.0)
    entries = a.ledger()["entries"]
    withdraws = [e for e in entries if e["type"] == "WITHDRAW"]
    assert len(withdraws) == 1
    assert acct().cash_balance() == pytest.approx(700.0)


# ============ 3. 非法 amount ============

@pytest.mark.parametrize("bad_amount", [0, -100, float("nan"),
                                        float("inf"), float("-inf")])
@pytest.mark.parametrize("endpoint", ["deposit", "withdraw"])
def test_invalid_amount_rejected_400(endpoint, bad_amount):
    a = api()
    fn = getattr(a, endpoint)
    with pytest.raises(HTTPException) as ei:
        fn(a.CashIn(amount=bad_amount))
    assert ei.value.status_code == 400
    # 不写库
    eq = a.equity()
    assert eq["cash"] == pytest.approx(0.0)
    assert a.ledger()["entries"] == []
    assert dbf().load_trades() == []


# ============ 4. equity 字段齐全 ============

def test_equity_response_has_all_contract_fields():
    a = api()
    a.deposit(a.CashIn(amount=2500, date="2026-11-10"))
    eq = a.equity()

    missing = EQUITY_FIELDS - set(eq)
    assert not missing, f"equity 缺少契约字段: {sorted(missing)}"

    # 基本类型/一致性
    assert eq["ledger_initialized"] is True
    assert eq["valuation_complete"] is True          # 无持仓 → 估值完整
    assert eq["missing_quotes"] == []
    assert eq["market_value"] == pytest.approx(0.0)
    assert eq["total_equity"] == pytest.approx(eq["cash"] + eq["market_value"])
    assert eq["total_equity"] == pytest.approx(2500.0)
    assert eq["realized_pnl"] == pytest.approx(0.0)
    assert eq["unrealized_pnl"] == pytest.approx(0.0)
    assert eq["total_fees"] == pytest.approx(0.0)
    assert eq["twr"] == 0
    assert isinstance(eq["asof"], str)      # 无持仓时可为空串（估值日字段口径）
    assert isinstance(eq["cash_source"], str) and eq["cash_source"]
    assert isinstance(eq["note"], str)
    assert isinstance(eq["twr_days"], int)
    assert isinstance(eq["twr_valuation_complete"], bool)
    assert isinstance(eq["valuation_complete"], bool)


# ============ 5. ledger 余额链 / limit ============

def test_ledger_running_cash_chain_consistent_and_limit():
    a = api()
    a.deposit(a.CashIn(amount=1000, date="2026-11-01"))
    a.deposit(a.CashIn(amount=500, date="2026-11-02"))
    a.withdraw(a.CashIn(amount=200, date="2026-11-03"))

    led = a.ledger(limit=50)
    assert set(led) >= {"base_cash", "cash", "entries", "note"}
    assert led["cash"] == pytest.approx(1300.0)
    assert led["base_cash"] == pytest.approx(0.0)

    cash_types = set(acct().CASH_EFFECT_TYPES)
    running = float(led["base_cash"])
    ordered = sorted(led["entries"], key=lambda e: e["id"])
    assert len(ordered) == 3
    for e in ordered:
        assert ENTRY_FIELDS <= set(e)
        if e["type"] in cash_types:
            running += float(e["amount"])
            assert e["cash_after"] == pytest.approx(running), \
                f"账本余额链不自洽: {e}"
    assert running == pytest.approx(led["cash"])
    assert running == pytest.approx(acct().cash_balance())

    # limit 生效（3 条 → 取 2 条）
    assert len(a.ledger(limit=2)["entries"]) == 2


# ============ 6. import-trades：preview → confirm → 幂等 ============

IMPORT_ROWS = [{
    "date": "2026-11-10", "action": "BUY", "code": "159828",
    "price": 1.5, "shares": 100, "fee": 0.5,
}]
# BUY_SETTLE(-price*shares) + FEE(-fee) = -150 - 0.5
EXPECTED_CASH_IMPACT = -(1.5 * 100 + 0.5)


def test_import_trades_preview_does_not_write_then_confirm_writes_idempotent():
    a, db = api(), dbf()
    a.deposit(a.CashIn(amount=1000, date="2026-11-10"))
    cash_before = a.equity()["cash"]
    assert cash_before == pytest.approx(1000.0)

    # ---- preview=false：不写库，返回契约 §4 预览字段 ----
    prev = a.import_trades(a.ImportTradesIn(trades=IMPORT_ROWS, confirm=False))
    assert set(prev) == PREVIEW_FIELDS, f"preview 响应字段与契约不一致: {sorted(prev)}"
    assert prev["preview"] is True
    assert prev["total"] == 1
    assert prev["to_import"] == 1
    assert prev["skipped_duplicates"] == 0
    assert prev["duplicates"] == []
    assert prev["cash_impact"] == pytest.approx(EXPECTED_CASH_IMPACT)
    assert prev["cash_after"] == pytest.approx(cash_before + EXPECTED_CASH_IMPACT)
    assert isinstance(prev["equity_after"], (int, float))
    assert isinstance(prev["diff"], list)
    assert isinstance(prev["note"], str)

    # 预览确实没写库：trades 行数、现金、账本条目数都不变
    assert db.load_trades() == []
    assert a.equity()["cash"] == pytest.approx(cash_before)
    assert len(a.ledger()["entries"]) == 1          # 只有那张 DEPOSIT

    # ---- confirm=true：单事务写库，现金变化 = Σ影响 ----
    res = a.import_trades(a.ImportTradesIn(trades=IMPORT_ROWS, confirm=True))
    assert set(res) == CONFIRM_FIELDS, f"confirm 响应字段与契约不一致: {sorted(res)}"
    assert res["ok"] is True
    assert res["imported"] == 1
    assert res["skipped_duplicates"] == 0
    assert res["cash"] == pytest.approx(cash_before + EXPECTED_CASH_IMPACT)

    eq = a.equity()
    assert eq["cash"] == pytest.approx(cash_before + EXPECTED_CASH_IMPACT)
    assert eq["total_equity"] == pytest.approx(eq["cash"] + eq["market_value"])
    assert res["total_equity"] == pytest.approx(eq["total_equity"])

    # 写入的 trades 行：fee/cash_after 列口径正确（§2）
    trades = db.load_trades()
    assert len(trades) == 1
    t = trades[0]
    assert t["action"] == "BUY" and t["code"] == "159828"
    assert t["fee"] == pytest.approx(0.5)
    assert t["cash_after"] == pytest.approx(eq["cash"])   # 最后一笔 → 余额即当前现金
    assert t["realized_pnl"] == pytest.approx(0.0)        # 买入实现盈亏=0

    # 账本逐笔：DEPOSIT(+1000) / BUY_SETTLE(-150) / FEE(-0.5)
    entries = sorted(a.ledger(limit=50)["entries"], key=lambda e: e["id"])
    assert [e["type"] for e in entries] == ["DEPOSIT", "BUY_SETTLE", "FEE"]
    assert [e["amount"] for e in entries] == pytest.approx([1000.0, -150.0, -0.5])
    assert [e["cash_after"] for e in entries] == pytest.approx([1000.0, 850.0, 849.5])

    # ---- 同一批再 confirm：全部 skipped_duplicates，不重复写 ----
    res2 = a.import_trades(a.ImportTradesIn(trades=IMPORT_ROWS, confirm=True))
    assert set(res2) == CONFIRM_FIELDS
    assert res2["imported"] == 0
    assert res2["skipped_duplicates"] == 1
    assert res2["cash"] == pytest.approx(cash_before + EXPECTED_CASH_IMPACT)
    assert len(db.load_trades()) == 1
    assert a.equity()["cash"] == pytest.approx(cash_before + EXPECTED_CASH_IMPACT)
    assert len(a.ledger()["entries"]) == 3          # 无重复记账

    # 重复行 preview：不计入 to_import / cash_impact，duplicates 可见
    prev2 = a.import_trades(a.ImportTradesIn(trades=IMPORT_ROWS, confirm=False))
    assert prev2["total"] == 1
    assert prev2["to_import"] == 0
    assert prev2["skipped_duplicates"] == 1
    assert len(prev2["duplicates"]) == 1
    assert prev2["cash_impact"] == pytest.approx(0.0)
    assert prev2["cash_after"] == pytest.approx(cash_before + EXPECTED_CASH_IMPACT)


@pytest.mark.parametrize("bad_row", [
    {"date": "2026-07-31", "action": "HOLD", "code": "159828", "price": 1.5, "shares": 100},   # action 非法
    {"date": "2026-07-31", "action": "BUY", "code": "159828", "price": 0, "shares": 100},      # price=0
    {"date": "2026-07-31", "action": "BUY", "code": "159828", "price": -1.5, "shares": 100},   # price<0
    {"date": "2026-07-31", "action": "BUY", "code": "159828", "price": 1.5, "shares": 0},      # shares=0
    {"date": "2026-07-31", "action": "BUY", "code": "159828", "price": 1.5, "shares": -100},   # shares<0
])
def test_import_trades_invalid_row_rejected_400(bad_row):
    a = api()
    a.deposit(a.CashIn(amount=1000, date="2026-11-10"))
    db = dbf()
    with pytest.raises(HTTPException) as ei:
        a.import_trades(a.ImportTradesIn(trades=[bad_row], confirm=True))
    assert ei.value.status_code == 400
    # 非法行 → 整批拒绝、不写库
    assert db.load_trades() == []
    assert a.equity()["cash"] == pytest.approx(1000.0)
    assert len(a.ledger()["entries"]) == 1

    # 预览同样必须 400（非法行不能给出可信的兑换结果）
    with pytest.raises(HTTPException) as ei2:
        a.import_trades(a.ImportTradesIn(trades=[bad_row], confirm=False))
    assert ei2.value.status_code == 400


# ============ 8. 路由表面 + main.py 挂载 ============

def test_account_router_surface_and_main_mount():
    a = api()
    surface = {}
    for r in a.router.routes:
        surface.setdefault(r.path, set()).update(r.methods or set())
    assert surface.get("/equity") == {"GET"}
    assert surface.get("/ledger") == {"GET"}
    assert surface.get("/deposit") == {"POST"}
    assert surface.get("/withdraw") == {"POST"}
    assert surface.get("/import-trades") == {"POST"}

    # main.py 必须把 account_api 挂到 /api/account（契约 §0/§4 的两处改动）
    main_src = (Path(__file__).resolve().parents[1] / "main.py").read_text(encoding="utf-8")
    assert "account_api" in main_src
    assert 'prefix="/api/account"' in main_src
