# -*- coding: utf-8 -*-
"""2026-11-08 GPT 复查问题的回归测试

覆盖：
1. 手动记账字段不错列（name/amount/price/shares）
2. 回测现金守恒：卖出回笼累加、买入手数预留佣金、期末净值=本金（零成本平盘）
3. 组合回测：跳过无数据标的后本金/曲线一致
4. 再平衡：传 total_capital 时不会“半仓后再半仓”重复减仓
5. 风控统一：温度<40 时 optimizer 不产出加仓/买入；recommend 不给买入/加仓
6. 信号时点：指标在“最后一根已收盘K线”上计算（不再多滞后一天）
"""
import sys
import os

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ============ 1. 记账字段 ============

def test_add_trade_columns_are_correct():
    from engine import db
    db.add_trade("2026-01-01", "BUY", "159828",
                 amount=150.0, price=1.5, shares=100.0, name="医疗ETF")
    t = db.load_trades()[-1]
    assert t["name"] == "医疗ETF"
    assert t["amount"] == 150.0
    assert t["price"] == 1.5
    assert t["shares"] == 100.0
    # 金额 = 份数 × 价格（口径自洽）
    assert abs(t["amount"] - t["shares"] * t["price"]) < 0.01


def test_add_trade_signature_order():
    """签名必须是 (date, action, code, amount, price, shares, name=None)"""
    import inspect
    from engine import db
    params = list(inspect.signature(db.add_trade).parameters)
    assert params[:4] == ["date", "action", "code", "amount"], params


# ============ 2. 回测现金守恒 ============

def _flat_df(days=8, price=3.0):
    dates = pd.date_range("2026-01-05", periods=days, freq="B")
    return pd.DataFrame({
        "date": dates,
        "open": price, "high": price, "low": price, "close": price,
        "volume": 100000,
    })


class _FixedSignal:
    """最小策略：直接给出 signal 列（1买/-1卖/0不动）。"""

    def __init__(self, sig):
        self.sig = sig
        self.name = "fixed"

    def generate_signals(self, df):
        d = df.copy()
        d["signal"] = self.sig[:len(d)]
        return d


def test_backtest_cash_conservation_flat_zero_cost():
    """平盘、零费用：1000 本金最后必须还是 1000（旧实现会变 900）。"""
    from engine.backtest import Backtest
    df = _flat_df(8, 3.0)
    sig = [1, 0, -1, 0, 0, 0, 0, 0]   # 第2根开盘买、第4根开盘卖
    bt = Backtest(df, _FixedSignal(sig), initial_capital=1000.0,
                  commission=0.0, slippage=0.0, enable_risk=False)
    r = bt.run()
    assert r["equity_curve"][-1] == pytest.approx(1000.0, abs=0.01), r["equity_curve"]
    assert r["equity_curve"][-1] > 0


def test_backtest_buy_lots_leave_room_for_commission():
    """1000 元、1 元/份、佣金万三：不能买 1000 份（会负现金），应买 900 份。"""
    from engine.backtest import Backtest
    df = _flat_df(8, 1.0)
    sig = [1, 0, -1, 0, 0, 0, 0, 0]
    bt = Backtest(df, _FixedSignal(sig), initial_capital=1000.0,
                  commission=0.0003, slippage=0.0, enable_risk=False)
    r = bt.run()
    buys = [t for t in r["trade_list"] if t["action"] == "BUY"]
    assert buys and buys[0]["shares"] == 900, buys
    assert min(r["equity_curve"]) >= 0


# ============ 3. 组合回测：缺数据标的不吞资金 ============

def test_portfolio_backtest_capital_after_skipping_missing_code():
    from engine.portfolio_backtest import portfolio_backtest
    r = portfolio_backtest(codes=["159828", "999999"], capital=100000)
    assert "error" not in r, r
    assert r["initial_capital"] == pytest.approx(100000, abs=1)
    # 只有 1 只有数据 → 曲线起点仍应是全部本金，而不是一半
    assert r["equity_curve"][0] == pytest.approx(100000, abs=1), r["equity_curve"][:3]
    assert r["n_holdings"] == 1


# ============ 4. 再平衡：不重复减仓 ============

def _fake_rebalance_env(monkeypatch):
    import engine.rebalance as rb

    fake_df = pd.DataFrame({
        "date": pd.date_range("2026-01-01", periods=5, freq="B"),
        "open": 1.0, "high": 1.0, "low": 1.0, "close": 1.0, "volume": 100,
    })
    scan = {
        "generated_at": "2026-11-08T00:00:00",
        "holdings": [{"code": "C1", "name": "测试ETF", "market_value": 1000.0,
                      "shares": 1000, "pnl_pct": 0.0, "status": "正常",
                      "current_price": 1.0}],
        "portfolio": {"holdings": [{"code": "C1", "weight": 100.0}]},
        "market": {"temp": 50.0, "avg_score": 50.0},
    }
    monkeypatch.setattr(rb, "fetch", lambda code, offline=True: fake_df)
    monkeypatch.setattr(rb.db, "load_positions",
                        lambda: {"C1": {"shares": 1000, "name": "测试ETF",
                                        "cost_price": 1.0, "cost": 1000.0}})
    import engine.signals as sig_mod
    monkeypatch.setattr(sig_mod, "scan_all_signals", lambda use_cache=True: scan)


def test_rebalance_no_repeat_half_reduction(monkeypatch):
    _fake_rebalance_env(monkeypatch)
    import engine.rebalance as rb

    # 不传总资金：按持仓市值算，50% 温度 → 目标 500 → 卖 500（旧口径）
    r1 = rb.rebalance_plan()
    sell1 = r1["plans"][0]["sell_shares"] if r1["plans"][0]["action"] == "卖出" else 0
    assert sell1 == 500, r1["plans"][0]

    # 传总资金（现金+持仓=2000）：目标 1000 = 当前市值 → 不再减仓
    r2 = rb.rebalance_plan(total_capital=2000)
    assert r2["plans"][0]["action"] == "持有", r2["plans"][0]
    assert r2["total_equity"] == 2000
    assert "外部传入" in r2["capital_source"]


# ============ 5. 风控统一 ============

def _fake_scan(temp=30.0):
    return {
        "generated_at": "2026-11-08T00:00:00",
        "signals": [{
            "code": "C1", "name": "测试ETF", "signal": "BUY", "score": 90.0,
            "price": 1.0, "main_net_5d": 5000.0, "main_net": 100.0,
            "main_pct": 5.0, "main_pct_5d": 5.0, "main_streak": 1,
        }],
        "holdings": [{
            "code": "C1", "name": "测试ETF", "shares": 1000, "price": 1.0,
            "cost_price": 1.0, "current_price": 1.0, "market_value": 1000.0,
            "pnl_pct": 5.0, "status": "正常", "signal": "BUY", "score": 90.0,
            "main_net_5d": 5000.0, "main_net": 100.0,
        }],
        "market": {"temp": temp, "avg_score": temp},
        "discipline": {"allowed": True, "msg": "可买入"},
        "ml_signals": {},
    }


def test_optimizer_gates_add_when_market_cold(monkeypatch):
    import engine.optimizer as opt
    monkeypatch.setattr(opt, "load_verify_map",
                        lambda: {"C1": {"verdict": "valid", "label": "有效"}})
    r = opt.optimize_rebalance(scan=_fake_scan(temp=30.0))
    actions = [p["action"] for p in r["trade_plan"]]
    assert "加仓" not in actions and "买入" not in actions, actions
    # 可复制指令里不应再出现加仓/买入行（“买入/加仓≈x元”的结余模板行不算）
    order_lines = [ln for ln in r["order_text_full"].splitlines() if ln.strip()]
    assert not any(ln.startswith("加仓 ") or ln.startswith("买入 ") for ln in order_lines), order_lines
    assert any("纪律=空仓" in n for n in r["risk_notes"]), r["risk_notes"]
    # 持仓建议里也不能再出现“加仓”
    assert all(h["action"] != "加仓" for h in r["holdings_plan"])


def test_optimizer_keeps_add_when_market_hot(monkeypatch):
    import engine.optimizer as opt
    monkeypatch.setattr(opt, "load_verify_map",
                        lambda: {"C1": {"verdict": "valid", "label": "有效"}})
    r = opt.optimize_rebalance(scan=_fake_scan(temp=70.0))
    assert any(h["action"] == "加仓" for h in r["holdings_plan"]), r["holdings_plan"]


def _fake_recommend_scan(temp=30.0):
    scan = _fake_scan(temp=temp)
    scan["signals"].append({
        "code": "C2", "name": "新标的", "signal": "BUY", "score": 85.0,
        "price": 2.0, "main_net_5d": 3000.0, "main_net": 50.0,
        "main_pct": 3.0, "main_pct_5d": 3.0, "main_streak": 1,
    })
    # C1 已触发止损 → 不允许加仓
    scan["holdings"][0]["status"] = "止损触发"
    return scan


def test_recommend_gates_buy_and_add(monkeypatch):
    import engine.recommend as rec
    scan = _fake_recommend_scan(temp=30.0)
    r = rec.recommended_portfolio(scan=scan)
    acts = [x["action"] for x in r["rotate"]]
    assert "买入" not in acts and "加仓" not in acts, r["rotate"]
    # 止损持仓必须给卖出/止盈，而不是加仓
    stop_items = [x for x in r["rotate"] if x["code"] == "C1"]
    assert stop_items and stop_items[0]["action"] in ("卖出", "止盈"), stop_items


# ============ 6. 信号时点：最后一根已收盘K线 ============

def test_signal_uses_last_closed_bar_no_extra_lag():
    from engine.signals import gen_signal
    n = 70
    dates = pd.date_range("2026-06-01", periods=n, freq="B")
    close = np.ones(n)
    close[-7] = 1.0
    close[-6] = 1.0
    close[-2] = 1.01     # 上一交易日 5 日动量 1%
    close[-1] = 1.31     # 最后一根 5 日动量 31%
    df = pd.DataFrame({
        "date": dates, "open": close, "high": close * 1.01,
        "low": close * 0.99, "close": close, "volume": 100000,
    })
    info = {"code": "159828", "buy_th": 50, "sell_th": 30}
    r = gen_signal("医疗ETF", info, df, sector_mom_map={})
    assert r is not None
    # 旧实现 lag=True 会返回 1.0（上一交易日动量），新实现应为 31.0
    assert r["mom5"] == pytest.approx(31.0, abs=0.2), r["mom5"]
    assert r["date"] == dates[-1].strftime("%Y-%m-%d")


# ============ 7. 权重上限：迭代限权不突破单只 40% ============

def test_weight_cap_iterative():
    import engine.recommend as rec
    scan = {
        "generated_at": "2026-11-09T00:00:00",
        "signals": [
            {"code": "C1", "name": "A", "signal": "BUY", "score": 100.0, "price": 1.0,
             "main_net_5d": 5000.0, "main_net": 100.0, "main_pct": 5.0,
             "main_pct_5d": 5.0, "main_streak": 1},
            {"code": "C2", "name": "B", "signal": "BUY", "score": 100.0, "price": 1.0,
             "main_net_5d": 5000.0, "main_net": 100.0, "main_pct": 5.0,
             "main_pct_5d": 5.0, "main_streak": 1},
        ],
        "holdings": [],
        "market": {"temp": 70.0, "avg_score": 70.0},
        "discipline": {"allowed": True},
        "ml_signals": {},
    }
    r = rec.recommended_portfolio(scan=scan)
    allocs = [x.get("alloc_pct", 0) for x in r["recommended"]]
    assert allocs, r
    assert max(allocs) <= 40.0 + 1e-6, allocs


# ============ 8. 对比接口：start 应用到曲线 ============

def test_compare_start_applied():
    from engine.backtest import strategy_comparison
    r = strategy_comparison("159828", start="2023-01-01")
    assert "error" not in r, r
    assert r.get("start") == "2023-01-01"
    k = list(r["curves"].keys())[0]
    first = r["curves"][k]["dates"][0]
    assert first >= "2023-01-01", (first, "曲线没有从 start 开始")
