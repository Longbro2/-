# -*- coding: utf-8 -*-
"""24 项任务：第 12/13/16/20/21/22/23 项回归测试（+ 第 02 项 API 层 400 校验）"""
import sys
import os

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ============ 02 API 层校验 ============

def test_api_rejects_invalid_trade_with_400():
    from fastapi import HTTPException
    from api.portfolio_api import add_trade, TradeIn

    with pytest.raises(HTTPException) as ei:
        add_trade(TradeIn(action="INVALID", code="159828", price=1.5, shares=100))
    assert ei.value.status_code == 400
    with pytest.raises(HTTPException) as ei2:
        add_trade(TradeIn(action="SELL", code="159828", price=1.5, shares=100))  # 未持有
    assert ei2.value.status_code == 400


# ============ 12 回测评分与线上同分 ============

def test_backtest_score_matches_live_score():
    from engine.data import fetch
    from engine.signals import gen_signal
    from engine.backtest import ScoreStrategy
    from engine.config import SCORE_LT_TERM

    df = fetch("159828", offline=True)
    assert len(df) > 300
    c = df["close"]
    r60 = (c.iloc[-1] / c.iloc[-61] - 1) * 100
    r20 = (c.iloc[-1] / c.iloc[-21] - 1) * 100
    r5 = (c.iloc[-1] / c.iloc[-6] - 1) * 100
    momentum = r60 * 0.4 + r20 * 0.35 + r5 * 0.25
    if r60 > 5 and r5 > -2:
        tq = "强趋势"
    elif r60 > 5 and r20 < 0 and r5 > 0:
        tq = "回调企稳"
    elif r60 < -10 and r5 > 3:
        tq = "超跌反弹"
    elif r60 < -5:
        tq = "下跌趋势"
    else:
        tq = "震荡"

    live = gen_signal("医疗ETF", {"code": "159828", "buy_th": 50, "sell_th": 30},
                      df, sector_mom_map={"159828": {"momentum": momentum,
                                                     "trend_quality": tq}})
    assert live is not None
    st = ScoreStrategy(50, 30, code="159828")
    d = st.generate_signals(df)
    bt_score = float(d["score"].iloc[-1])
    # 同一时点、同一因子配置 → 同分（容差仅浮点/仓位无关）
    assert abs(bt_score - live["score"]) < 0.6, (bt_score, live["score"])
    assert SCORE_LT_TERM in (True, False)


def test_score_strategy_declares_factor_config():
    from engine.backtest import ScoreStrategy
    st = ScoreStrategy(50, 30)
    assert st.use_fflow is True
    assert st.use_sector is True
    assert hasattr(st, "use_lt")
    assert "资金流" in st.name and "板块" in st.name


# ============ 13 在线/回测止盈规则统一 ============

def test_fixed_take_profit_active_even_with_trailing():
    from engine.risk_rules import evaluate_risk
    r = evaluate_risk(1.0, 1.2, 1.19, r60=None)   # +19% 盈利，回落 0.8%
    assert r["take_profit"] is True, r
    assert r["pnl_pct"] > 15


def test_backtest_and_online_take_profit_agree():
    from engine.backtest import Backtest, BuyAndHoldStrategy
    from engine.risk_rules import evaluate_risk

    n = 40
    close = np.linspace(1.0, 1.19, n)
    dates = pd.date_range("2026-01-01", periods=n, freq="B")
    df = pd.DataFrame({"date": dates, "open": close, "high": close,
                       "low": close, "close": close, "volume": 100000})
    r = Backtest(df, BuyAndHoldStrategy(), enable_risk=True,
                 commission=0.0, slippage=0.0).run()
    sells = [t for t in r["trade_list"] if t["action"] == "SELL"]
    assert sells, r["trade_list"]
    assert any("止盈" in t.get("reason", "") for t in sells), sells

    # 在线：同价格状态也应触发止盈
    online = evaluate_risk(1.0, 1.19, 1.19, r60=None)
    assert online["take_profit"] is True


# ============ 16 样本外验证：预热 + 评估不足标记 ============

def test_find_best_thresholds_has_evaluation_and_score_config():
    from engine.backtest import find_best_thresholds
    r = find_best_thresholds("159828", test_ratio=0.3)
    assert r is not None, "数据不足"
    assert "evaluation" in r and "score_config" in r
    ev = r["evaluation"]
    assert ev["test_bars"] > 0 and ev["warmup_bars"] > 0
    assert isinstance(ev["insufficient"], bool)
    # 测试期有成交时才允许给出“有效/无效”级别结论
    if ev["test_trades"] == 0:
        assert ev["insufficient"] is True


# ============ 20 摘要风险距离服从触发状态 ============

def _fake_scan_with_stopped_holding():
    return {
        "generated_at": "2026-11-09T00:00:00",
        "market": {"temp": 55, "avg_score": 55, "buy": 10, "hold": 9, "sell": 1,
                   "count": 20, "status": "中性"},
        "discipline": {"allowed": True, "msg": "可买入"},
        "holdings": [{
            "code": "159828", "name": "医疗ETF", "shares": 100, "cost_price": 1.0,
            "current_price": 1.05, "market_value": 105.0, "cost": 100.0,
            "pnl_pct": 5.0, "drawdown": -19.2, "peak": 1.3,
            "status": "止损触发", "signal": "HOLD", "score": 50,
            "risk_thresholds": {"adaptive": False, "stop_loss": -10.0,
                                "stop_drawdown": -8.0, "take_profit": 15.0,
                                "use_trailing_stop": True, "trailing_activate": 8.0,
                                "trailing_stop": -8.0},
        }],
        "instructions": [], "portfolio": None,
    }


def test_summary_risk_distance_not_safe_when_stopped(monkeypatch):
    from api import summary_api
    monkeypatch.setattr("engine.signals.scan_all_signals",
                        lambda use_cache=True: _fake_scan_with_stopped_holding())
    monkeypatch.setattr("engine.macro.analyze_macro", lambda: {})
    res = summary_api.daily_summary()
    d = res["risk_distance"][0]
    assert d["level"] == "danger", d
    assert d["status"] == "止损触发"
    # 有效止损线 = max(成本止损 0.90, 峰值回撤 1.3*0.92=1.196) → 1.196
    assert d["stop"] == pytest.approx(1.196, abs=1e-3)
    # 有效止盈线 = min(固定 1.15, 移动 1.196) → 1.15
    assert d["take"] == pytest.approx(1.15, abs=1e-3)


# ============ 21 缺报价不冒充 0 ============

def test_positions_missing_quote_marks_incomplete(monkeypatch):
    from engine import db
    from api import portfolio_api
    monkeypatch.setattr(db, "load_positions", lambda: {
        "159828": {"shares": 100, "cost": 100.0, "cost_price": 1.0,
                   "date": "2026-11-01", "name": "医疗ETF"}})
    monkeypatch.setattr("engine.signals.fetch", lambda code, offline=True: pd.DataFrame())
    res = portfolio_api.positions()
    assert res["valuation_complete"] is False
    assert res["missing_quotes"] and res["missing_quotes"][0]["code"] == "159828"
    p = res["positions"][0]
    assert p["current_price"] is None and p["market_value"] is None and p["no_data"] is True
    assert res["total_pnl"] == 0.0          # 不再出现 -100
    assert res["total_market_value"] == 0.0


# ============ 22 风险/相关性：缺失标的对齐 ============

def test_portfolio_risk_skips_missing_codes(monkeypatch):
    from engine.data import fetch as real_fetch
    from engine import risk
    real = real_fetch("159828", offline=True)
    monkeypatch.setattr(risk, "fetch",
                        lambda code, offline=True: real if code == "159828" else pd.DataFrame())
    r = risk.portfolio_risk(codes=["159828", "999999"])
    assert "error" not in r, r
    assert r["codes"] == ["159828"]
    assert r["missing_codes"] == ["999999"]
    assert len(r["holdings"]) == 1


def test_correlation_skips_missing_codes(monkeypatch):
    from engine.data import fetch as real_fetch
    from engine import correlation
    real = real_fetch("159828", offline=True)
    monkeypatch.setattr(correlation, "fetch",
                        lambda code, offline=True: real if code == "159828" else pd.DataFrame())
    r = correlation.correlation_matrix(codes=["159828", "999999"])
    assert r["missing_codes"] == ["999999"]
    assert r["codes"] == ["159828"]


# ============ 23 扫描缓存失效语义 ============

def test_scan_cache_invalidation_bumps_version_and_clears():
    from engine import signals
    before = signals._scan_cache_version
    signals._scan_cache = {"ts": 123, "data": {"stale": True}}
    signals.invalidate_scan_cache()
    assert signals._scan_cache_version == before + 1
    assert signals._scan_cache["data"] is None
