# -*- coding: utf-8 -*-
"""
CherryQuant Web — 单元测试
运行: python -m pytest backend/tests/ 或 python backend/tests/test_core.py
覆盖: 胜率FIFO、止损止盈、评分、数据边界
"""
import sys
import os
import pytest
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ============ 胜率 FIFO 配对 ============

def test_win_rate_single():
    from engine.backtest import win_rate_from_trades
    trades = [
        {"date": "2026-01-01", "action": "BUY", "price": 10, "shares": 100},
        {"date": "2026-01-10", "action": "SELL", "price": 12, "shares": 100},
    ]
    assert win_rate_from_trades(trades) == 100.0


def test_win_rate_batch_buy():
    """分批买入3次，一次性卖出 → FIFO配对"""
    from engine.backtest import win_rate_from_trades
    trades = [
        {"date": "2026-01-01", "action": "BUY", "price": 10, "shares": 100},
        {"date": "2026-01-05", "action": "BUY", "price": 11, "shares": 100},
        {"date": "2026-01-08", "action": "BUY", "price": 9, "shares": 100},
        {"date": "2026-01-15", "action": "SELL", "price": 11, "shares": 300},
    ]
    # 10→11赚, 11→11平, 9→11赚 → 2/3 = 66.7
    assert win_rate_from_trades(trades) == pytest.approx(66.7, abs=0.1)


def test_win_rate_partial_sell():
    from engine.backtest import win_rate_from_trades
    trades = [
        {"date": "2026-01-01", "action": "BUY", "price": 10, "shares": 200},
        {"date": "2026-01-10", "action": "SELL", "price": 12, "shares": 100},
        {"date": "2026-01-15", "action": "SELL", "price": 9, "shares": 100},
    ]
    # 10→12赚, 10→9亏 → 1/2 = 50
    assert win_rate_from_trades(trades) == 50.0


def test_win_rate_unsorted():
    """先卖后买（乱序）→ 按时间排序后正确"""
    from engine.backtest import win_rate_from_trades
    trades = [
        {"date": "2026-01-05", "action": "SELL", "price": 12, "shares": 100},
        {"date": "2026-01-01", "action": "BUY", "price": 10, "shares": 100},
    ]
    assert win_rate_from_trades(trades) == 100.0


def test_win_rate_no_sell():
    from engine.backtest import win_rate_from_trades
    trades = [{"date": "2026-01-01", "action": "BUY", "price": 10, "shares": 100}]
    assert win_rate_from_trades(trades) == 0.0


# ============ 止损止盈 ============

def test_stop_loss():
    from engine.signals import stop_loss_check
    pos = {"shares": 100, "cost_price": 1.0, "cost": 100}
    sl = stop_loss_check("test", pos, 0.85)  # -15%
    assert sl["stop_triggered"] is True


def test_take_profit():
    from engine.signals import stop_loss_check
    pos = {"shares": 100, "cost_price": 1.0, "cost": 100}
    sl = stop_loss_check("test", pos, 1.16)  # +16%
    assert sl["take_profit"] is True


def test_no_trigger_normal():
    from engine.signals import stop_loss_check, reset_peak_on_buy
    # 重置峰值，避免测试间共享DB状态导致误判
    reset_peak_on_buy("test", 1.0)
    pos = {"shares": 100, "cost_price": 1.0, "cost": 100}
    sl = stop_loss_check("test", pos, 1.05)  # +5%
    assert sl["stop_triggered"] is False
    assert sl["take_profit"] is False


# ============ 评分 ============

def test_score_fflow_boost():
    """资金流为正应加分"""
    from engine.signals import _score
    s_no = _score(True, False, True, 50, 0.0)
    s_ff = _score(True, False, True, 50, 0.0, fflow5=500, fflow5_pct=5.0)
    assert s_ff > s_no


def test_score_fflow_penalty():
    """资金流为负应减分"""
    from engine.signals import _score
    s_no = _score(True, False, True, 50, 0.0)
    s_ff = _score(True, False, True, 50, 0.0, fflow5=-500, fflow5_pct=-5.0)
    assert s_ff < s_no


# ============ 数据边界 ============

def test_empty_backtest():
    from engine.backtest import Backtest, BuyAndHoldStrategy
    bt = Backtest(pd.DataFrame(), BuyAndHoldStrategy())
    r = bt.run()
    assert "error" in r


if __name__ == "__main__":
    sys.exit(pytest.main([__file__, "-v"]))
