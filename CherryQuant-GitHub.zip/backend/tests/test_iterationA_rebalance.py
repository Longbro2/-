# -*- coding: utf-8 -*-
"""迭代 A（现金账本）再平衡回归测试。

契约：D:\\ds\\CherryQuant-迭代A-资金账本-契约与分工.md §5
验收点：
  1. 账本已初始化（deposit 后）→ 默认 rebalance_plan() 的 total_equity = 现金 + 持仓市值
     （不再是持仓市值/旧锚点），响应带 cash，capital_source 说明来自资金账本；
  2. 按计划减仓成交后再调默认接口 → 不再重复减仓（target_mv 不变、持有为 0 卖出）；
  3. 显式传 total_capital → 以外部值为准，并写 account_meta['anchor_total_capital']
     （同时保留旧 app_meta 键兼容）；
  4. 账户未初始化（只有成交、无入金）→ 保留旧锚点逻辑（持仓市值初始化、半仓不重复减仓）；
  5. 缺行情持仓 → no_data=True、valuation_complete=False、不抛异常，总权益只含有价部分。

全部使用 conftest 的临时数据库；行情用 monkeypatch 的合成 K 线（不写真实库）。
"""
import os
import sys

import pandas as pd
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ==================== 合成行情 / 扫描结果 / 环境替换 ====================

def _flat_df(days=5, price=1.0):
    dates = pd.date_range("2026-01-05", periods=days, freq="B")
    return pd.DataFrame({
        "date": dates,
        "open": price, "high": price, "low": price, "close": price,
        "volume": 100000,
    })


def _fake_scan(temp=50.0, weights=None):
    weights = weights or [{"code": "C1", "weight": 100.0}]
    return {
        "generated_at": "2026-11-10T00:00:00",
        "holdings": [],
        "portfolio": {"holdings": weights},
        "market": {"temp": temp, "avg_score": temp},
    }


def _patch_rebalance_env(monkeypatch, missing_codes=()):
    """替换再平衡/账户估值的数据源：同一份合成行情 + 固定扫描结果。

    - engine.rebalance.fetch：再平衡自身算现价/市值
    - engine.account.fetch：账户估值（总权益里的持仓市值）必须同源，否则跨模块数字不一致
    - engine.signals.scan_all_signals：rebalance 内部是调用时 from-import，patch 模块属性即生效
    """
    import engine.account as acct_mod
    import engine.rebalance as rb
    import engine.signals as sig_mod

    state = {"scan": _fake_scan()}
    fake_df = _flat_df(5, 1.0)

    def fake_fetch(code, offline=True):
        if code in missing_codes:
            return pd.DataFrame()
        return fake_df

    monkeypatch.setattr(rb, "fetch", fake_fetch)
    monkeypatch.setattr(acct_mod, "fetch", fake_fetch)
    monkeypatch.setattr(sig_mod, "scan_all_signals", lambda use_cache=True: state["scan"])
    monkeypatch.setattr(rb, "scan_all_signals", lambda use_cache=True: state["scan"], raising=False)
    return rb, state


# ==================== 1. 账本初始化后默认口径 = 现金 + 持仓市值 ====================

def test_ledger_default_equity_is_cash_plus_market_value(monkeypatch):
    """deposit 2000 → 买 1000 股@1（费 0.3）→ 默认接口总权益 = 现金 + 市值 ≈ 1999.7。"""
    from engine import account, db

    rb, _ = _patch_rebalance_env(monkeypatch)
    account.deposit(2000)
    db.apply_trade("BUY", "C1", price=1.0, shares=1000.0, fee=0.3, name="C1")

    eq = account.get_account_equity(with_twr=False)
    assert eq["ledger_initialized"] is True, eq
    assert eq["cash"] == pytest.approx(999.7, abs=0.01), eq
    assert eq["market_value"] == pytest.approx(1000.0, abs=0.01), eq
    assert eq["total_equity"] == pytest.approx(1999.7, abs=0.01), eq

    r = rb.rebalance_plan()                       # 默认路径（API 无参调用）
    assert "error" not in r, r
    assert r["ledger_initialized"] is True, r
    # cash 字段正确（与资金账本一致）
    assert r["cash"] == pytest.approx(999.7, abs=0.01), r
    # 总权益 = 现金 + 持仓市值（不再拿持仓市值 1000 当总资金）
    assert r["total_equity"] == pytest.approx(
        r["cash"] + r["total_market_value"], abs=0.01), r
    assert r["total_equity"] == pytest.approx(1999.7, abs=0.01), r
    assert "资金账本" in r["capital_source"], r["capital_source"]
    assert r["anchor_initialized"] is False, r
    assert r["valuation_complete"] is True, r
    assert r["plans"][0]["action"] == "持有", r["plans"][0]   # 1000 ≈ 2000×100%×0.5


# ==================== 2. 按计划成交后不重复减仓 ====================

def test_executed_reduction_does_not_repeat(monkeypatch):
    """deposit 1000 + 买 1000 股 → 计划卖 500；成交后再调默认接口 → 持有、不再减仓。"""
    from engine import account, db

    rb, _ = _patch_rebalance_env(monkeypatch)
    account.deposit(1000)
    db.apply_trade("BUY", "C1", price=1.0, shares=1000.0, name="C1")

    r1 = rb.rebalance_plan()
    assert "error" not in r1, r1
    p1 = r1["plans"][0]
    assert p1["action"] == "卖出" and p1["sell_shares"] == 500, p1
    assert r1["total_equity"] == pytest.approx(1000.0, abs=0.01), r1
    target_mv_before = p1["target_mv"]

    # 按计划成交：卖出 500 份 @1.0 → 现金 500 + 市值 500 = 总权益仍 1000
    db.apply_trade("SELL", "C1", price=1.0, shares=500.0, name="C1")

    r2 = rb.rebalance_plan()                      # 再次默认调用
    assert "error" not in r2, r2
    p2 = r2["plans"][0]
    assert p2["action"] == "持有", f"半仓执行后默认接口仍在减仓: {p2}"
    assert p2["sell_shares"] == 0, p2
    # 目标市值不变（仍是总权益 × 权重 × 温度，不随持仓缩水）
    assert p2["target_mv"] == pytest.approx(target_mv_before, abs=1.0), (p1, p2)
    assert r2["total_equity"] == pytest.approx(1000.0, abs=0.01), r2
    assert r2["cash"] == pytest.approx(500.0, abs=0.01), r2


# ==================== 3. 显式 total_capital 覆盖 + 写锚点 ====================

def test_explicit_total_capital_overrides_and_writes_fund_anchor(monkeypatch):
    """账本已初始化时显式传 total_capital：以外部值为准，写 account_meta 锚点（兼容旧键）。"""
    from engine import account, db

    rb, _ = _patch_rebalance_env(monkeypatch)
    account.deposit(2000)
    db.apply_trade("BUY", "C1", price=1.0, shares=1000.0, name="C1")

    r = rb.rebalance_plan(total_capital=3000)
    assert "error" not in r, r
    assert r["total_equity"] == pytest.approx(3000.0, abs=0.01), r
    assert "外部传入" in r["capital_source"], r["capital_source"]
    # 新锚点写 account_meta；旧 app_meta 键同步写（历史页面/接口兼容）
    assert db.get_account_meta("anchor_total_capital") == "3000.00"
    assert db.get_app_meta("account_total_capital") == "3000.00"

    # 默认路径仍以资金账本为准（不被显式锚点污染）：现金 1000 + 市值 1000 = 2000
    r2 = rb.rebalance_plan()
    assert r2["total_equity"] == pytest.approx(2000.0, abs=0.01), r2
    assert "资金账本" in r2["capital_source"], r2["capital_source"]


# ==================== 4. 账户未初始化：保留旧锚点逻辑 ====================

def test_uninitialized_account_keeps_legacy_anchor_path(monkeypatch):
    """只有成交、无入金 → ledger_initialized=False → 旧口径（持仓市值初始化锚点，不重复减仓）。"""
    from engine import account, db

    rb, _ = _patch_rebalance_env(monkeypatch)
    db.apply_trade("BUY", "C1", price=1.0, shares=1000.0, name="C1")   # 只买，不入金

    eq = account.get_account_equity(with_twr=False)
    assert eq["ledger_initialized"] is False, eq      # 纯成交行不算初始化

    r = rb.rebalance_plan()
    assert "error" not in r, r
    assert r["ledger_initialized"] is False, r
    assert r["total_equity"] == pytest.approx(1000.0, abs=0.01), r   # 旧口径：持仓市值预算基准
    assert r["anchor_initialized"] is True, r
    assert "初始化" in r["capital_source"], r["capital_source"]
    assert r["plans"][0]["action"] == "卖出" and r["plans"][0]["sell_shares"] == 500, r["plans"][0]
    # 锚点写库（account_meta 新键 + 旧 app_meta 键）
    assert db.get_account_meta("anchor_total_capital") is not None
    assert db.get_app_meta("account_total_capital") is not None

    # 模拟成交后再调默认接口 → 持有，不重复减仓
    db.apply_trade("SELL", "C1", price=1.0, shares=500.0, name="C1")
    r2 = rb.rebalance_plan()
    assert r2["plans"][0]["action"] == "持有", f"半仓执行后仍在减仓: {r2['plans'][0]}"
    assert r2["total_equity"] == pytest.approx(1000.0, abs=0.01), r2


# ==================== 5. 缺行情：no_data + 不抛异常 ====================

def test_missing_quote_no_data_and_total_equity_uses_priced_part(monkeypatch):
    """C2 缺行情：no_data=True、valuation_complete=False、不报错；总权益只含有价部分。"""
    from engine import account, db

    rb, state = _patch_rebalance_env(monkeypatch, missing_codes=("C2",))
    state["scan"] = _fake_scan(weights=[
        {"code": "C1", "weight": 60.0}, {"code": "C2", "weight": 40.0}])
    account.deposit(1000)
    db.apply_trade("BUY", "C1", price=1.0, shares=500.0, name="C1")
    db.apply_trade("BUY", "C2", price=1.0, shares=300.0, name="C2")

    r = rb.rebalance_plan()                        # 缺行情不得抛异常
    assert "error" not in r, r
    assert r["ledger_initialized"] is True, r
    assert r["valuation_complete"] is False, r
    assert [m["code"] for m in r["missing_quotes"]] == ["C2"], r

    c2 = next(p for p in r["plans"] if p["code"] == "C2")
    assert c2["no_data"] is True, c2
    assert c2["price"] is None and c2["cur_mv"] is None and c2["cur_pct"] is None, c2
    assert c2["action"] == "行情缺失", c2
    c1 = next(p for p in r["plans"] if p["code"] == "C1")
    assert c1["no_data"] is False and c1["cur_mv"] == pytest.approx(500.0), c1

    # cash=1000-500-300=200；有价市值=500；总权益=700（缺报价部分不计入）
    assert r["cash"] == pytest.approx(200.0, abs=0.01), r
    assert r["total_market_value"] == pytest.approx(500.0, abs=0.01), r
    assert r["total_equity"] == pytest.approx(700.0, abs=0.01), r
    # 目标市值仍按账本总权益照算：700 × 40% × 半仓 0.5 = 140
    assert c2["target_mv"] == pytest.approx(140.0, abs=1.0), c2
