# -*- coding: utf-8 -*-
"""关键修复行为的回归测试（自动使用 conftest 的临时库隔离，不碰真实 quant.db）"""
import numpy as np
import pandas as pd
import pytest

sys_path = __import__("sys")
sys_path.path.insert(0, "D:/Projects/quant-web/backend")

from engine.signals import stop_loss_check
from engine.backtest import Strategy, Backtest


def make_df(n=120, close=None, seed=3):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2024-01-01", periods=n)
    close = np.full(n, 1.0) if close is None else np.asarray(close, dtype=float)
    close = close * (1 + rng.normal(0, 0.0008, n))
    open_ = np.concatenate([[close[0]], close[:-1]])
    return pd.DataFrame({
        "date": dates, "open": open_, "close": close,
        "high": np.maximum(open_, close) * 1.002,
        "low": np.minimum(open_, close) * 0.998,
        "volume": np.full(n, 1e5),
    }), dates


class Fixed(Strategy):
    def __init__(self, sigs):
        super().__init__("固定信号")
        self.sigs = sigs

    def generate_signals(self, df):
        d = df.copy()
        d["signal"] = np.asarray(self.sigs[: len(df)], dtype=int)
        return d


def test_stop_loss_check_price0_no_sell():
    """行情断档(价格<=0)：绝不触发止损/止盈，标记 no_data"""
    pos = {"shares": 100, "cost_price": 1.0, "cost": 100.0}
    sl = stop_loss_check("900001", pos, 0.0)
    assert sl["stop_triggered"] is False
    assert sl["take_profit"] is False
    assert sl.get("no_data") is True


def test_stop_loss_check_normal():
    """正常价格路径仍按旧口径工作"""
    pos = {"shares": 100, "cost_price": 1.0, "cost": 100.0}
    assert stop_loss_check("900001", pos, 0.85)["stop_triggered"] is True
    assert stop_loss_check("900001", pos, 1.16)["take_profit"] is True


def test_trailing_locked_after_arm_live():
    """移动止盈锁定：峰值曾超+8%后，回撤达标即触发，即使当前盈利只剩+2%"""
    pos = {"shares": 100, "cost_price": 1.0, "cost": 100.0}
    sl1 = stop_loss_check("900002", pos, 1.15)   # 峰值 1.15 → 已激活
    assert sl1["take_profit"] is False            # 当日无回撤
    sl2 = stop_loss_check("900002", pos, 1.02)   # 回撤 -11.3% < -8%
    assert sl2["trailing_take"] is True
    assert sl2["take_profit"] is True


def test_backtest_trailing_sells_next_open():
    """回测移动止盈：触发后次日开盘成交（含滑点），不再坐回原点"""
    n = 90
    close = np.full(n, 1.00)
    close[66:77] = np.linspace(1.00, 1.15, 11)   # 拉升到峰值 1.15(+15%)
    close[77:79] = 1.15
    close[79] = 1.09
    close[80:] = 1.02                             # 回撤 -11.3%，当前盈利仅+2%
    df, dates = make_df(n, close=close, seed=5)
    sigs = np.zeros(n, dtype=int)
    sigs[49] = 1                                  # 第50根开盘买入
    # 传统止损线放宽(-20%)：让移动止盈(-8% 峰值回撤)成为唯一触发者，
    # 单独验证“激活后利润不再坐回去”的行为
    perf = Backtest(df, Fixed(sigs), enable_risk=True, stop_drawdown=-20.0).run()
    sells = [t for t in perf["trade_list"] if t["action"] == "SELL"]
    assert len(sells) == 1, perf["trade_list"]
    assert sells[0]["date"] == str(dates[81])
    assert "移动止盈" in sells[0].get("reason", "")
    expect = round(float(df["open"].iloc[81]) * 0.999, 4)
    assert sells[0]["price"] == pytest.approx(expect, abs=1e-4)


def test_backtest_fflow_unit_aligned():
    """回测资金流单位对齐：原始元 ÷1e4 → 万元后参与评分（±10 顶格对应3000万）"""
    from engine.backtest import ScoreStrategy
    from engine import fflow as fflow_mod

    df, _ = make_df(120, seed=11)
    ff = pd.DataFrame({
        "date": df["date"].values,
        "main_net": np.full(len(df), 300_000.0),   # 每日常 30万 元
        "main_pct": np.full(len(df), 1.0),
        "small_net": 0.0, "mid_net": 0.0, "big_net": 0.0, "super_net": 0.0,
    })
    orig_fetch, orig_add = fflow_mod.fetch_fflow, fflow_mod.add_fflow_factors
    fflow_mod.fetch_fflow = lambda code, **kw: ff
    fflow_mod.add_fflow_factors = lambda d: d.assign(
        main_net_5d=d["main_net"].rolling(5).sum(), main_pct_5d=0.0)
    try:
        s_on = ScoreStrategy(buy_th=30, sell_th=15, use_fflow=True)
        s_on.code = "900003"
        d_on = s_on.generate_signals(df)
        s_off = ScoreStrategy(buy_th=30, sell_th=15, use_fflow=False)
        s_off.code = "900003"
        d_off = s_off.generate_signals(df)
        diff = (d_on["score"] - d_off["score"]).dropna().tail(20).mean()
        # 5日累计 150万元 → 万元150 → +150/300=+0.5 分（旧代码 1.5e6/300 恒触顶+10）
        assert 0.3 < diff < 0.7, f"diff={diff}"
    finally:
        fflow_mod.fetch_fflow, fflow_mod.add_fflow_factors = orig_fetch, orig_add
