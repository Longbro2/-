/**
 * 迭代 A（现金账本）页面验收：实际执行 frontend/index.html 的内联 JS（Node 最小 DOM/API 桩）。
 *
 * 覆盖场景：
 *   A 未初始化（ledger_initialized=false）→ 页面显示“未初始化（请入金或导入对账）”
 *   B 入金后（两次入金 → cash=1000 / total_equity=1000 / TWR=0 / 账本 2 行）
 *     → 账户卡片显示 1000、0.00%、已实现盈亏，账本表格显示入金行与运行余额 cash_after
 *   C 缺报价（valuation_complete=false）→ “估值不完整”+“—”，不出现 -100 的假亏损
 *   D 出金失败（POST 返回 HTTP 400 + detail“现金不足”）→ alert 文案含“现金不足”
 *   E 现金为负 → 红色“现金为负”提示
 *   F 账户/账本接口整体失败 → 只降级本卡片，不出现整页“加载失败”（__renderDone 仍置 true）
 *
 * 运行: node backend/tests/frontend/iterationA_account_check.js
 */
'use strict';
const fs = require('fs');
const path = require('path');

// ---------- 读取并提取首页内联 JS ----------
const html = fs.readFileSync(path.join(__dirname, '../../../frontend/index.html'), 'utf8');
const inline = [...html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g)].map(m => m[1]);
if (!inline.length) { console.error('FAIL: 未找到首页内联 JS'); process.exit(1); }
const code = inline[inline.length - 1];

// ---------- 最小 DOM 桩 ----------
const elements = {};
function mkEl(id) {
  return {
    id, innerHTML: '', textContent: '', style: {},
    querySelector() { return null; },
  };
}
global.document = {
  querySelector(sel) {
    const id = String(sel).replace(/^#/, '');
    return elements[id] || (elements[id] = mkEl(id));
  },
  querySelectorAll() { return []; },
  addEventListener() {},
  createElement() { return { textContent: '', innerHTML: '' }; },
  body: { appendChild() {}, removeChild() {} },
};

// ---------- 全局工具 / 浏览器环境桩 ----------
global.esc = s => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
global.fmtPct = (v, digits = 2) =>
  (v == null || isNaN(v)) ? '—' : ((v > 0 ? '+' : '') + Number(v).toFixed(digits) + '%');
global.sigBadge = sig => `<span class="badge">${sig || '—'}</span>`;
global.window = globalThis;   // 页面 JS 用 window.__renderDone/__renderError 标记渲染完成

let alerts = [];
global.alert = msg => { alerts.push(String(msg)); };
let promptQueue = [];
global.prompt = () => (promptQueue.length ? promptQueue.shift() : null);

// ---------- 假服务端状态（账户资金口径 = base_cash + Σ cash_ledger.amount） ----------
const round2 = v => Math.round(Number(v) * 100) / 100;
const state = {
  initialized: false, cash: 0, base_cash: 0, realized_pnl: 0,
  entries: [], nextId: 1,
  positions: [], valuation_complete: true, missing_quotes: [],
  fail_account: false, fail_ledger: false,
};

function addEntry(type, amount, note) {
  const e = {
    id: state.nextId++, date: '2026-11-10', type,
    amount: round2(amount), note: note || '', trade_id: null,
    cash_after: round2(state.cash),
  };
  state.entries.push(e);
  return e;
}

function marketValue() {
  return round2(state.positions.filter(p => !p.no_data)
    .reduce((s, p) => s + (p.market_value || 0), 0));
}

function equityResponse() {
  const mv = marketValue();
  return {
    base_cash: round2(state.base_cash),
    cash: round2(state.cash),
    market_value: mv,
    total_equity: round2(state.cash + mv),
    realized_pnl: round2(state.realized_pnl),
    unrealized_pnl: 0,
    total_fees: 0,
    twr: state.initialized ? 0 : null,          // 只有入金/出金：TWR 必须 == 0
    twr_reliable: state.initialized,            // 历史/未初始化账户 TWR 不可用
    twr_start: state.initialized ? '2026-11-10' : null,
    twr_end: state.initialized ? '2026-11-10' : null,
    twr_days: state.initialized ? 1 : 0,
    twr_valuation_complete: state.valuation_complete,
    valuation_complete: state.valuation_complete,
    missing_quotes: state.missing_quotes.map(x => ({ ...x })),
    cash_source: 'account_ledger',
    ledger_initialized: state.initialized,
    asof: '2026-11-10',
    note: state.initialized ? '' : '账户未初始化（无期初基线且账本为空）',
  };
}

function ledgerResponse() {
  return {
    base_cash: round2(state.base_cash),
    cash: round2(state.cash),
    entries: state.entries.slice().reverse().slice(0, 20).map(e => ({ ...e })),
    note: state.initialized ? '' : '账户尚未初始化',
  };
}

function positionsResponse() {
  return {
    positions: state.positions.map(p => ({ ...p })),
    total_market_value: marketValue(),
    total_cost: round2(state.positions.reduce((s, p) => s + (p.cost || 0), 0)),
    total_cost_priced: round2(state.positions.filter(p => !p.no_data)
      .reduce((s, p) => s + (p.cost || 0), 0)),
    total_pnl: 0,
    total_pnl_pct: null,
    valuation_complete: state.valuation_complete,
    missing_quotes: state.missing_quotes.map(x => ({ ...x })),
    note: state.valuation_complete ? '全部持仓有有效报价'
      : `${state.missing_quotes.length} 只缺少行情，总额仅统计有报价部分`,
  };
}

const scan = {
  generated_at: '2026-11-10T09:00:00', data_asof: '2026-11-09',
  market: { temp: 50, avg_score: 50, status: '中性 ⚖️' },
  discipline: { allowed: true, msg: '可买入' },
  holdings: [], advice: { buy: [], sell: [] }, signals: [],
};
const rec = {
  recommended: [], summary: '', backtest_summary: {},
  temp_timing: { market_temp: 50, position_ratio: 0.5, action: '半仓', note: '中性市场' },
  disclaimer: '', action_authority: '', verify_source: '',
};
global.API = {
  async get(url) {
    if (url === '/api/signals/scan') return JSON.parse(JSON.stringify(scan));
    if (url === '/api/signals/recommended') return JSON.parse(JSON.stringify(rec));
    if (url === '/api/portfolio/positions') return positionsResponse();
    if (url === '/api/portfolio/rebalance') return { error: '无持仓' };
    if (url === '/api/account/equity') {
      if (state.fail_account) throw new Error('HTTP 500');
      return equityResponse();
    }
    if (String(url).indexOf('/api/account/ledger') === 0) {
      if (state.fail_ledger) throw new Error('HTTP 500');
      return ledgerResponse();
    }
    throw new Error('no fixture ' + url);
  },
  async post() { return {}; },
};

// 页面入金/出金用原生 fetch（以便从 400 响应体取 detail），这里桩出真实 HTTP 语义
global.fetch = async (url, opts) => {
  const body = opts && opts.body ? JSON.parse(opts.body) : {};
  const resp = (status, data) => ({
    ok: status >= 200 && status < 300,
    status,
    async json() { return JSON.parse(JSON.stringify(data)); },
  });
  if (url === '/api/account/deposit') {
    const amount = Number(body.amount);
    if (!isFinite(amount) || amount <= 0) return resp(400, { detail: 'amount 必须是有限正数' });
    state.initialized = true;
    state.cash = round2(state.cash + amount);
    const entry = addEntry('DEPOSIT', amount, '');
    return resp(200, { ok: true, entry, equity: equityResponse() });
  }
  if (url === '/api/account/withdraw') {
    const amount = Number(body.amount);
    if (!isFinite(amount) || amount <= 0) return resp(400, { detail: 'amount 必须是有限正数' });
    if (amount > state.cash + 1e-9) {
      return resp(400, {
        detail: `现金不足：当前现金 ¥${round2(state.cash).toFixed(2)}，无法出金 ¥${amount.toFixed(2)}`,
      });
    }
    state.initialized = true;
    state.cash = round2(state.cash - amount);
    const entry = addEntry('WITHDRAW', -amount, '');
    return resp(200, { ok: true, entry, equity: equityResponse() });
  }
  return resp(404, { detail: 'not found: ' + url });
};

// ---------- 执行首页 JS（真实 load()/renderAccount()/renderLedger()/depositCash()/withdrawCash()） ----------
eval(code + '\n;globalThis.__pageLoad = load;'
  + 'globalThis.__deposit = depositCash; globalThis.__withdraw = withdrawCash;');

// ---------- 断言工具 ----------
let checks = 0;
const assert = (cond, msg) => {
  if (!cond) { console.error('FAIL: ' + msg); process.exit(1); }
  checks++;
};
const vis = name => (elements[name] ? elements[name].innerHTML : '');
const allText = () => ['topCards', 'accountCards', 'accountNote', 'ledgerBody', 'ledgerNote',
  'holdBody', 'rebArea', 'actionBanner'].map(vis).join('\n');
const rowCount = el => (vis(el).match(/<tr\b/g) || []).length;
const noFakeLoss = (name, text) => {
  assert(!text.includes('-100'), `${name} 仍出现 -100: ${text.slice(0, 400)}`);
  assert(!/\(-100/.test(text), `${name} 仍出现 (-100%: ${text.slice(0, 400)}`);
  assert(!text.includes('NaN'), `${name} 出现 NaN`);
};

(async () => {
  // ================= 场景 A：账户未初始化 =================
  console.log('[A] 未初始化 → 显示“未初始化（请入金或导入对账）”');
  await globalThis.__pageLoad();
  assert(globalThis.__renderDone === true, 'A: window.__renderDone 应为 true');
  assert(vis('accountCards').includes('未初始化'),
    'A: 账户卡片未显示“未初始化”: ' + vis('accountCards'));
  assert(vis('accountNote').includes('未初始化（请入金或导入对账）'),
    'A: 未初始化提示文案不正确: ' + vis('accountNote'));
  assert(vis('ledgerBody').includes('暂无账本记录'),
    'A: 空账本未显示“暂无账本记录”: ' + vis('ledgerBody'));
  assert(!vis('topCards').includes('加载失败'), 'A: 页面出现“加载失败”');

  // ================= 场景 B：入金后显示现金/权益/TWR/账本行 =================
  console.log('[B] 两次入金 500 → cash=1000 / total_equity=1000 / TWR=0 / 账本 2 行');
  promptQueue = ['500', '500']; alerts = [];
  await globalThis.__deposit();
  await globalThis.__deposit();
  assert(state.cash === 1000, 'B: 桩账户现金应为 1000，实际 ' + state.cash);
  assert(state.entries.length === 2, 'B: 桩账本应有 2 行，实际 ' + state.entries.length);
  assert(alerts.length === 0, 'B: 入金成功不应 alert: ' + alerts.join(' | '));
  const acctB = vis('accountCards');
  assert(acctB.includes('1000'), 'B: 现金/总权益未显示 1000: ' + acctB);
  assert(acctB.includes('0.00%'), 'B: TWR 未显示 0.00%: ' + acctB);
  assert(acctB.includes('累计收益') && acctB.includes('已实现盈亏'),
    'B: 账户卡片字段（累计收益/已实现盈亏）缺失: ' + acctB);
  assert(!acctB.includes('未初始化'), 'B: 入金后仍显示未初始化: ' + acctB);
  assert(globalThis.__renderDone === true, 'B: window.__renderDone 应为 true');
  const lgB = vis('ledgerBody');
  assert(rowCount('ledgerBody') === 2, 'B: 账本应有 2 行，实际 ' + rowCount('ledgerBody') + ': ' + lgB);
  assert(lgB.includes('入金'), 'B: 账本未显示“入金”: ' + lgB);
  assert(lgB.includes('+500.00'), 'B: 账本未显示金额 +500.00: ' + lgB);
  assert(lgB.includes('500.00') && lgB.includes('1000.00'),
    'B: 账本运行余额 cash_after 未显示 500/1000: ' + lgB);
  assert(vis('ledgerNote').includes('期初现金基线'), 'B: 账本备注缺期初基线口径: ' + vis('ledgerNote'));

  // ================= 场景 C：缺报价 → 估值不完整 / —，无 -100 =================
  console.log('[C] 缺报价（valuation_complete=false）→ “估值不完整”+“—”，无 -100');
  state.positions = [{
    code: '999999', name: '未知代码', shares: 100, cost_price: 1, cost: 100,
    current_price: null, market_value: null, pnl_pct: null, no_data: true,
  }];
  state.valuation_complete = false;
  state.missing_quotes = [{ code: '999999', name: '未知代码' }];
  await globalThis.__pageLoad();
  assert(vis('accountCards').includes('估值不完整'),
    'C: 总权益未标“估值不完整”: ' + vis('accountCards'));
  assert(vis('accountNote').includes('估值不完整') && vis('accountNote').includes('缺行情'),
    'C: 账户备注未提示缺行情: ' + vis('accountNote'));
  assert((vis('accountCards') + vis('holdBody')).includes('—'),
    'C: 缺报价未显示“—”: ' + vis('accountCards') + ' | ' + vis('holdBody'));
  noFakeLoss('C:topCards', vis('topCards'));
  noFakeLoss('C:accountCards', vis('accountCards'));
  noFakeLoss('C:holdBody', vis('holdBody'));
  assert(!allText().includes('加载失败'), 'C: 页面出现“加载失败”');
  assert(globalThis.__renderDone === true, 'C: window.__renderDone 应为 true');

  // ================= 场景 D：出金失败 → alert(detail) 含“现金不足” =================
  console.log('[D] 出金 5000（现金 1000）→ HTTP 400 detail“现金不足”→ alert 文案含“现金不足”');
  alerts = []; promptQueue = ['5000'];
  const cashBefore = state.cash;
  await globalThis.__withdraw();
  assert(alerts.length === 1, 'D: 出金失败应 alert 一次，实际 ' + alerts.length);
  assert(alerts[0].includes('现金不足'), 'D: alert 未含“现金不足”: ' + alerts.join(' | '));
  assert(alerts[0].includes('出金失败'), 'D: alert 未含“出金失败”: ' + alerts[0]);
  assert(state.cash === cashBefore, 'D: 出金失败后现金被改动: ' + state.cash);
  assert(!vis('accountCards').includes('-100'), 'D: 失败后账户卡片出现异常值');

  // ================= 场景 E：现金为负 → 红色提示 =================
  console.log('[E] 现金为负（cash=-50）→ 红色“现金为负”提示');
  state.cash = -50;
  await globalThis.__pageLoad();
  assert(vis('accountCards').includes('现金为负'),
    'E: 现金为负未提示: ' + vis('accountCards'));
  assert(vis('accountCards').includes('-¥50.00'),
    'E: 负现金未按负值显示: ' + vis('accountCards'));
  assert(/class="big down"/.test(vis('accountCards')),
    'E: 负现金未使用红色 down 样式: ' + vis('accountCards'));
  assert(vis('accountNote').includes('现金为负'), 'E: 账户备注未提示现金为负: ' + vis('accountNote'));

  // ================= 场景 F：账户/账本接口失败容错（不整页加载失败） =================
  console.log('[F] /api/account/equity + /api/account/ledger 失败 → 仅本卡片降级，不整页“加载失败”');
  state.fail_account = true;
  state.fail_ledger = true;
  await globalThis.__pageLoad();
  state.fail_account = false;
  state.fail_ledger = false;
  assert(vis('accountCards').includes('暂不可用'),
    'F: 账户接口失败未降级提示: ' + vis('accountCards'));
  assert(vis('ledgerBody').includes('暂不可用'),
    'F: 账本接口失败未降级提示: ' + vis('ledgerBody'));
  assert(!vis('topCards').includes('加载失败'),
    'F: 账户接口失败导致整页“加载失败”: ' + vis('topCards'));
  assert(!allText().includes('加载失败'), 'F: 页面出现“加载失败”');
  assert(globalThis.__renderDone === true, 'F: window.__renderDone 应为 true');

  console.log(`OK: 迭代 A 首页账户资金/资金账本/入金出金检查通过（实际执行 index.html 内联 JS，${checks} 项断言）`);
  process.exit(0);
})().catch(e => {
  console.error('FAIL: ' + (e && e.stack || e));
  process.exit(1);
});
