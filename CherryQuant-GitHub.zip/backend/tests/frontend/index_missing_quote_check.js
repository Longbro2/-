/**
 * F #21 回归：实际执行首页 frontend/index.html 的内联 JS（Node 最小 DOM/API 桩），
 * 复现场景 = 持仓成本 100 元、行情缺失。
 *
 * 旧实现：market_value 当 0 参与总额 → 顶部“浮动盈亏 -100”、(-100%)，持仓表市值 0。
 * 新实现：缺报价行显示“—/行情缺失”，总额标“不完整”，不再出现 -100% 的假亏损；
 *        再平衡卡片正确处理 error / total_equity / no_data。
 *
 * 运行: node backend/tests/frontend/index_missing_quote_check.js
 */
'use strict';
const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(path.join(__dirname, '../../../frontend/index.html'), 'utf8');
const inline = [...html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g)].map(m => m[1]);
if (!inline.length) { console.error('FAIL: 未找到首页内联 JS'); process.exit(1); }
const code = inline[inline.length - 1];

// ---------- 最小 DOM / 全局桩 ----------
const elements = {};
function mkEl(id) {
  return {
    id, innerHTML: '', textContent: '', style: {},
    querySelector() { return null; },
  };
}
global.document = {
  querySelector(sel) {
    const id = String(sel).replace(/^#/, '');
    return elements[id] || (elements[id] = mkEl(id));
  },
  querySelectorAll() { return []; },
  addEventListener() {},
  createElement() { return { textContent: '', innerHTML: '' }; },
  body: { appendChild() {}, removeChild() {} },
};
global.esc = s => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
global.fmtPct = (v, digits = 2) =>
  (v == null || isNaN(v)) ? '—' : ((v > 0 ? '+' : '') + Number(v).toFixed(digits) + '%');
global.sigBadge = sig => `<span class="badge">${sig || '—'}</span>`;
global.alert = () => {};
global.window = globalThis;   // 页面 JS 用 window.__renderDone/__renderError 标记渲染完成
// Node >=21 自带只读 global.navigator（无 clipboard），copyOrders 不在本测试触发，无需桩

let fixtures = {};
global.API = {
  async get(url) {
    if (!(url in fixtures)) throw new Error('no fixture ' + url);
    return JSON.parse(JSON.stringify(fixtures[url]));
  },
  async post() { return {}; },
};

// ---------- 执行首页 JS ----------
eval(code + '\n;globalThis.__pageLoad = load;');

const assert = (cond, msg) => {
  if (!cond) { console.error('FAIL: ' + msg); process.exit(1); }
};
const noFakeLoss = (name, html) => {
  assert(!html.includes('-100'), `${name} 仍出现 -100: ${html.slice(0, 300)}`);
  assert(!/\(-100/.test(html), `${name} 仍出现 (-100%: ${html.slice(0, 300)}`);
  assert(!html.includes('NaN'), `${name} 出现 NaN`);
};

// ================= 场景 A：单只持仓行情缺失、成本 100 元 =================
const scanA = {
  generated_at: '2026-11-09T17:43:33', data_asof: '2026-11-09',
  market: { temp: 50, avg_score: 50, status: '中性 ⚖️' },
  discipline: { allowed: true, msg: '可买入' },
  holdings: [{
    code: '159828', name: '医疗ETF', shares: 100, cost_price: 1.0, cost: 100,
    current_price: null, market_value: null, no_data: true, pnl_pct: null,
    drawdown: null, status: '数据缺失', signal: 'BUY',
  }],
  advice: { buy: [], sell: [], add: [], hold: [], watch: [], summary: '', market_temp: 50, buy_allowed: true },
  signals: [],
};
const posA = {
  positions: [{
    code: '159828', name: '医疗ETF', shares: 100, cost_price: 1.0,
    current_price: null, market_value: null, cost: 100, pnl_pct: null, drawdown: null,
    stop_triggered: false, take_profit: false, no_data: true,
  }],
  total_market_value: 0, total_cost: 100, total_cost_priced: 0, total_pnl: 0,
  total_pnl_pct: null, valuation_complete: false,
  missing_quotes: [{ code: '159828', name: '医疗ETF' }], note: '1 只缺少行情',
};
const recA = {
  recommended: [], rec_not_hold: [], rotate: [], summary: '', backtest_summary: {},
  temp_timing: { market_temp: 50, position_ratio: 0.5, action: '半仓', note: '中性市场' },
  disclaimer: '', action_authority: '最终买卖建议以 /api/signals/advice 为准',
  verify_source: 'optimize_report_new.json（点内验证，统一口径）',
};
const rbA = { error: '无持仓' };

fixtures = {
  '/api/signals/scan': scanA,
  '/api/signals/recommended': recA,
  '/api/portfolio/positions': posA,
  '/api/portfolio/rebalance': rbA,
};

(async () => {
  await globalThis.__pageLoad();

  const top = elements['topCards'].innerHTML;
  const hold = elements['holdBody'].innerHTML;
  const note = elements['holdNote'].innerHTML;
  const banner = elements['actionBanner'].innerHTML;
  const reb = elements['rebArea'].innerHTML;
  const rec = elements['recArea'].innerHTML;

  assert(top.includes('不完整'), '顶部总市值未标“不完整”: ' + top);
  assert(top.includes('缺行情'), '顶部未提示缺行情: ' + top);
  noFakeLoss('topCards', top);
  noFakeLoss('holdBody', hold);
  assert(hold.includes('行情缺失'), '持仓表未显示“行情缺失”: ' + hold);
  assert(hold.includes('—'), '持仓表缺报价未显示“—”: ' + hold);
  assert(hold.includes('医疗ETF'), '持仓表丢了持仓行: ' + hold);
  assert(note.includes('缺行情') && note.includes('医疗ETF'), '持仓表下方缺提示: ' + note);
  assert(banner.includes('缺行情'), '行动横幅未提示缺行情: ' + banner);
  assert(reb.includes('无持仓'), '再平衡 error 未展示: ' + reb);
  assert(rec.includes('optimize_report_new.json'), '推荐卡片未展示统一验证口径来源: ' + rec);
  assert(rec.includes('/api/signals/advice'), '推荐卡片未展示最终建议权威来源: ' + rec);

  // ================= 场景 B：再平衡计划含缺行情持仓 + 账户总资金锚点 =================
  const scanB = JSON.parse(JSON.stringify(scanA));
  scanB.holdings.push({
    code: 'C2', name: '缺行情ETF', shares: 300, cost_price: 1.0, cost: 300,
    current_price: null, market_value: null, no_data: true, pnl_pct: null,
    drawdown: null, status: '数据缺失', signal: 'HOLD',
  });
  const posB = JSON.parse(JSON.stringify(posA));
  posB.positions.push({
    code: 'C2', name: '缺行情ETF', shares: 300, cost_price: 1.0,
    current_price: null, market_value: null, cost: 300, pnl_pct: null,
    drawdown: null, stop_triggered: false, take_profit: false, no_data: true,
  });
  posB.total_cost = 400;
  posB.missing_quotes = [{ code: '159828', name: '医疗ETF' }, { code: 'C2', name: '缺行情ETF' }];
  const rbB = {
    total_market_value: 500, total_equity: 1000,
    capital_source: '账户总资金锚点 app_meta.account_total_capital（现金+持仓）',
    anchor_initialized: false, valuation_complete: false,
    missing_quotes: [{ code: 'C2', name: '缺行情ETF' }],
    total_buy: 100, total_sell: 0, market_temp: 50, regime: '半仓(温度40-60)',
    plans: [
      { code: 'C1', name: '测试ETF', action: '买入', no_data: false, price: 1.0,
        cur_mv: 500, target_mv: 600, diff: 100, hint: '加仓 100份 (约100元)' },
      { code: 'C2', name: '缺行情ETF', action: '行情缺失', no_data: true, price: null,
        cur_mv: null, target_mv: 200, diff: null, hint: '缺行情，无法计算当前市值/差额' },
    ],
    note: '',
  };
  fixtures['/api/signals/scan'] = scanB;
  fixtures['/api/portfolio/positions'] = posB;
  fixtures['/api/portfolio/rebalance'] = rbB;
  await globalThis.__pageLoad();

  const topB = elements['topCards'].innerHTML;
  const holdB = elements['holdBody'].innerHTML;
  const rebB = elements['rebArea'].innerHTML;
  noFakeLoss('topCards(B)', topB);
  noFakeLoss('holdBody(B)', holdB);
  assert(topB.includes('不完整'), 'B 场景总市值未标不完整');
  assert(holdB.includes('行情缺失'), 'B 场景持仓表未显示行情缺失');
  assert(rebB.includes('账户总资金 ¥1000'), 'B 场景再平衡未展示 total_equity: ' + rebB);
  assert(rebB.includes('行情缺失'), 'B 场景再平衡未展示 no_data 计划: ' + rebB);
  assert(rebB.includes('目标市值 600'), 'B 场景再平衡未展示正常计划目标市值: ' + rebB);
  assert(rebB.includes('估值不完整'), 'B 场景再平衡未提示估值不完整: ' + rebB);

  console.log('OK: 首页缺报价/再平衡渲染检查通过（实际执行 index.html 内联 JS）');
  process.exit(0);
})().catch(e => {
  console.error('FAIL: ' + (e && e.stack || e));
  process.exit(1);
});
