/* CherryQuant Web — 公共 JS：API 封装 + 工具函数 */
const API = {
  async get(url) {
    const r = await fetch(url);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  },
  async post(url, body) {
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  },
  async del(url) {
    const r = await fetch(url, { method: 'DELETE' });
    return r.json();
  },
  async upload(url, file) {
    const fd = new FormData();
    fd.append('file', file);
    const r = await fetch(url, { method: 'POST', body: fd });
    return r.json();
  },
};

function fmtPct(v, digits = 2) {
  if (v === null || v === undefined || isNaN(v)) return '—';
  const cls = v > 0 ? 'up' : v < 0 ? 'down' : '';
  return `<span class="${cls}">${v > 0 ? '+' : ''}${v.toFixed(digits)}%</span>`;
}

function sigBadge(sig) {
  const map = { BUY: ['badge-buy', '买入'], SELL: ['badge-sell', '卖出'], HOLD: ['badge-hold', '持有'] };
  const [cls, txt] = map[sig] || ['badge-neutral', sig || '—'];
  return `<span class="badge ${cls}">${txt}</span>`;
}

function rankStars(rank) {
  if (rank === 1) return '⭐⭐⭐';
  if (rank <= 3) return '⭐⭐';
  if (rank <= 5) return '⭐';
  return '';
}

function esc(s) {
  const d = document.createElement('div');
  d.textContent = s == null ? '' : String(s);
  return d.innerHTML;
}

async function apiHealth() {
  try {
    const h = await API.get('/api/health');
    document.querySelectorAll('[data-health]').forEach(el => {
      el.textContent = `v${h.version} · ${h.migrated ? '已迁移旧数据' : '运行中'}`;
    });
  } catch (e) {
    document.querySelectorAll('[data-health]').forEach(el => {
      el.textContent = '后端未连接';
    });
  }
}

/* 页面加载后检查健康状态 */
document.addEventListener('DOMContentLoaded', apiHealth);
