# CherryQuant Web V5.2

> 本压缩包包含 CherryQuant 源码和启动文件。Windows 解压后可双击 `run.bat` 启动，
> 或在项目根目录执行 `python -m pip install -r requirements.txt`，再执行
> `python -m uvicorn main:app --app-dir backend --host 127.0.0.1 --port 8000`。
> 首次启动会创建空数据库，行情可在数据管理页刷新。本机账户、行情缓存、上传文件、
> 模型和历史报告会留在原项目。需要旧项目迁移时，可以显式设置 `CHERRYQUANT_LEGACY_DIR`。
> 部分研究脚本需要准备历史行情和配置数据路径。依赖本机行情的测试需准备相应缓存。
> ECharts 5.6.0 的第三方许可和声明位于 `frontend/assets`。


A股 ETF 量化信号 & 回测系统（本地 Web 版）

## 🚀 快速启动

```
双击 run.bat
```

自动完成：
1. 检查 Python 与依赖（缺什么自动装）
2. 清理非法缓存文件
3. 启动服务并自动打开浏览器 → http://localhost:8000

> 关闭启动窗口即停止服务。

## 📁 目录结构

```
D:\Projects\quant-web\
├── run.bat               # 一键启动
├── requirements.txt      # 依赖清单
├── backend\
│   ├── main.py           # FastAPI 入口
│   ├── engine\           # 核心引擎
│   │   ├── config.py     # 配置：ETF池/阈值/风控参数
│   │   ├── data.py       # 数据层：联网拉取/Choice解析/缓存
│   │   ├── db.py         # SQLite 存储 + 旧数据迁移
│   │   ├── signals.py    # 评分引擎/信号/止损止盈/纪律锁
│   │   └── backtest.py   # 回测引擎/阈值优化
│   └── api\              # REST 接口
├── frontend\             # 前端页面（原生 HTML + ECharts）
│   ├── index.html        # 仪表盘
│   ├── signals.html      # 每日信号
│   ├── backtest.html     # 回测中心
│   └── data.html         # 数据管理
└── data\
    ├── quant.db          # SQLite（持仓/成交/峰值/元数据）
    ├── cache\
    │   ├── eastmoney\    # 东财缓存
    │   ├── akshare\      # akshare 缓存
    │   └── choice\       # Choice Excel 导入缓存
    └── uploads\          # 上传的 Excel 备份
```

## 🧭 四个页面

| 页面 | 功能 |
|---|---|
| **仪表盘** | 总市值/浮动盈亏、市场温度、信号分布、持仓概览 |
| **每日信号** | 全池评分排名、单 ETF K 线（含均线/RSI）、持仓风控 |
| **回测中心** | 策略对比净值曲线、阈值优化（样本外验证） |
| **数据管理** | 联网刷新、Choice Excel 上传、缓存状态/清理 |

## 🔄 数据来源

自动拉取优先级：**东方财富直连 → akshare → 腾讯行情 → Choice 缓存 → 旧项目缓存**
- 设置 CHERRYQUANT_LEGACY_DIR 后，可从指定的旧项目目录读取迁移数据
- 东财/akshare 被反爬限制时，自动切换腾讯行情（web.ifzq.gtimg.cn），保证数据可达
- 联网失败自动降级用本地缓存，不中断
- 缓存按来源分目录，Choice 估算 OHLC 不会污染真实行情
- **资金流数据**：东财资金流接口（push2his fflow），独立缓存 `data/cache/fflow/`

## 📊 核心升级（相对旧版 V5.1）

1. **回测接入与实盘一致的风控**：峰值回撤 -8% / 亏损 -10% / 止盈 +15%
2. **阈值优化加样本外验证**：前 70% 训练 / 后 30% 测试，防过拟合
3. **因子 IC/IR 分析**：检验各因子预测力，剔除噪音（动量/底背离），加权有效因子
4. **资金流因子接入**：5日主力净流入为最强因子（近半年实测 IC≈+0.12/90%正，见 `backend/fflow_ic_check.py`；东财免费接口仅提供约120天历史，长周期回测不含该因子）
5. **样本外验证状态标注**：信号表每只 ETF 显示 ✅有效/⚠️一般/❌无效/❓数据不足
6. **ML 选股实验**：GradientBoosting 复用因子预测未来5日，含资金流后 AUC 0.51→0.60
7. **修复数据污染**：分源缓存、垃圾文件清理、来源/新鲜度标注
8. **新增市场温度**：全池信号分布近似大盘多空

## ⚙️ 常用配置

编辑 `backend/engine/config.py`：
- `POOL`：ETF 池、买卖阈值
- `RISK`：止损/止盈参数、每周买入限次
- `KLINE_LIMIT`：拉取 K 线数量
- `CATALYST_CALENDAR`：催化事件日历（当前为空，可自行添加）

## ⚠️ 风险提示

信号与回测结果仅供研究参考，不构成投资建议。历史表现不代表未来。

## 🔬 诚实回测管线（2026-09-05 升级）

```
backend\fetch_long_history.ps1   # 拉取上市以来全历史OHLC → data\cache\em_long\
backend\fetch_fflow.ps1          # 拉取资金流(约120天) → data\cache\fflow\
backend\long_history_backtest.py # 诚实回测: T+1开盘成交/含成本/点内有效/止损止盈/温度择时
backend\today_signals.py         # 当期信号报告(排名/趋势/温度仓位建议)
backend\fflow_ic_check.py        # 资金流因子IC检验
```

诚实口径基准数字（Top5/20日调仓/温度择时/完整风控/含成本）：

| 起点 | 总收益 | 年化 | 夏普 | 最大回撤 |
|---|---|---|---|---|
| 2016（10.7年） | +43.5% | 3.4% | 0.32 | -28.4% |
| 2021（5.7年） | +26.6% | 4.2% | 0.40 | -28.2% |
| 2023（3.7年） | +55.1% | 12.7% | 0.92 | -20.2% |

> 旧宣传口径（+58.4%/+181.9%）为零成本+同日收盘+全历史标签的过期数字，已废弃。
